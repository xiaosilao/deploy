#!/usr/bin/env python
#-*- coding: utf-8 -*-
#=============================================================================
#     FileName:
#         Desc:
#       Author: 苦咖啡
#        Email: voilet@qq.com
#     HomePage: http://blog.kukafei520.net
#      Version: 0.0.1
#   LastChange: 
#      History:
#=============================================================================


# from IPy import IP
#
# #print IP('124.207.253.192/27').len()
# ip_list = '124.207.253.192/27'
#
# ip = IP(ip_list)
# x = [x for x in ip]
#
# print "此网段共有:",ip.len(),"个ip"
# print "第一个:",x[0]
# print "最后一个:",x[-1]
# print "=" * 60
# print "掩码","-" * 5,IP(ip_list).strNetmask()
# print "网段 - 掩码","-" * 5,IP(ip_list).strNormal(3)
# print "网段 - 掩码","-" * 5,IP(ip_list).strNormal(2)
# print "网段 - 掩码","-" * 5,IP(ip_list).strNormal(1)
#
# print "=" * 60
