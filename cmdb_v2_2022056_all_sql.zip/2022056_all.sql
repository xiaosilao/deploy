﻿SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS  `auth_group`;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `authnode`;
CREATE TABLE `authnode` (
  `uuid` char(32) NOT NULL,
  `auth` tinyint(1) NOT NULL,
  `datetime` datetime NOT NULL,
  `node_id` char(32) DEFAULT NULL,
  `user_name_id` int(11) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `AuthNode_c693ebc8` (`node_id`),
  KEY `AuthNode_f10400a0` (`user_name_id`),
  CONSTRAINT `AuthNode_node_id_1f87fa44f6684140_fk_assets_host_uuid` FOREIGN KEY (`node_id`) REFERENCES `assets_host` (`uuid`),
  CONSTRAINT `AuthNode_user_name_id_2f11b0adc9c83a00_fk_users_customuser_id` FOREIGN KEY (`user_name_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `authnode`(`uuid`,`auth`,`datetime`,`node_id`,`user_name_id`) values
('489e49eb15e84a9f8ad14bc2a7bc4cec','1','2018-04-25 00:18:14','d63d5ce484374594b5c28ffbfd4b1454','17'),
('bf33cd58891648bb94f816c9007c2762','1','2018-04-25 00:18:39','920d7f5d1c5f45ea8ad60ebdbc95cdb7','17');
DROP TABLE IF EXISTS  `salt_ui_salt_api_log`;
CREATE TABLE `salt_ui_salt_api_log` (
  `uuid` char(32) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `minions` varchar(2048) NOT NULL,
  `jobs_id` varchar(40) DEFAULT NULL,
  `stalt_type` varchar(20) NOT NULL,
  `salt_len_node` int(11) NOT NULL,
  `stalt_input` varchar(100) DEFAULT NULL,
  `api_return` longtext NOT NULL,
  `log_time` datetime NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `users_department_mode`;
CREATE TABLE `users_department_mode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(64) DEFAULT NULL,
  `description` longtext,
  `desc_gid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

insert into `users_department_mode`(`id`,`department_name`,`description`,`desc_gid`) values
('6','开发部','开发部','1003'),
('7','测试部','测试部','1004'),
('8','运维部','运维部','1001');
DROP TABLE IF EXISTS  `monitor_monitormysql`;
CREATE TABLE `monitor_monitormysql` (
  `uuid` char(32) NOT NULL,
  `name` varchar(120) NOT NULL,
  `monitor_ip` longtext NOT NULL,
  `monitor_user` varchar(32) NOT NULL,
  `monitor_pass` varchar(128) NOT NULL,
  `monitor_port` int(11) NOT NULL,
  `mail` longtext NOT NULL,
  `weixin` longtext NOT NULL,
  `slave` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `createtime` datetime NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `django_content_type`;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_45f3b1d93ec8c61c_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `audit_ssh_audit`;
CREATE TABLE `audit_ssh_audit` (
  `uuid` char(32) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `bash_shell` longtext NOT NULL,
  `audit_data_time` datetime NOT NULL,
  `server_ip` char(15) NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `project_swan_node`;
CREATE TABLE `project_swan_node` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_swan_id` char(32) NOT NULL,
  `host_id` char(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_swan_id` (`project_swan_id`,`host_id`),
  KEY `project_swan_node_a3e2b54e` (`project_swan_id`),
  KEY `project_swan_node_8396f175` (`host_id`),
  CONSTRAINT `project_sw_project_swan_id_4814a3a6ff88c636_fk_project_swan_uuid` FOREIGN KEY (`project_swan_id`) REFERENCES `project_swan` (`uuid`),
  CONSTRAINT `project_swan_node_host_id_633f2c729f485d77_fk_assets_host_uuid` FOREIGN KEY (`host_id`) REFERENCES `assets_host` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=utf8;

insert into `project_swan_node`(`id`,`project_swan_id`,`host_id`) values
('145','00f09e54e29a47dc866f949ba755b660','a90f2ad509bf45038475de14b222254b'),
('144','00f09e54e29a47dc866f949ba755b660','d36533c0f7fe4fdfb0bc8cf6d0821219'),
('171','05f204d07621404db22e893d5fa29d33','cea2ceeeb9d5411b870117c4493e7bf7'),
('150','15e2e12d0a2c4e2c9a519e7ed8bd0fdf','1da4d56bff0d49ce9fb61b7161958410'),
('147','15e2e12d0a2c4e2c9a519e7ed8bd0fdf','68720adbd74a42ccbd13813b133f5e87'),
('149','15e2e12d0a2c4e2c9a519e7ed8bd0fdf','80c84e2365f84c3c8acb64d7c7110ee9'),
('148','15e2e12d0a2c4e2c9a519e7ed8bd0fdf','cc65ad7c5c5d4ee28d618a1a48fcf2f7'),
('136','20a59b4dd0d5413698ba9c64b6455999','0ee19bdefd474ca69f971ba9565ba336'),
('180','251f70b4a2e44dc7bb93b722722ca653','70700e3193eb40d4b04b19d50366c738'),
('182','251f70b4a2e44dc7bb93b722722ca653','a2ddd6b350134e29b61de1632f99951c'),
('181','251f70b4a2e44dc7bb93b722722ca653','ce29d96613d54a6bb34c779be5eb2320'),
('179','251f70b4a2e44dc7bb93b722722ca653','f49bfd6d64b84f1388ee55d884bdb835'),
('192','6a6f0b4db63d456997373e3483f83fbd','3fc7f5176602460981b7161adcf6e8c8'),
('191','6a6f0b4db63d456997373e3483f83fbd','661e8acebc664513a1c190518bf509df'),
('190','6a6f0b4db63d456997373e3483f83fbd','e756c7646fbd4deb8ddf488666f9c56f'),
('156','6dd78f5bb082420888c046fc10b025f3','63d3f007774241f9888b4cd931a96991'),
('157','6dd78f5bb082420888c046fc10b025f3','f4f7353dc25a4c3c965c2e1b1760ebe6'),
('193','81960857dc654f7297c049fa6d17ace2','929390a816c64ca3bad9427c6a61bc8a'),
('172','82c30d1f7cdf41cd8c87a762f8377736','281ee4bdd589466d8ff23f37e74db9d1'),
('174','82c30d1f7cdf41cd8c87a762f8377736','b3d5549560294b55be66e879ce50cc63'),
('173','82c30d1f7cdf41cd8c87a762f8377736','dfad991de88a473eb51c8fbfe5758329'),
('175','82c30d1f7cdf41cd8c87a762f8377736','f16f80fb12e24a828da7fdc20bf0baf1'),
('176','84fbd6d5afbd43ecbbc528cf0cd75cff','c02f6dcc9e9e4266a01786ac4dc8a910'),
('161','8f3780e03ac54e3c99e85437e65e63d1','3b44291e2ef648dabd1454da8c2fc799'),
('163','8f3780e03ac54e3c99e85437e65e63d1','8495bdb243ba4fd7834a541935296a16'),
('160','8f3780e03ac54e3c99e85437e65e63d1','920d7f5d1c5f45ea8ad60ebdbc95cdb7'),
('162','8f3780e03ac54e3c99e85437e65e63d1','d63d5ce484374594b5c28ffbfd4b1454'),
('165','8f3780e03ac54e3c99e85437e65e63d1','e806abad59b344b4850f23512d94d192'),
('164','8f3780e03ac54e3c99e85437e65e63d1','f11b4a0b622b4f529aa78f87b3278f95'),
('139','983bdcb9123a46b1b8e9aa4885b11cdf','aca69ae4047043648bd7d22ac8768c78'),
('140','983bdcb9123a46b1b8e9aa4885b11cdf','cd90c144576e4283a42d881c290d958b'),
('141','983bdcb9123a46b1b8e9aa4885b11cdf','f0970a4c458440b8bf8aa03e6f8962dc'),
('178','988ddc4c36da4f689b743a3ce04d2a3c','5e74a72799ca4c58a5d3a8ec2f19dd81'),
('177','988ddc4c36da4f689b743a3ce04d2a3c','da5c37a7134a46e09ebfdfe08642a238'),
('159','b2b017bbacca4d598394b7cf83d63902','c212701463a64565b78570d6b8a3f327'),
('138','b2f6e08569e5401fbb457a90b733d000','434e41ed69b94147a33d3991bed8bded'),
('137','b2f6e08569e5401fbb457a90b733d000','ebd6b633359242b0a5d3ffe81b472294'),
('170','c08ca0522d0248c5808fb65aa38ee5fd','0ee19bdefd474ca69f971ba9565ba336'),
('143','c8214592eca9448da11c7ee4e8099429','331e180944b54fc2b93ea1a002aff9e3'),
('142','c8214592eca9448da11c7ee4e8099429','c880688c3558450ca198bb40bc24a824'),
('194','d232f9d47c764cd98cef5fac4be84a21','2fade89f55da4583ab2e8172ab3ffccc'),
('196','d232f9d47c764cd98cef5fac4be84a21','6a2d404a802c4c20bf7ce1733a221096'),
('197','d232f9d47c764cd98cef5fac4be84a21','e17795d5d51a4bc6986f1c4c3803c215'),
('195','d232f9d47c764cd98cef5fac4be84a21','fc85d1b92a20459ca6d282cefafef864'),
('153','d6c010a6b33f48a89d007cbe960a290f','4d49b5d9919e4a92b77c8b49f031a2ae'),
('155','d6c010a6b33f48a89d007cbe960a290f','53c8c24011c6496fae19d451b4d87e0d'),
('154','d6c010a6b33f48a89d007cbe960a290f','7f46c2dabac0461d8b3b785ddc548368'),
('152','d6c010a6b33f48a89d007cbe960a290f','ebc801311a7448d2b9e5702b50f91915'),
('184','dae23435fb0644b7ac230f64055c3cbe','4b01881128644227ac8b345b8ab0e335'),
('185','dae23435fb0644b7ac230f64055c3cbe','87bdb70665f44b3ea18414168f646eb0'),
('183','de1fa48b3d1f4ac98fdf2624c0f0722b','d248814a89cf4cd0bd280c23dcb01b38'),
('151','f81f34d2614541289c778b66df22ed9d','39831ac380474932aeda749be56a8a2d'),
('168','f832512dade74e029905c18afcae4691','573995d50bba43be978599a41861faf7'),
('169','f832512dade74e029905c18afcae4691','6289d71d26c14641811cf8f868b3fea6');
DROP TABLE IF EXISTS  `salt_ui_salt_conf`;
CREATE TABLE `salt_ui_salt_conf` (
  `uuid` char(32) NOT NULL,
  `server_name` varchar(20) NOT NULL,
  `prod_name` varchar(20) NOT NULL,
  `file_name` varchar(20) NOT NULL,
  `server_code` longtext NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `assets_line`;
CREATE TABLE `assets_line` (
  `uuid` char(32) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `assets_line`(`uuid`,`name`,`slug`,`sort`) values
('01125dccf48544ddac1a0fc916be1e06','rplan','rplan rzjf','1'),
('512a9e416957498a934c8821ea895cc1','rzjf-rebuild','人众金融服务-重构系统','0');
DROP TABLE IF EXISTS  `auth_permission`;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_417f1b1c` (`content_type_id`),
  CONSTRAINT `auth__content_type_id_508cf46651277a81_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `assets_iplist`;
CREATE TABLE `assets_iplist` (
  `uuid` char(32) NOT NULL,
  `network` varchar(32) DEFAULT NULL,
  `ip` varchar(16) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `idc_id` char(32) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `assets_iplist_0869e37a` (`idc_id`),
  CONSTRAINT `assets_iplist_idc_id_4118d0827945673f_fk_assets_idc_uuid` FOREIGN KEY (`idc_id`) REFERENCES `assets_idc` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `cmdb_auth_auth_group_group_user`;
CREATE TABLE `cmdb_auth_auth_group_group_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auth_group_id` char(32) NOT NULL,
  `customuser_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_id` (`auth_group_id`,`customuser_id`),
  KEY `cmdb_auth_auth_group_group_user_af3f5f04` (`auth_group_id`),
  KEY `cmdb_auth_auth_group_group_user_721e74b0` (`customuser_id`),
  CONSTRAINT `cmdb_auth__customuser_id_33ec160b6f4a2e93_fk_users_customuser_id` FOREIGN KEY (`customuser_id`) REFERENCES `users_customuser` (`id`),
  CONSTRAINT `cmdb_auth_group_id_19c331db012ad2d9_fk_cmdb_auth_auth_group_uuid` FOREIGN KEY (`auth_group_id`) REFERENCES `cmdb_auth_auth_group` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

insert into `cmdb_auth_auth_group_group_user`(`id`,`auth_group_id`,`customuser_id`) values
('13','846e66dd279647dfb1d1963fc79fb27f','17');
DROP TABLE IF EXISTS  `swan_swanlog`;
CREATE TABLE `swan_swanlog` (
  `uuid` char(32) NOT NULL,
  `username` varchar(32) DEFAULT NULL,
  `userID` varchar(128) DEFAULT NULL,
  `project_name` varchar(20) DEFAULT NULL,
  `project_uuid` varchar(64) DEFAULT NULL,
  `module_name` varchar(200) DEFAULT NULL,
  `module_args` varchar(32) DEFAULT NULL,
  `swan_datetime` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `message` longtext,
  `swan_name` varchar(64) DEFAULT NULL,
  `update_log` longtext,
  `target_host` varchar(128) NOT NULL COMMENT '发布目标主机',
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `swan_swanlog`(`uuid`,`username`,`userID`,`project_name`,`project_uuid`,`module_name`,`module_args`,`swan_datetime`,`status`,`message`,`swan_name`,`update_log`,`target_host`) values
('004e5eb40f34434b85fb6d5ffddac8f8','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-04-04 14:46:31','1','发布成功','rz-web-app','注册发短信接口404错误需要上线app,以及短信模板问题修复','172.16.106.1,172.16.105.1'),
('0061a114f12a4a84a09f1b76177a2824','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-05-03 21:35:43','1','发布成功','rz-service-customer','','172.16.101.8,172.16.102.8'),
('00a5f81e9d4a4c0a9ef41c6171c4a5f7','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-accountlo','4d0674633fc8424bb44075597166157c','release','all','2018-04-18 00:11:38','1','发布成功','rz-service-accountlog','','172.16.102.16'),
('010130f1a421436794fe33db302d94b8','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-22 02:47:30','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.103.7,172.16.104.7'),
('011778e122174aeca5a7b550adbb4195','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-08-02 17:55:12','1','发布成功','rz-service-account','','172.16.101.6'),
('018be0e5a6b34cd49ecebf4f4059bf55','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-04-19 16:12:23','1','发布成功','rz-service-third','口袋记账第三方对接','172.16.101.11'),
('02166c9b33974d7d969dd233b104a20e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-09-05 16:51:15','1','发布成功','rz-web-boss','','172.16.101.3'),
('0237175222064836964396b0af762a47','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-06-28 18:51:29','1','发布成功','rz-service-task','','172.16.104.12,172.16.103.12'),
('029820bc67764bc08de718413090975e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-18 00:14:25','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('02b51ac9d19948ee8c8b7da593c54562','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-06-26 23:48:10','1','发布成功','rz-web-app','','172.16.101.1'),
('02bc8eb1ec814f9e8e3f06d55ea71f25','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-08-14 22:02:44','1','发布成功','rz-web-pc','','172.16.102.2'),
('02cce1b767e94ce19677de6140ef183a','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-09 19:23:07','1','发布成功','rz-service-task','bi手机版H5页面数据sql优化','172.16.102.12,172.16.101.12'),
('031bd9380d1d4b71a7bcaaba9a6a1816','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-taskcompa','9d0759ff802c4331916fc124c08e7c1b','release','all','2018-09-11 17:30:08','1','发布成功','rz-service-taskcompare','','172.16.101.18'),
('04349936d1cf49079a47ee57438d122d','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-06-26 14:15:27','1','发布成功','rz-service-bidweb','','172.16.101.24'),
('043b10f2da2a4752a295776e98efaffe','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-05-08 18:31:30','1','发布成功','rz-web-boss','1、boss后台标的待审核列表，标的期限修改功能
2、boss后台已待追加列表-操作-追加-操作框内增加删除键，用于清空追加金额以及右侧追加的小标','172.16.101.3'),
('043ce97ea9de439181bdfc7699f486c9','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-09-11 16:03:22','1','发布成功','rz-service-taskoffline','去掉监控配置','172.16.101.23'),
('048a524a0bd44d0ebfcdb834659b320e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-25 18:25:29','1','发布成功','rz-web-boss','','172.16.101.3'),
('04e2d12470804f1cb21a50ed0ed7618e','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-08-09 15:20:34','1','发布成功','rz-web-redemption','受托支付关闭影响业务的解决方式','172.16.101.5'),
('051b414ef3d44e429ccde39579f066c6','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-05-03 21:43:06','1','发布成功','rz-web-redemption','','172.16.101.5'),
('061dbb44ee4249d28c9d4ef68bc69b8d','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-05-03 21:03:32','1','发布成功','rz-service-taskoffline','','172.16.101.23'),
('0734ea890d944a4c8a0dc8c3686e872d','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-05-08 18:33:56','1','发布成功','rz-service-redpacket','邀请好友后台现金查询','172.16.102.10'),
('079b510891af4bcc99814b5c565f541b','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-04-03 23:01:05','1','发布成功','rz-web-pc','','172.16.103.2,172.16.104.2'),
('07cce788be494d8c9b19ee50b79eb3f2','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-07-03 15:35:05','1','发布成功','rz-web-pc','2.0协议合规内容调整: 协议修改和经常居住地/注册地脱敏需','172.16.102.2,172.16.101.2'),
('07dfc401457f441eb3a2e71de9c45585','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-03 23:02:13','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('0873d7cc02d5499ca36fa86b7cab7056','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-07-26 18:16:11','1','发布成功','rz-web-redemption','','172.16.101.5'),
('091735e398d9422598207475faa64cd4','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-03 22:52:10','1','发布成功','rz-service-redpacket','','172.16.101.10,172.16.102.10'),
('0a39ff2c26c247d4ade4be52bad230cd','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-21 16:42:04','1','发布成功','rz-service-borrow','积分会员优化','172.16.103.7,172.16.104.7'),
('0a924a180f394c729b7771ff0bbe502f','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-07-03 19:29:50','1','发布成功','rz-service-content','','172.16.101.9'),
('0b17cb77d7fa488bb3d276925894cec9','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-07 20:00:04','1','发布成功','rz-service-task','','172.16.104.12,172.16.102.12,172.16.103.12'),
('0bb5d2e6925c4c1995afb4ca8667a069','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-07-24 19:08:45','1','发布成功','rz-service-redpacket','','172.16.102.10'),
('0be27944c0f64fb38d141d443f4c6813','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-05-10 18:13:14','1','发布成功','rz-service-third','承接债权银行超时处理','172.16.101.11'),
('0c84691bcbee4c629d1c4b668d38add7','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-05-24 18:48:11','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('0c951512e789440fa9a126128a37d19a','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-07-05 19:20:49','1','发布成功','rz-service-taskoffline','	邀请好友增加历史排行榜','172.16.101.23'),
('0cd603c6b52142a79b13cb77a40b9a93','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-05-29 16:27:29','1','发布成功','rz-service-task','优化bi当日数据统计数据校验','172.16.104.12,172.16.103.12'),
('0d322bc49e95483c91f7aa34a5c0db5a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-09-13 18:37:34','1','发布成功','rz-web-redemption','','172.16.101.5'),
('0d5c93fe4df343a2add4e5bfa288c1ce','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-09-14 16:50:42','1','发布成功','rz-service-content','MQ技术改造','172.16.102.9'),
('0dad80e1443946af857eded3f95c22d6','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-callback','b47613d484c94327a6f4991654f52032','release','all','2018-06-26 23:54:25','1','发布成功','rz-web-callback','','172.16.101.4'),
('0e39045f1cca4819b18dd458a5d9a19c','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-07-12 21:35:32','1','发布成功','rz-service-redpacket','','172.16.102.10'),
('0f7705be424a459ab71cc790c5d16464','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-28 18:17:12','1','发布成功','rz-service-task','债转协议
借款协议部分信息内容脱敏
提前还款协议','172.16.104.12,172.16.103.12'),
('0f9984bf65424d80a5e809d9b6a6ee79','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-06-28 18:50:27','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('0ff6b645df0e4707a48ca5da933ce6aa','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-05-08 15:51:04','1','发布成功','rz-service-taskoffline','网贷之家和网贷天眼数据接口','172.16.101.23'),
('10252990951e498fa125115aaf56c63c','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-24 16:56:32','1','发布成功','rz-service-task','未脱敏协议地址加密，上上签返回合同号加','172.16.104.12,172.16.103.12'),
('10b04d71177d4f5baa8efba330ecbd1b','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-24 17:53:55','1','发布成功','rz-service-borrow','r计划查询标的详情查询优化','172.16.103.7,172.16.104.7'),
('114841889f434f8dbbaad60e582a8449','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-05-31 19:52:10','1','发布成功','rz-web-boss','系统短信按照短信内容做不同渠道发送','172.16.101.3'),
('11700e58fc654654ba6dcf73fae5df56','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-24 16:54:59','1','发布成功','rz-service-task','未脱敏协议地址加密，上上签返回合同号加','172.16.102.12,172.16.101.12'),
('118f32fd46894a5eac70ea6fe6f76d0f','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-28 18:52:57','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('11f87a3fc6694b3185bba57aa6d82be1','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-04-03 23:07:25','1','发布成功','rz-service-rplan','','172.16.102.14,172.16.101.14'),
('1212ae17ae5240a084c485a67254b992','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-14 18:13:15','1','发布成功','rz-service-borrow','投资失败bug修复','172.16.102.7,172.16.101.7'),
('12b1944612c643bc9a5dfcb6f4bbe18a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-07-10 19:47:30','1','发布成功','rz-service-customer','','172.16.101.8,172.16.102.8'),
('1311ccd9d0804732b446ece4f6515ca0','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-01 01:59:35','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('1338a86cd3814c31890580a096c9481b','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-08-14 20:47:04','1','发布成功','rz-service-bidweb','','172.16.101.24'),
('13c535fcfba747cab9dc49b0a6a9fe79','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-04 14:49:26','1','发布成功','rz-service-redpacket','短信模板问题修复','172.16.104.10,172.16.103.10'),
('1421ccbf5a094ae19a05e1b5de0db9d2','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-04-18 15:55:35','1','发布成功','rz-service-customer','','172.16.101.8,172.16.102.8'),
('143b87cf237041c9838580d40e10153d','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-06-28 18:56:11','1','发布成功','rz-service-customer','','172.16.103.8,172.16.104.8'),
('148e2bb8ab524adeaa192c81b441e690','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-06-27 04:46:01','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('14e7b87f240f4511a6d43926a21cf10b','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-callback','b47613d484c94327a6f4991654f52032','release','all','2018-09-06 18:29:34','1','发布成功','rz-web-callback','springboot技术改造（8）','172.16.101.4'),
('14ec7a518a4f4668861e3b285620e17e','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-27 11:25:56','1','发布成功','rz-service-borrow','支付密码问题','172.16.103.7,172.16.104.7'),
('14ef586c8e4744fd9bf33e898c83fda8','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-05-24 18:52:00','1','发布成功','rz-service-rplan','','172.16.104.14,172.16.103.14'),
('150d67e00ff24f42ab0281a2d428f01d','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-06-25 15:35:33','1','发布成功','rz-service-checkbid','','172.16.101.20'),
('156188aa75024fa297188002b3011f68','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-07-31 22:31:19','1','发布成功','rz-service-customer','','172.16.103.8'),
('157cb4f79883458ab0e4a953c5863e19','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-06-28 19:21:00','1','发布成功','rz-web-boss','','172.16.101.3'),
('15e3bb1d241646e79a896543fe34a791','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-05-03 21:37:18','1','发布成功','rz-service-customer','','172.16.103.8,172.16.104.8'),
('1629d7cebfa2436cab718ec73fcaab26','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-24 17:43:27','1','发布成功','rz-service-redpacket','移动端注册红包显示','172.16.102.10'),
('166b964f8abd48b2afe661b3f7f44950','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-07-24 19:07:53','1','发布成功','rz-service-redpacket','','172.16.101.10'),
('167b0102c87046299691538a20a7a491','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-03-22 01:22:01','1','发布成功','rz-web-app','',''),
('1683292d66ce4dd2a03b5213a198c6af','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-25 02:17:38','1','发布成功','rz-web-boss','修改bug','172.16.101.3'),
('16985c24cb944524bb04b277485bd15d','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-11 18:17:36','1','发布成功','rz-service-redpacket','激活成长现金红包','172.16.101.10'),
('16abd3a1f1b0416797f307246c6110b7','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-07-19 20:50:28','1','发布成功','rz-web-app','','172.16.102.1,172.16.101.1,172.16.103.1'),
('17280860dcd74ee69421150677f7feca','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-18 18:26:36','1','发布成功','rz-service-borrow','','172.16.102.7'),
('17c34eaf2c94422ab8cb1f7d16cc96e0','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-04-26 11:33:55','1','发布成功','rz-web-app','配合IOS审核
APP迭代需求
','172.16.102.1,172.16.101.1'),
('17cbfa8a14824e788ffb99556c85892a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-07-03 21:23:48','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('17f4b81f11c54e719677d0bd0d302d3a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-04 22:58:45','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('182e6642a74d4a90acb86cedbec6933e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-06-26 23:43:40','1','发布成功','rz-service-redpacket','','172.16.101.10'),
('1880dbc59fc34155968f37470d26fbdf','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-08-07 20:02:43','1','发布成功','rz-service-checkbid','','172.16.101.20'),
('189b73349b1a4e9b9319e2872d872704','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-04-17 18:42:07','1','发布成功','rz-service-account','充值处于创建状态会显示"取消提现"','172.16.102.6'),
('190b4035f8b6405fbc7530c6760140ea','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-07-24 19:10:26','1','发布成功','rz-web-boss','','172.16.101.3'),
('1922f55a1b0447afb4a93c7ee60e2976','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-09-15 11:19:54','1','发布成功','rz-service-account','','172.16.102.6'),
('197df9940628412f8f6d668650494519','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-04-04 22:56:22','1','发布成功','rz-service-customer','','172.16.101.8,172.16.102.8'),
('1982cad731d44d9885e9662242d8143e','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-30 17:53:38','1','发布成功','rz-service-borrow','展期优化','172.16.103.7,172.16.104.7'),
('19e26a2fee5b41bd85e1bfa56720095c','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-07 05:30:11','1','发布成功','rz-service-borrow','','172.16.101.7'),
('1a158fd1f80b4fc7a05c2c96e3bc1427','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-07-03 15:39:07','1','发布成功','rz-service-taskoffline','数据统计','172.16.101.23'),
('1ad1e2b0529e4ca2a5c5f5d9a4341439','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-09-19 16:43:34','1','发布成功','rz-web-boss','springboot技术改造','172.16.101.3'),
('1b62bee97d484438bd42d2c66e7a3663','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-06-28 18:58:23','1','发布成功','rz-service-bidweb','','172.16.101.24'),
('1b670b825c674d7cbb68d97bdec89b8d','','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-03-13 17:56:23','1','发布成功','rz-web-app','',''),
('1b7db896159243019b7dfd3b2d1941c1','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-09-11 21:09:41','1','发布成功','rz-service-customer','aqg#gsG7TqTu6%eXVz$tkuCWM','172.16.103.8,172.16.104.8'),
('1c6b43c4c79643a28090a3222304a966','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-03-22 03:29:21','1','发布成功','rz-web-app','获取渠道来源',''),
('1c8c028245504f20aeef88d3e3c584dc','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-04-25 18:03:28','1','发布成功','rz-service-customer','借款信息-借款企业工商信息
1、全称或简称披露后四位，如XXX有限公司；
2、隐去注册地址、成立时间、办公地点，显示星号。','172.16.101.8,172.16.102.8'),
('1c97199fb36448b8bd13d51e5dbceb22','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-06-27 19:15:36','1','发布成功','rz-web-pc','','172.16.103.2,172.16.104.2'),
('1ca235365e4b41c28e27a85febf9a1aa','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-07-12 21:33:44','1','发布成功','rz-service-customer','','172.16.103.8,172.16.104.8'),
('1d85a9ca681441288037a6252b7dffe6','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-07-19 20:36:31','1','发布成功','rz-service-customer','','172.16.103.8,172.16.104.8'),
('1d8c1020da5d4348ada284b7f8bafd81','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-09-06 18:31:02','1','发布成功','rz-web-boss',' boss后台展期优化','172.16.101.3'),
('1e031415d86d4c05be5aa4c3987f3f8b','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-07-05 19:28:06','1','发布成功','rz-web-pc','邀请好友增加历史排行榜','172.16.102.2'),
('1e525bffc4cc4e7ba7d78970c802acb4','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-05-31 19:42:41','1','发布成功','rz-service-third','	系统短信按照短信内容做不同渠道发送','172.16.103.11,172.16.102.11'),
('1e744cd1cd7941c999443f4c4c579236','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-05-31 19:44:20','1','发布成功','rz-service-content','系统短信按照短信内容做不同渠道发送','172.16.102.9'),
('1ef27952a20d4eaaa12b90bdbdb113b0','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-04-19 20:13:43','1','发布成功','rz-web-boss','','172.16.101.3'),
('203152ee3c824d848bf5c14299b8ee29','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-19 20:11:11','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('20db4504225f41b0a16b0b76834272e4','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-08-24 16:57:43','1','发布成功','rz-service-third','未脱敏协议地址加密，上上签返回合同号加','172.16.101.11'),
('20df3fcb74654aa48c4f4e432cb8fe1c','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-14 21:16:36','1','发布成功','rz-service-task','','172.16.101.12'),
('21af277f376a414b8d4a895380d43498','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-08-14 20:45:53','1','发布成功','rz-service-checkbid','','172.16.101.20'),
('21b3b61bee034205a8e77e56e2e5bd21','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redemptio','7b92ba85373f4315a7b9020c7c0227d5','release','all','2018-09-04 18:32:21','1','发布成功','rz-service-redemption','springboot技术改造','172.16.101.19'),
('21cb35ee568d47ed96d9d582b66ab859','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-28 22:17:32','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('224770c3662a4d6282b74a89e4516f27','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-30 15:27:14','1','发布成功','rz-service-borrow','','172.16.103.7'),
('22904f008a634be0ab3f31898a3c2732','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-19 20:10:05','1','发布成功','rz-service-redpacket','','172.16.102.10'),
('22b0be08cdb447d6bafdd2f0186778c2','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-03-22 01:23:50','1','发布成功','rz-web-app','',''),
('22f2a9f1841b4c83a7a49dd059553422','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-03-22 05:34:30','1','发布成功','rz-web-app','',''),
('2323c0960a494d89afccecdcf31dd6aa','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-16 22:16:38','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('235bc934245047babbd87e18eafd8bff','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-07-31 22:48:12','1','发布成功','rz-service-third','','172.16.103.11,172.16.102.11'),
('25c25a0eca2c439d95311cf6ce1b69a4','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-09-14 16:49:48','1','发布成功','rz-service-content','MQ技术改造','172.16.101.9'),
('25d8e1b34a3b417eaf9c23ffc02a024e','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-callback','b47613d484c94327a6f4991654f52032','release','all','2018-08-09 15:18:01','1','发布成功','rz-web-callback','受托支付关闭影响业务的解决方式','172.16.101.4'),
('25e3a383dbce44b18535d19cf1e809d0','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-08-31 19:51:20','1','发布成功','rz-service-account','','172.16.101.6'),
('25f51e64c28b4039a347daf65c51d963','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-08-24 16:59:21','1','发布成功','rz-service-third','未脱敏协议地址加密，上上签返回合同号加','172.16.103.11,172.16.102.11'),
('2652fa8a2f2848ae9a09408a5debd826','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-taskcompa','9d0759ff802c4331916fc124c08e7c1b','release','all','2018-09-11 16:04:58','1','发布成功','rz-service-taskcompare','去掉监控配置','172.16.101.18'),
('2670d3ef414d4f99ab2d5f5e45c55b6a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-accountlo','4d0674633fc8424bb44075597166157c','release','all','2018-07-19 20:46:27','1','发布成功','rz-service-accountlog','','172.16.102.16'),
('2672706f5dfa43d38da4465dd7aaf680','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-07-19 20:35:23','1','发布成功','rz-service-customer','','172.16.101.8,172.16.102.8'),
('272b7b5bc11541d7a35a3fed93116075','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-26 17:41:34','1','发布成功','rz-service-borrow','展期规则配置优化','172.16.102.7,172.16.101.7'),
('279807c3d5164ca68f78dc8a6ebae895','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-07-05 19:26:27','1','发布成功','rz-web-pc','邀请好友增加历史排行榜','172.16.101.2'),
('28b810ed615f4e09981bfa1904349633','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-25 15:09:57','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('297b7fc99b92402388d6260a73ae7383','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-05-08 18:27:21','1','发布成功','rz-service-rplan','日志记录处理时间，便于定位问题','172.16.102.14,172.16.101.14'),
('2a2b5021fad04c12b72894cd635402a4','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-08-07 19:55:12','1','发布成功','rz-service-customer','','172.16.101.8'),
('2a2e392dc345435e9bc0b2960c2cd709','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-03 20:15:44','1','发布成功','rz-service-task','','172.16.104.12,172.16.102.12'),
('2a64026546684c6b889c27fb02ebdd5e','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-07 17:59:11','1','发布成功','rz-service-borrow','springboot技术改造','172.16.103.7,172.16.104.7'),
('2b53b2af267c4087bd59bb19eef6c345','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-02 19:40:13','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('2bbfa1660ecb4a01a46efb7def9f9a02','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-07 05:31:30','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.103.7,172.16.104.7'),
('2c201e93108e4b97ad431bb79d897b22','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-bi','9d0f99c5f18e4496a80322f8320aa393','release','all','2018-05-17 18:18:52','1','发布成功','rz-web-bi',' web-bi的技术需求，本地发短信功能','172.16.101.22'),
('2cfd8e20954c4faead5e81fb6d0ea6a3','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-08 19:20:27','1','发布成功','rz-service-redpacket','','172.16.101.10'),
('2d3facb1d5964caeabaa10e5561a083a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-05-22 19:34:04','1','发布成功','rz-service-redpacket','','172.16.101.10'),
('2e924846b2fc4db392ae5c542f60c46e','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-04-27 21:08:39','1','发布成功','rz-service-content','提前还款需求','172.16.101.9'),
('2fa57121ced94c93850a857aed8edaa5','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-04-27 21:10:47','1','发布成功','rz-service-content','提前还款需求','172.16.102.9'),
('2ffca738fb844dfaa21c97ebbe09bf9b','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-27 04:07:22','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('300e9d2ec79946bdaf7a73f11aa3ed6e','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-03-20 18:19:47','1','发布成功','rz-service-third','投融资转账接口',''),
('3017d5e2a29044fba5231c858aad4b68','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-03 20:19:52','1','发布成功','rz-service-task','','172.16.101.12,172.16.103.12'),
('302c04b6017945e991c9fb32f25f7fbe','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-06-27 03:12:55','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('3080c642c76b4226ada9994b03f018f6','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-06-27 00:00:13','1','发布成功','rz-service-taskoffline','','172.16.101.23'),
('30ec66833f714e54a0cc5432084ab895','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-06-26 23:41:39','1','发布成功','rz-service-customer','','172.16.103.8,172.16.102.8,172.16.104.8'),
('32057196bf1d467f90051c122e312971','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-08-24 16:52:17','1','发布成功','rz-service-content','未脱敏协议地址加密，上上签返回合同号加密','172.16.101.9'),
('320dc8dd1fb84cec8d4bff01289ca245','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-21 16:41:02','1','发布成功','rz-service-borrow','积分会员优化','172.16.102.7,172.16.101.7'),
('32362684ef824f6487229eaafba5975d','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-accountlo','4d0674633fc8424bb44075597166157c','release','all','2018-08-21 20:33:59','1','发布成功','rz-service-accountlog','springboot 改造','172.16.102.16'),
('3266827b56ba4d62bf137456871e25a3','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-04-03 22:57:38','1','发布成功','rz-web-app','','172.16.104.1,172.16.106.1,172.16.105.1'),
('328555b93de94929b62de881c8a0403d','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-08-02 18:01:55','1','发布成功','rz-service-redpacket','','172.16.101.10,172.16.102.10'),
('32953ecccb81400db11dc72cea2a1c35','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-09-14 17:59:51','1','发布成功','rz-service-account','自动提现优化','172.16.102.6'),
('332aab3651604e2da4b683a9f61985c3','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-04-03 22:46:42','1','发布成功','rz-service-content','','172.16.101.9'),
('33413fea91a34309ba64534316171998','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-provide','acf68ee3993641d5b029a205ba7da108','release','all','2018-03-22 15:15:51','1','发布成功','rz-web-provide','',''),
('334dd210981648a9b5cbf2844be1dd05','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-08-09 18:15:50','1','发布成功','rz-service-redpacket','','172.16.102.10'),
('335c2d1f44414873b721eafc436720cb','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-07-03 15:35:41','1','发布成功','rz-web-pc','2.0协议合规内容调整: 协议修改和经常居住地/注册地脱敏需','172.16.103.2,172.16.104.2'),
('34108ed324fa406ebc4daee42355094d','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-09-11 21:08:43','1','发布成功','rz-service-customer','aqg#gsG7TqTu6%eXVz$tkuCWM','172.16.101.8,172.16.102.8'),
('3425eaf94a58497da2d95cb855bd94db','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-08-31 19:55:56','1','发布成功','rz-web-app','','172.16.104.1,172.16.103.1'),
('3425f264d3d14421bb3ebb46aeca577c','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-08-16 00:19:12','1','发布成功','rz-service-bidweb','','172.16.101.24'),
('358dd6248de744b98e7a7d91e698dace','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-accountlo','4d0674633fc8424bb44075597166157c','release','all','2018-07-19 20:45:27','1','发布成功','rz-service-accountlog','','172.16.101.16'),
('35fed543169c43629a0ac229628e4ead','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-05-10 18:15:38','1','发布成功','rz-web-boss','债转承接实际回款时间','172.16.101.3'),
('3625f366392c4023bc9088b876d0eac0','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-06-26 14:16:14','1','发布成功','rz-service-bidweb','','172.16.101.24'),
('36a71b8c665544589e0b0cdbf18f4a00','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-07-24 19:02:37','1','发布成功','rz-web-app','','172.16.106.1,172.16.105.1'),
('37bb4afae66e45fbb8885daf0830e389','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-06-27 11:32:13','1','发布成功','rz-service-task','修改数据源','172.16.102.12,172.16.101.12'),
('380e900b792f4843862810c9b2f4e01c','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-06-27 04:46:21','1','发布成功','rz-service-task','','172.16.104.12,172.16.103.12'),
('385420e6496447778c06fe540c622137','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-04-03 17:58:39','1','发布成功','rz-service-content','主站首页banner图连接地址修改','172.16.102.9'),
('395381d9ea184a8598fdb14544112330','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-taskcompa','9d0759ff802c4331916fc124c08e7c1b','release','all','2018-08-23 17:33:15','1','发布成功','rz-service-taskcompare','springboot 改造','172.16.101.18'),
('3979f0562615490e99feed715f6438e5','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-05-31 18:22:07','1','发布成功','rz-service-third','','172.16.101.11,172.16.102.11'),
('398b928d14454201904d42d8a81ef8c6','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-16 20:54:54','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('398da52593fa499e91bd24d9461c3a9c','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-07-10 19:45:34','1','发布成功','rz-service-taskoffline','','172.16.101.23'),
('3ac35cdb11fa4877b4f6f1241db05a8a','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-07-31 18:18:04','1','发布成功','rz-service-bidweb','兑标协议配合第三方签章优化','172.16.101.24'),
('3b1e9c668dc54106bd134741284f45cb','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-accountlo','4d0674633fc8424bb44075597166157c','release','all','2018-06-26 23:23:44','1','发布成功','rz-service-accountlog','','172.16.102.16'),
('3b33c12cc47d4a53bde9cf061e8a09c5','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-11 15:26:24','1','发布成功','rz-service-borrow','彩虹桥二期','172.16.102.7,172.16.101.7'),
('3b5d9d6207da4aaa8f5c1cbd68866482','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-08-16 18:18:03','1','发布成功','rz-service-bidweb','对标系统批量导入借款企业','172.16.101.24'),
('3b676d7e7c104cf7bf352c68b9216274','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-05-03 17:44:18','1','发布成功','rz-web-app','修改IOS审核首页隐藏因素iPhonex不支持的问题','172.16.104.1,172.16.106.1,172.16.105.1,172.16.103.1'),
('3b98f8c5ece04a7284a7ea74914e8d54','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-24 17:42:02','1','发布成功','rz-service-redpacket','移动端注册红包显示','172.16.101.10'),
('3ba0f6369db3423190664b62c563f6e5','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-06-27 05:55:29','1','发布成功','rz-web-boss','','172.16.101.3'),
('3be33cdc469041bf86b6ae2e334ba318','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-03-20 19:27:33','1','发布成功','rz-web-redemption','费率后金额修改，每日出账增加成标自动出账数据',''),
('3bee7e9329754482b9da4c5e32d2d538','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-consumer','c0097a800e784e42bb7cc7b94cd69113','sp','all','2018-09-14 16:21:20','1','发布成功','rz-service-consumer','','172.16.104.13'),
('3c405bb17dcb4090a8dff95ffae23b29','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-04-25 18:05:50','1','发布成功','rz-service-customer','借款信息-借款企业工商信息
1、全称或简称披露后四位，如XXX有限公司；
2、隐去注册地址、成立时间、办公地点，显示星号。','172.16.103.8,172.16.104.8'),
('3c4f2de2125a465595a0302b56daf378','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-accountlo','4d0674633fc8424bb44075597166157c','release','all','2018-08-23 17:31:28','1','发布成功','rz-service-accountlog','springboot 改造','172.16.101.16'),
('3cd7153d10b04931b67ee7f5d4625d5d','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-04 22:38:09','1','发布成功','rz-service-redpacket','','172.16.101.10,172.16.102.10'),
('3d1597b116f3477a9e7a9a5e5196ad80','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-04-03 17:45:32','1','发布成功','rz-service-account','周末提现到账优化','172.16.102.6,172.16.101.6'),
('3d5ad3146cd542b2b794db14204d1973','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-07-03 15:33:29','1','发布成功','rz-web-app','2.0协议合规内容调整: 协议修改和经常居住地/注册地脱敏需','172.16.102.1,172.16.101.1,172.16.103.1'),
('3d7b6ad45d9a403eaad2bfa265077c80','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-09-14 09:07:36','1','发布成功','rz-web-redemption','','172.16.101.5'),
('3e01b5c014094bdc908bc472565effd5','','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-03-13 10:12:49','1','发布成功','rz-web-boss','',''),
('3e04c2952de6437083381e4d4e15eeb8','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-04-12 20:43:22','1','发布成功','rz-web-app','','172.16.102.1,172.16.101.1,172.16.103.1'),
('3e4025b1d4684dc6bc7085407e52e7e8','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-09-01 02:02:11','1','发布成功','rz-web-app','','172.16.102.1,172.16.101.1'),
('3ee6c7322fcc4218882f97f6f94c5936','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-04-09 19:42:03','1','发布成功','rz-service-rplan','','172.16.104.14,172.16.103.14'),
('3f05ebcd23854e33abb871f8147f36e4','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-31 19:46:25','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.103.7'),
('3f2753641d0c4711b947502822833081','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-14 16:56:59','1','发布成功','rz-service-borrow','MQ技术改造','172.16.103.7,172.16.104.7'),
('3f868515d11b46538828bcbb9be68331','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-25 18:20:42','1','发布成功','rz-service-borrow','','172.16.101.7'),
('3fd58dac1d154801be2e08e68e321c15','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redemptio','7b92ba85373f4315a7b9020c7c0227d5','release','all','2018-09-14 16:59:21','1','发布成功','rz-service-redemption','MQ技术改造','172.16.102.19'),
('40837831f4bd4b4487eaf88137d85c98','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-06-29 18:00:18','1','发布成功','rz-web-boss','165条用户流水记录 因消息消费失败而丢失，现需要紧急修复上线','172.16.101.3'),
('41251f7bc28744b6842537bb596c2725','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-05-24 18:47:07','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('41310684bcf446c0975b7d5418e64c8e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-09-07 05:35:34','1','发布成功','rz-web-app','','172.16.104.1,172.16.106.1,172.16.105.1,172.16.103.1'),
('41a9c273f50f4d6d841fdd2629536a5a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-04-12 20:35:28','1','发布成功','rz-service-content','','172.16.102.9'),
('41dd79dc394843fe9bdeffbf13c417d9','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-30 16:00:23','1','发布成功','rz-web-boss','boss后台债转相关的提前还款','172.16.101.3'),
('4225e6176a6f4626b862531b9557f6bc','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redemptio','7b92ba85373f4315a7b9020c7c0227d5','release','all','2018-07-05 17:07:18','1','发布成功','rz-service-redemption','将原推送至Rebuild的mq替换为java的mq地址','172.16.101.19'),
('422828824ff141eaa3153e5da062ee0d','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-08-25 21:16:32','1','发布成功','rz-service-content','','172.16.101.9'),
('42c771ac2e5f4b0c8c78b214a4299fcc','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-04 22:36:43','1','发布成功','rz-service-redpacket','','172.16.101.10,172.16.102.10'),
('431bb47b73d641f8979ab1eb03d374da','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-06-28 22:19:20','1','发布成功','rz-web-boss','','172.16.101.3'),
('434e083b0ccf4289944e6ea564b77c5e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-08-09 18:14:53','1','发布成功','rz-service-redpacket','','172.16.101.10'),
('436b15a16d304d169de10a03f1778d24','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-08-30 16:04:34','1','发布成功','rz-web-app','springboot技术改造','172.16.104.1,172.16.106.1,172.16.105.1,172.16.103.1'),
('4378b534f8d24f83b42f29e1f6f65f21','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-04-28 19:03:41','1','发布成功','rz-web-redemption','出账异步回调数据更新问题修改
','172.16.101.5'),
('4389e79d737b4b7391e92ad9b7431f58','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-28 10:18:45','1','发布成功','rz-service-borrow','还款业务还原成6.26日上线的版本','172.16.102.7,172.16.101.7'),
('442cddd38f404d7090c76c91c8058feb','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-07 20:56:14','1','发布成功','rz-service-borrow','彩虹桥二期','172.16.102.7,172.16.101.7'),
('4452fdd5b4ba4e72972993ac13f289ff','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-11 18:19:18','1','发布成功','rz-service-redpacket','激活成长现金红包','172.16.102.10'),
('445cfb869d2e4c86b0d771ecd07994d0','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-12 14:12:12','1','发布成功','rz-service-borrow','投标异常回滚','172.16.102.7,172.16.101.7'),
('44c395cfc5d44b80a2ecee6187164467','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-27 04:45:25','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('452dc1241de6424ba55aac38b5ec6612','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-accountlo','4d0674633fc8424bb44075597166157c','release','all','2018-06-26 23:22:27','1','发布成功','rz-service-accountlog','','172.16.101.16'),
('4590b1e4aebd4bd090c5364b319c5bab','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-07-03 15:29:42','1','发布成功','rz-service-customer','2.0协议合规内容调整: 协议修改和经常居住地/注册地脱敏需','172.16.103.8,172.16.104.8'),
('463ac19cbfcd4767b18732790e165439','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-09-14 00:37:53','1','发布成功','rz-service-account','','172.16.101.6'),
('4643f6681225462f970016488eaa9593','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-09-15 11:18:40','1','发布成功','rz-service-account','','172.16.101.6'),
('46abc0a80f1442899e8632ad738cbb69','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-27 04:45:01','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('474ac3fd9d5644b79c552453e6c7c4a4','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-07-22 02:49:23','1','发布成功','rz-web-app','','172.16.101.1'),
('47542e4c481f4781af8970053fde663b','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-07 18:16:00','1','发布成功','rz-service-borrow','1、有发生债转时优化协议查询
2、承接债转-新增 更新activity_award表状态为3债转回收，防止还款发放加息券','172.16.102.7,172.16.101.7'),
('47d6fd86afe544868bdb8c04d4d82134','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-09 14:28:33','1','发布成功','rz-service-task','信息披露--平台数据','172.16.104.12,172.16.103.12'),
('484888875af946c1b15e59c7bbfc9421','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-06-28 19:22:34','1','发布成功','rz-web-pc','','172.16.103.2,172.16.104.2'),
('48497d0c22e94bb0a0d0032b3015ffd2','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-05-29 20:03:49','1','发布成功','rz-service-rplan','标的进度优化','172.16.102.14,172.16.101.14'),
('484d78cc78c24a7cb2b84f725dc5467e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-04-08 19:27:42','1','发布成功','rz-service-taskoffline','','172.16.101.23'),
('48cc225ad9844e9f9684f8ed7b2c8e92','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-03-20 18:16:55','1','发布成功','rz-service-third','投融资转账接口',''),
('48e2a78be86745fba2ba5bdfa1e3fc37','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-07-19 20:48:52','1','发布成功','rz-web-pc','','172.16.102.2'),
('4956056b7c7b45798f4734fffad427f7','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-bi','9d0f99c5f18e4496a80322f8320aa393','release','all','2018-08-20 16:35:40','1','发布成功','rz-web-bi','springboot改造','172.16.101.22'),
('499b9090d8b54a23931342a801a504bf','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-07-12 19:34:22','1','发布成功','rz-service-bidweb','','172.16.101.24'),
('4a2f502292234521a21408eee9359cb7','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-09-13 18:15:20','1','发布成功','rz-service-customer','','172.16.101.8'),
('4a3f6b37d08a4400a8bec90e8dcb5b2e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-05-03 21:41:08','1','发布成功','rz-service-rplan','','172.16.102.14,172.16.101.14'),
('4a8b229004f841e1a98db9ff0a433a2f','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-18 00:22:59','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('4b5636fc554e49a5a7e56211d7c004c1','','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-03-15 17:48:27','1','发布成功','rz-web-boss','',''),
('4b9bbb9e73294fa293788811a0cb236d','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-19 21:58:19','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('4bd8fdd8e3e742058278fa0f82d967b7','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-05-24 18:49:37','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('4c88e7598a3747c2a251a29e5e5e250d','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-09 14:27:09','1','发布成功','rz-service-task','信息披露--平台数据','172.16.102.12,172.16.101.12'),
('4d6a2b4c88ae4f6d84865a7c4dbee397','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-06-26 23:44:06','1','发布成功','rz-service-redpacket','','172.16.102.10'),
('4d9e5d1a3f6b404d9f428cfefb365eef','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-25 15:12:56','1','发布成功','rz-service-task','','172.16.101.12'),
('4db183588db040e8bad5051a8e1c3a4a','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-06-27 11:33:20','1','发布成功','rz-service-task','修改数据源','172.16.104.12,172.16.103.12'),
('4dda7b8b037b4eb3943693b6c899ebd2','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-03 18:03:32','1','发布成功','rz-service-task','周末提现在工作日审批后能够有限到账','172.16.102.12,172.16.101.12'),
('4defc7a3366041d0a74268f292d49fee','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-07 18:19:41','1','发布成功','rz-web-boss','boss查询优化','172.16.101.3'),
('4f507915ace24ef485edde8b002e8e3b','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-08-14 21:28:24','1','发布成功','rz-service-third','','172.16.103.11,172.16.102.11'),
('4f8937977d01440782921cc6baa357a1','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-callback','b47613d484c94327a6f4991654f52032','release','all','2018-09-06 18:30:18','1','发布成功','rz-web-callback','springboot技术改造（8）','172.16.103.4,172.16.102.4'),
('5007d98191eb4ea0b7412ee38ad02b27','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-04-28 18:19:16','1','发布成功','rz-service-content','债转协议
借款协议部分信息内容脱敏
提前还款协议','172.16.102.9'),
('5062c9ae551047f7a59fcb81b6532914','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-07-05 19:25:03','1','发布成功','rz-web-app','邀请好友增加历史排行榜','172.16.104.1,172.16.106.1,172.16.105.1'),
('5098bc65710641d0806abe414ed98e95','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-03-27 16:46:01','1','发布成功','rz-service-borrow','生产问题修复：
标的是还款中但用户投资记录显示的已汇款','172.16.103.7,172.16.104.7'),
('50f18343455f4f369e0e52b42bbddec5','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-08-30 16:02:58','1','发布成功','rz-web-app','springboot技术改造','172.16.102.1,172.16.101.1'),
('51029175d8914adebd810abbc1db5883','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-03-22 01:23:01','1','发布成功','rz-web-app','',''),
('51456a2655d046b6b03876105d44f6eb','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-07-19 20:41:11','1','发布成功','rz-service-bidweb','','172.16.101.24'),
('521dd0ee15d143bb8af36fd86bdcf4d7','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-09 22:37:06','1','发布成功','rz-service-task','','172.16.104.12,172.16.102.12,172.16.101.12,172.16.103.12'),
('523381838a7f40c98d325869d77494d5','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-06-27 19:13:25','1','发布成功','rz-web-pc','','172.16.102.2,172.16.101.2'),
('52558c4cb9694b0f878bf705ecc8c497','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-05-24 18:30:31','1','发布成功','rz-service-content','','172.16.101.9'),
('52c3a1006f624abba9031b0946c42e26','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-06-26 23:59:24','1','发布成功','rz-service-task','','172.16.104.12,172.16.102.12,172.16.103.12'),
('52ea1e911e4d442aa38589d6383875a5','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-04-09 11:23:34','1','发布成功','rz-web-boss','','172.16.101.3'),
('53d8ee8bb6294060a24acc5e0aeaf0bd','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-06-27 09:22:58','1','发布成功','rz-web-boss','bug','172.16.101.3'),
('53da70a430eb43d78ab67b909f306f04','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-06-26 23:48:57','1','发布成功','rz-web-app','','172.16.104.1,172.16.106.1,172.16.102.1,172.16.105.1,172.16.103.1'),
('54056f8caea447098e087213007bdd11','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-09-04 18:29:42','1','发布成功','rz-service-task','技术优化，去掉数据库监控配置','172.16.104.12,172.16.103.12'),
('54318af0e9bd4c4a92a784a385c49c78','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-18 18:25:47','1','发布成功','rz-service-borrow','','172.16.101.7'),
('5502ca6cc95e4089ad7817468f6e1ab0','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-30 15:26:21','1','发布成功','rz-service-borrow','','172.16.102.7'),
('55c21fef59bb48b9b8fa58153c7578ff','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-09-14 17:00:13','1','发布成功','rz-web-redemption','MQ技术改造','172.16.101.5'),
('58e3d2a94d1d48e3b3171bf5eff85df4','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-03-22 15:20:12','1','发布成功','rz-service-borrow','回款日历查询优化',''),
('58fb4f5ec6ae44a2bdd935adc37a66d2','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-18 00:24:11','1','发布成功','rz-service-task','','172.16.104.12,172.16.103.12'),
('598b030fc96e4da4a22521e3dd16c385','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redemptio','7b92ba85373f4315a7b9020c7c0227d5','release','all','2018-08-16 00:18:25','1','发布成功','rz-service-redemption','','172.16.101.19,172.16.102.19'),
('59dd71acd8f34020bd001e1184633527','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-11 10:56:13','1','发布成功','rz-service-borrow','彩虹桥二期','172.16.102.7,172.16.101.7'),
('59de7f382b5344089ac191cd3659c949','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-05-03 20:56:46','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('5a9fa9fe702a4146a54041b0f7a0def0','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-27 03:01:25','1','发布成功','rz-service-borrow','','172.16.101.7'),
('5aea833f9dd7496bb400f09b5085ed1b','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-26 11:32:33','1','发布成功','rz-service-borrow','配合IOS审核
APP迭代需求','172.16.103.7,172.16.104.7'),
('5afa2e3a95bf4569ac31e7963b7ef094','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redemptio','7b92ba85373f4315a7b9020c7c0227d5','release','all','2018-08-09 15:15:12','1','发布成功','rz-service-redemption','受托支付关闭影响业务的解决方式','172.16.101.19'),
('5afa2fa1db754f26a3da8ca3989e6aa2','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-27 03:02:20','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.103.7,172.16.104.7'),
('5bda53cd9c3146079a8a029d8b3964fa','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-14 21:26:30','1','发布成功','rz-service-task','','172.16.104.12'),
('5c3da814dfd64bad8b149af9cc947227','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-09-11 20:47:22','1','发布成功','rz-service-account','boss后台自动体现取消最新金额限制','172.16.101.6'),
('5cb3dc4a731742d783298ad399cccdfe','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-24 20:19:06','1','发布成功','rz-service-borrow','展期配置','172.16.103.7,172.16.104.7'),
('5db66886eb4d44b39cd59d300a23e597','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-31 18:08:58','1','发布成功','rz-web-boss','boss后台:  跑用户充值、提现、累积收益任务','172.16.101.3'),
('5dc44709b66948a1a4dc991f1d1c5cb0','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-27 11:24:30','1','发布成功','rz-service-borrow','支付密码问题','172.16.102.7,172.16.101.7'),
('5de429c403e74e509a10c332ffbf8517','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-07 19:58:55','1','发布成功','rz-service-task','','172.16.101.12'),
('5e568aa5f0f940ae97abdb9670d56d6a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-26 23:35:31','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.103.7,172.16.104.7'),
('5ea6ea0e288d42e6928dccfddfb720d0','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-04-03 22:56:17','1','发布成功','rz-web-app','','172.16.102.1,172.16.101.1,172.16.103.1'),
('5ecd2a231e3644a789e9e1c7460edf26','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-18 00:46:24','1','发布成功','rz-service-task','','172.16.104.12,172.16.103.12'),
('5f355d6e7def46139c026538650435dc','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-03-27 16:44:11','1','发布成功','rz-service-borrow','生产问题修复：
标的是还款中但用户投资记录显示的已汇款','172.16.102.7,172.16.101.7'),
('5fb9501534e843b8884e24a742d55f00','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-06-25 15:49:39','1','发布成功','rz-service-bidweb','','172.16.101.20'),
('5fe1f6f5ff4f4f3898dc7f1ea9b74b2b','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-callback','b47613d484c94327a6f4991654f52032','release','all','2018-05-03 21:47:40','1','发布成功','rz-web-callback','','172.16.103.4'),
('6026ea5c549f475b88abbfd2d3c9dfae','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-27 09:52:49','1','发布成功','rz-service-borrow','Android标的详情进度精度问题bug','172.16.102.7,172.16.101.7'),
('60480638ca374d90b81ad37cbc399013','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-08-24 16:53:49','1','发布成功','rz-service-content','未脱敏协议地址加密，上上签返回合同号加','172.16.102.9'),
('6048b186d3c841588ca668aab6147002','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-09-14 17:57:22','1','发布成功','rz-service-customer','boss后台黑名单优化','172.16.103.8,172.16.104.8'),
('60c4a9733e78483b8cba384ef2f09a39','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-consumer','c0097a800e784e42bb7cc7b94cd69113','sp','all','2018-09-14 16:19:25','1','发布成功','rz-service-consumer','','172.16.103.13'),
('6127e8c2bfa04a1795c03af240179489','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-14 21:23:39','1','发布成功','rz-service-task','','172.16.101.12'),
('61966226c9a44a8e841b8e36f782b8c9','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-05-31 18:22:59','1','发布成功','rz-service-third','','172.16.103.11'),
('61d0e8ccb8de44a28fda2d272cb34672','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-30 15:27:47','1','发布成功','rz-service-borrow','','172.16.104.7'),
('62335b633bdc4be8b5bc63ef8c7e0d92','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-accountlo','4d0674633fc8424bb44075597166157c','release','all','2018-08-21 20:26:15','1','发布成功','rz-service-accountlog','springboot 改造','172.16.101.16'),
('630a138be2d54dd5b241f75c693d25f4','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-06-26 23:57:09','1','发布成功','rz-web-redemption','','172.16.101.5'),
('63338f69c11342fba6355b93eeca7c31','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-05-03 21:44:45','1','发布成功','rz-web-boss','','172.16.101.3'),
('637670be46dd4d3a9f2d5fe8e0ef67a1','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-04-05 02:13:50','1','发布成功','rz-service-customer','','172.16.103.8,172.16.104.8'),
('63af3af556af4cb1874b640f9a1e8a63','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-04-04 14:44:33','1','发布成功','rz-web-app','注册发短信接口404错误需要上线app,以及短信模板问题修复','172.16.102.1,172.16.101.1'),
('63d2d8a292184ac7b2c252681debee65','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-06-28 19:24:05','1','发布成功','rz-web-app','','172.16.102.1,172.16.101.1,172.16.103.1'),
('65128dc7600e41a88f947accc291d5b4','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-04-12 20:36:37','1','发布成功','rz-service-account','','172.16.101.6'),
('657f6af3e5cb4c80b801151f71aec67a','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-24 20:18:01','1','发布成功','rz-service-borrow','展期配置','172.16.102.7,172.16.101.7'),
('6686df13af99483197b203ac28fe0fac','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-06-25 15:48:12','1','发布成功','rz-service-bidweb','','172.16.101.20'),
('66985d9d898542d1aecec7955c467d5e','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-28 18:15:38','1','发布成功','rz-service-task','债转协议
借款协议部分信息内容脱敏
提前还款协议','172.16.102.12,172.16.101.12'),
('66b3a4ccbd4a4c30969e7df1e308ab58','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-08-09 19:25:09','1','发布成功','rz-service-third','boss后台短信管理','172.16.101.11'),
('66c7d3388f3740a2b275ac682abaa6b5','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-09-06 16:01:32','1','发布成功','rz-service-task','boss后台展期操作界面增加筛选框','172.16.104.12,172.16.103.12'),
('66cd22a3552543a785222547f96c5b1c','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-07-26 16:14:05','1','发布成功','rz-web-app','协议：图片改为pdf','172.16.104.1,172.16.106.1,172.16.105.1'),
('66e2b1748ba44aa0879d4c3c15d4f07a','','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-03-19 16:07:07','1','发布成功','rz-web-boss','添加双因子认证（手机验证码）',''),
('670d028cfee74f8c9e54576cd771c2b4','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-06-27 06:04:46','1','发布成功','rz-service-task','','172.16.104.12,172.16.102.12,172.16.101.12,172.16.103.12'),
('678d916faf8744cd9e7425efa815f8b9','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-28 10:43:11','1','发布成功','rz-service-borrow','回款日历优化','172.16.103.7,172.16.104.7'),
('67993cf623014f3eadbb5371ca5513ff','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-12 14:17:04','1','发布成功','rz-service-borrow','投标异常回滚','172.16.103.7,172.16.104.7'),
('68a9b1f7e59f48f5b6c996dda4db5f26','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-28 10:20:48','1','发布成功','rz-service-borrow','还款业务还原成6.26日上线的版本','172.16.103.7,172.16.104.7'),
('68b6ca13361d4ee7b57681fb7d1cf4b7','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-06-26 23:52:05','1','发布成功','rz-web-pc','','172.16.103.2,172.16.102.2,172.16.104.2'),
('68d27bf3d3704c5e9cefbd6463e28c82','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-06-28 18:49:13','1','发布成功','rz-service-content','','172.16.102.9'),
('6a2150d32ceb4de5bd1f5f1fa6ad9d3e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-19 21:59:00','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('6b7f605579e04ccd89f3fdb97157cb23','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-09-14 16:52:44','1','发布成功','rz-service-third','MQ技术改造','172.16.103.11,172.16.102.11'),
('6c32aa0840a4419d8c363dce4ec6761b','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-06-26 23:58:22','1','发布成功','rz-service-task','','172.16.101.12'),
('6c42badc96fe45679ce3910fdd692d4c','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-07-03 15:27:52','1','发布成功','rz-service-customer','2.0协议合规内容调整: 协议修改和经常居住地/注册地脱敏需','172.16.101.8,172.16.102.8'),
('6c6cd14f88f04e6bbe8da8be1bab6970','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-04-03 23:19:57','1','发布成功','rz-service-taskoffline','','172.16.101.23'),
('6c92c50433444b4db06f1526b562d8b2','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-26 18:28:17','1','发布成功','rz-service-borrow','回款日历优化','172.16.103.7,172.16.104.7'),
('6cd282c3318a4a87a2febfb648280729','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-06 17:59:13','1','发布成功','rz-service-borrow','小黑屋需求','172.16.102.7,172.16.101.7'),
('6d02c47f93294054bab2976ea29c1718','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-08-25 15:06:29','1','发布成功','rz-service-content','','172.16.101.9'),
('6d0eb03c971a42e79ada00c837cfafd1','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-callback','b47613d484c94327a6f4991654f52032','release','all','2018-05-03 21:46:47','1','发布成功','rz-web-callback','','172.16.102.4,172.16.101.4'),
('6ef40f7796d44f37b22c7ec4b12696ec','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redemptio','7b92ba85373f4315a7b9020c7c0227d5','release','all','2018-08-09 18:42:56','1','发布成功','rz-service-redemption','','172.16.101.19'),
('6fa038913e3445eb9cfe96f46443edb7','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-04-03 19:31:40','1','发布成功','rz-service-taskoffline','','172.16.101.23'),
('6fc97e30458e4ef6afc12c1693ebf703','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-07-10 17:31:12','1','发布成功','rz-service-task','协议分表
R计划技术优化','172.16.102.12,172.16.101.12'),
('6fd62a9110c147a6a7e6706a8e9e5120','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-07-19 20:39:17','1','发布成功','rz-service-checkbid','','172.16.101.20'),
('70a365eabb0f42249cc5d9dbb5817a67','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-08-21 20:15:00','1','发布成功','rz-service-account','springboot 改造','172.16.101.6'),
('70ecb0ea90de4be09007352c2a9a3ec3','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-09-11 15:34:34','1','发布成功','rz-web-boss','彩虹桥二期','172.16.101.3'),
('713ffcfa8af247dcaeb013e58c70a68b','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-26 23:32:10','1','发布成功','rz-service-borrow','','172.16.101.7'),
('7160a7b997a74a32b38f5857d33544ab','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-07 18:17:47','1','发布成功','rz-service-borrow','1、有发生债转时优化协议查询
2、承接债转-新增 更新activity_award表状态为3债转回收，防止还款发放加息券','172.16.103.7,172.16.104.7'),
('718058653c244381b13b92f4997ffbdd','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-09-14 16:53:54','1','发布成功','rz-service-account','MQ技术改造','172.16.101.6'),
('71a95253b112452fa5460b8f09648a3f','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-09-07 05:18:13','1','发布成功','rz-service-content','','172.16.101.9'),
('729f8e5dc6e74d20b423fd4a4291e003','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-08 19:24:18','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('732821a2b20d46c59e927bd1656fbfb9','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-05-31 15:28:29','1','发布成功','rz-service-task','优化bi当日数据统计数据校验	详情项无数据展示','172.16.104.12,172.16.103.12'),
('73a8ae000f48417fa608db9f4892252c','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-09-04 21:08:11','1','发布成功','rz-web-boss','','172.16.101.3'),
('73ab087feb6043609e91d391e698bb8a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-07-24 19:01:45','1','发布成功','rz-web-app','','172.16.104.1,172.16.102.1,172.16.103.1'),
('73c0011ab46a425d9daaf96d105eb8f7','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-03-21 22:02:34','1','发布成功','rz-service-third','',''),
('74581ac0cc6c48708a8662b7d44a6f11','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-06-27 01:10:43','1','发布成功','rz-service-checkbid','','172.16.101.20'),
('746ab91a9e154156853f32a0eab4bb01','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-05-31 15:27:03','1','发布成功','rz-service-task','优化bi当日数据统计数据校验	详情项无数据展示','172.16.102.12,172.16.101.12'),
('751c3e8704474e729680656f8bb25daa','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-08-16 18:17:27','1','发布成功','rz-service-checkbid','对标系统批量导入借款企业','172.16.101.20'),
('7581cc0c2ddc4d0e81e65abd61ec608a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-03-22 02:46:24','1','发布成功','rz-web-app','获取渠道来源',''),
('763a7fe597f24639973d6d500aeb318f','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-07-03 17:18:32','1','发布成功','rz-web-boss','推送数据优化','172.16.101.3'),
('7686e67188354f5c8677c9f404b82bff','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-bi','9d0f99c5f18e4496a80322f8320aa393','release','all','2018-07-10 19:49:28','1','发布成功','rz-web-bi','','172.16.101.22'),
('76ab3d14522548898b1439b0734b9abd','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-08-31 19:54:50','1','发布成功','rz-web-app','','172.16.102.1,172.16.101.1'),
('7728210c702143ab89bf78751eb03141','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-14 16:55:58','1','发布成功','rz-service-borrow','MQ技术改造','172.16.102.7,172.16.101.7'),
('774134716ed440f6a934add57a41aa1e','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-30 17:15:30','1','发布成功','rz-web-boss','boss后台废标优化','172.16.101.3'),
('77706f7fa021406189afbbb496abb378','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-consumer','c0097a800e784e42bb7cc7b94cd69113','release','all','2018-09-07 17:55:37','1','发布成功','rz-service-consumer','springboot技术改造','172.16.101.13,172.16.102.13'),
('77b2e1d79b98408aa5347edfa3110702','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-07-03 15:38:38','1','发布成功','rz-service-checkbid','BI数据统计','172.16.101.20'),
('7879d2ca4ce94b64b27018b7c260ea21','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-09-06 15:59:43','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('7979fb5925644315b0502b5abba2f861','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-bi','9d0f99c5f18e4496a80322f8320aa393','release','all','2018-07-24 16:05:30','1','发布成功','rz-web-bi','数据大屏;长连接改造','172.16.101.22'),
('79eccb4c59694501b50efd6453a07518','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-bi','9d0f99c5f18e4496a80322f8320aa393','release','all','2018-06-27 10:42:17','1','发布成功','rz-web-bi','数据源','172.16.101.22'),
('7a1741f87eed4e419cf690549725a6e1','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-provide','acf68ee3993641d5b029a205ba7da108','release','all','2018-05-08 17:40:39','1','发布成功','rz-web-provide','网贷之家和网贷天眼的数据接口','172.16.101.21'),
('7ad565cd316e4ede9a94caa147343374','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-07-03 15:34:16','1','发布成功','rz-web-app','2.0协议合规内容调整: 协议修改和经常居住地/注册地脱敏需','172.16.104.1,172.16.106.1,172.16.105.1'),
('7ae1ba515de24eafbd838644f468e611','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-09-04 18:34:29','1','发布成功','rz-web-redemption','springboot技术改造','172.16.101.5'),
('7b0021b226744d1982122e2c802b4d02','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-06-25 21:07:52','1','发布成功','rz-service-bidweb','','172.16.101.19'),
('7b578bfd95af4e05ba9b6128f7a0e1ac','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-06-28 19:25:08','1','发布成功','rz-web-app','','172.16.104.1,172.16.106.1,172.16.105.1'),
('7cfd5e5ac23542d9b07f500de71b4b7b','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-consumer','c0097a800e784e42bb7cc7b94cd69113','release','all','2018-06-26 23:38:06','1','发布成功','rz-service-consumer','','172.16.104.13,172.16.102.13,172.16.103.13'),
('7d38ad8e7137493585e5b353ddf464b3','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-25 15:15:22','1','发布成功','rz-service-task','','172.16.104.12,172.16.102.12,172.16.103.12'),
('7d9d8725a01d4368a75da12556ec6776','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-09-14 16:51:47','1','发布成功','rz-service-third','MQ技术改造','172.16.101.11'),
('7e18964ccfcf4e7c9a1c8bcf456ca975','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-12 20:32:40','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('7efbf39c81cb422e9093e4c929b03f70','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-04-03 20:21:19','1','发布成功','rz-web-boss','','172.16.101.3'),
('7f3049ddac7748aa9b0b736110f71edf','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-08-08 20:39:28','1','发布成功','rz-service-checkbid','','172.16.101.20'),
('7f8d5123825446aca1d632574baaca93','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-03-22 02:40:58','1','发布成功','rz-web-app','获取渠道来源',''),
('7ff66dc891574c8fa427a8bfddd3aa1e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-12 20:31:58','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('808417f84c4c40eda5385714b59b33df','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-27 19:18:49','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('80d6f61314a84d94a620cc85933eed1a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-05-31 18:41:42','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('8163ee4de7194c158302f2c431cd8705','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-06-27 19:20:31','1','发布成功','rz-service-checkbid','','172.16.101.20'),
('817e9a0b5dd8426ba9ab01120016e0c1','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-06 18:00:13','1','发布成功','rz-service-borrow','小黑屋需求','172.16.103.7,172.16.104.7'),
('8186bdbcc759496282f7eb1700f40edf','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-26 17:44:29','1','发布成功','rz-web-boss','展期规则配置优化','172.16.101.3'),
('818e44fe2d9a4057834669a7bc47769e','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-30 17:52:39','1','发布成功','rz-service-borrow','展期优化','172.16.102.7,172.16.101.7'),
('820734d007344aa5a6a13889d85d10b3','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-04-03 17:54:16','1','发布成功','rz-service-content','主站首页banner图连接地址修改','172.16.101.9'),
('820ecfe66c1740f0bfe1e5fe53a6e208','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-09-04 19:49:32','1','发布成功','rz-web-app','平台数据优化','172.16.104.1,172.16.106.1,172.16.105.1'),
('8240811810d54e7392e5f9cf5252946e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-04-05 04:26:17','1','发布成功','rz-service-customer','','172.16.101.8,172.16.102.8'),
('832ce8776f2240dab2ea99a76ffa05b6','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-04-04 22:57:14','1','发布成功','rz-service-customer','','172.16.103.8,172.16.104.8'),
('8344ea34c1044cc3b358f973f3305281','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-07-03 17:19:21','1','发布成功','rz-web-redemption','推送数据优化','172.16.101.5'),
('8379daa4f8be4e7294b1c2e1de27b685','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-08-02 18:07:12','1','发布成功','rz-service-taskoffline','加解密优化','172.16.101.23'),
('83a79d6dd1a54e429ecb77c7a4a1fe54','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-08-23 23:52:40','1','发布成功','rz-web-redemption','','172.16.101.5'),
('8420eeeba45a4783b910fead2c93c495','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-11 15:33:27','1','发布成功','rz-service-borrow','彩虹桥二期','172.16.103.7,172.16.104.7'),
('8501bf6b09134922920fc20e05c94a1f','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-03-20 18:14:06','1','发布成功','rz-web-boss','标的列表修改，标的期限提示',''),
('854023bfeae1435a892fa236d2e6c4c8','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-02 18:08:32','1','发布成功','rz-web-boss','客服部boss后台产品迭代需求','172.16.101.3'),
('8543b5175b3640ea88f214550d3ffbb9','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-18 00:45:45','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('856ce82ffd86497bb718e2341ce6c2ff','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-07-10 17:27:51','1','发布成功','rz-service-content','协议分表','172.16.101.9'),
('85804cbd805145dabb9dbfe4f61f93e9','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-05-03 21:39:51','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('8588df14e17543acb3c0a5d13224255c','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-06-26 23:40:56','1','发布成功','rz-service-customer','','172.16.101.8'),
('85fa7ae6c36848229fdec711f853aa3c','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-09 19:38:54','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('86d73210d014437fb46560c4808a1002','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redemptio','7b92ba85373f4315a7b9020c7c0227d5','release','all','2018-09-11 21:05:51','1','发布成功','rz-service-redemption','boss后台：黑名单配置界面','172.16.101.19'),
('86e918022f8146848bfe0ab887eb345a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-09-14 00:38:45','1','发布成功','rz-service-account','','172.16.102.6'),
('86ff665b962d4381b9970b866c9b147e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-07-10 19:50:38','1','发布成功','rz-web-boss','','172.16.101.3'),
('876f1302459145309a06309d506ee379','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-26 18:14:02','1','发布成功','rz-service-borrow','','172.16.101.7'),
('877fdbd3eb904312a5bd7c278e22a06d','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-07-10 19:48:33','1','发布成功','rz-service-customer','','172.16.103.8,172.16.104.8'),
('87819626c3184a09a5edb8be69c44253','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-04-05 04:27:15','1','发布成功','rz-service-customer','','172.16.103.8,172.16.104.8'),
('87ad06a676f74853a0b9e09f54c82e92','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-05-17 18:25:09','1','发布成功','rz-service-customer','官网信息披露的自然人借款人信息（身份证号码和手机号）需要进行脱敏处理','172.16.103.8,172.16.104.8'),
('88174eb27a56495ca722528910a1466d','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-04-13 11:04:42','1','发布成功','rz-web-boss','平台转个人查询条件新增UID
自动上标','172.16.101.3'),
('887a2c1a036a4bbd8cca70b720249776','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-01 02:00:32','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('88f128fba95f4a34a498a2a05ac8bd4a','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-26 15:16:29','1','发布成功','rz-service-borrow','协议：图片改为pdf','172.16.102.7,172.16.101.7'),
('899f8fba804f492ca86b30b1c3ba5dbd','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-18 16:17:25','1','发布成功','rz-service-borrow','展期过滤黑名单用户','172.16.103.7,172.16.104.7'),
('8a9806c6428749afb9fc932381935805','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-06-05 19:47:51','1','发布成功','rz-service-taskoffline','','172.16.101.23'),
('8adfef05ed3343dcbb48aa0561e7b71c','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-07-24 19:00:25','1','发布成功','rz-web-app','','172.16.101.1'),
('8b260262f113438abe4139315439ac7b','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-07-24 16:06:09','1','发布成功','rz-service-taskoffline','数据大屏;长连接改造','172.16.101.23'),
('8b3620f3a1dd4e1f80ce956a229a2ba4','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-06-26 23:50:10','1','发布成功','rz-web-pc','','172.16.101.2'),
('8b3907d520a44a43b1241a1f1cf7c793','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-30 15:24:46','1','发布成功','rz-service-borrow','','172.16.101.7'),
('8b8efded0f2e4cd3b64e305e51484de7','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-05-24 18:50:29','1','发布成功','rz-service-task','','172.16.104.12,172.16.103.12'),
('8c21d009c2da4b749117bb981d2ab338','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-05-31 19:46:39','1','发布成功','rz-service-borrow','系统短信按照短信内容 做不同渠道发送','172.16.102.7,172.16.101.7'),
('8cdbceeb1b944e868d9abf948bb5692d','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-28 18:19:47','1','发布成功','rz-service-borrow','债转协议
借款协议部分信息内容脱敏
提前还款协议','172.16.102.7,172.16.101.7'),
('8cfe1e8a1df34fb4b6961187b079dfbe','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-04-03 22:47:23','1','发布成功','rz-service-content','','172.16.102.9'),
('8d16750eebb74b6d8e125a152ab580ff','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-19 20:08:44','1','发布成功','rz-service-redpacket','','172.16.101.10'),
('8d1d4a4bf8684df4a02c9f7592c01be5','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-04-19 16:19:11','1','发布成功','rz-service-rplan','口袋记账第三方对接','172.16.102.14,172.16.101.14'),
('8dd061899fe44b47b5a69f9be829b7ad','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-26 23:25:13','1','发布成功','rz-service-borrow','','172.16.101.7'),
('8e00d98f74a542729a72d9a8465684ae','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-06-28 19:18:58','1','发布成功','rz-service-account','','172.16.101.6'),
('8eaeb83260474a9a8f9ade3e738a2b40','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-08-21 20:16:27','1','发布成功','rz-service-account','springboot 改造','172.16.102.6'),
('8f8e0fb06f5549bcb9f935e3f0de248a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-05-22 19:35:25','1','发布成功','rz-web-boss','','172.16.101.3'),
('8fb4b1ebcf6f476ea45d1e185d147faa','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-provide','acf68ee3993641d5b029a205ba7da108','release','all','2018-08-10 17:40:49','1','发布成功','rz-web-provide','','172.16.101.21'),
('8fbf55adf73240fda34cfbed512dcdd1','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-02 18:04:23','1','发布成功','rz-service-task','','172.16.101.12'),
('90d10b0bcc114fa8acc5905e8649f69e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-04 22:51:43','1','发布成功','rz-service-redpacket','','172.16.104.10,172.16.103.10'),
('90d6d94824aa42cb9bae9705d7191e3e','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-09-06 15:50:50','1','发布成功','rz-service-task','boss后台展期操作界面增加筛选框','172.16.102.12,172.16.101.12'),
('9185160ce6044b34b2dd116341848019','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-09-18 18:29:55','1','发布成功','rz-web-boss','','172.16.101.3'),
('9195dc4e45b74926afe1e7544e1af04a','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-08-21 16:45:02','1','发布成功','rz-service-bidweb','对标系统180817优化','172.16.101.24'),
('91fffe3233764d8896b11acecf40d5f6','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-02 19:41:30','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('92b816b214c549839e3166baadb88fa4','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-07-10 17:32:07','1','发布成功','rz-service-task','协议分表
R计划技术优化','172.16.104.12,172.16.103.12'),
('934da9292bca4e73a967ad6945fddfa5','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-07-10 20:42:55','1','发布成功','rz-web-app','','172.16.102.1,172.16.101.1,172.16.103.1'),
('936ef4cc09f3474ca078d5b161bbe3da','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-09-07 05:40:39','1','发布成功','rz-web-pc','','172.16.102.2'),
('952233636c89483985b01b4bd483c228','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-19 20:44:04','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('9539e0a1dc404c08a81ac80a1c355046','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-09-11 20:48:36','1','发布成功','rz-service-account','boss后台自动体现取消最新金额限制','172.16.102.6'),
('95b24fa981bd4055b214a6d9faf9ee0a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-06-26 23:40:09','1','发布成功','rz-service-content','','172.16.102.9'),
('95c363858e414427881c315f80445163','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-02 18:05:09','1','发布成功','rz-service-task','','172.16.102.12,172.16.103.12'),
('963adf99b0204b24a6509909430846ed','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-03-21 22:37:54','1','发布成功','rz-service-third','',''),
('9652845fb95240a5928f595f7be0d3dc','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-06-27 19:23:11','1','发布成功','rz-service-bidweb','','172.16.101.24'),
('967ebe034a154d71ab1236a34839698c','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-09-14 17:56:33','1','发布成功','rz-service-customer','boss后台黑名单优化','172.16.101.8,172.16.102.8'),
('96a837d98b4745b5b0ef5a6ba76d546a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-08-07 19:56:33','1','发布成功','rz-service-customer','','172.16.103.8,172.16.102.8,172.16.104.8'),
('96f15cda60404d7ab35019ce94f7128a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-03 23:03:12','1','发布成功','rz-service-task','','172.16.104.12,172.16.103.12'),
('9719a413a999429ca02580a6e43dd0c2','','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-03-13 17:58:02','1','发布成功','rz-web-app','deploy
101.1
102.1',''),
('9771ce97bec94c7e8f1c67cd300f6f7a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-07-26 19:52:22','1','发布成功','rz-service-account','','172.16.102.6'),
('97addc10d32c4e1f81c7e45b37f9d614','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-04-03 23:04:56','1','发布成功','rz-service-taskoffline','','172.16.101.23'),
('97e0f7c301864cf59e3299d875c9bba0','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-07-22 02:50:53','1','发布成功','rz-web-app','','172.16.104.1,172.16.102.1,172.16.105.1,172.16.103.1'),
('9822ebe9d52244f9a315da7c73488081','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-06-27 06:45:44','1','发布成功','rz-web-boss','','172.16.101.3'),
('9885b05fb7104775889e9c57df650933','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-03-22 02:47:37','1','发布成功','rz-web-app','获取渠道来源',''),
('98fa2a16b86742999d792e6a3307facd','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-07 20:57:32','1','发布成功','rz-service-borrow','彩虹桥二期','172.16.103.7,172.16.104.7'),
('994226d6c3b54e64a2e9b4418d7672e6','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-03-20 16:58:18','1','发布成功','rz-service-borrow','迭代优化',''),
('99d57400ab1440819d0e622a9daa65de','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-09-07 05:24:37','1','发布成功','rz-service-customer','','172.16.101.8'),
('9a08b4d5ed8c43708b0e9e3a41034931','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-05-03 21:00:26','1','发布成功','rz-service-task','','172.16.104.12,172.16.103.12'),
('9a0b4ee4dc5c4eac8292eef1edef2db9','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-07-19 19:49:19','1','发布成功','rz-service-taskoffline','','172.16.101.23'),
('9a43b747dc37422986ccbbbfa5f5d123','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-09-04 19:50:40','1','发布成功','rz-web-boss','展期优化 平台数据优化','172.16.101.3'),
('9a580607c87847849a607bbdb8337e2b','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-25 18:24:37','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('9a72f41d14ca4003814655a58fc9839b','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-07-31 22:29:56','1','发布成功','rz-service-customer','','172.16.101.8,172.16.102.8,172.16.104.8'),
('9afbf927d1b846aeb0e91041c4b7c013','','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-03-15 17:54:29','1','发布成功','rz-service-task','rz-service-task',''),
('9b94962416694ad7a66edce3f8b8cc34','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-provide','acf68ee3993641d5b029a205ba7da108','release','all','2018-08-23 17:35:51','1','发布成功','rz-web-provide','springboot 改造','172.16.101.21'),
('9c159e6f78f144c595cb7a93f351bede','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-06-27 18:51:24','1','发布成功','rz-web-app','','172.16.104.1,172.16.106.1,172.16.102.1,172.16.105.1,172.16.103.1'),
('9d593f3913834e5ca18a32119efbf9c4','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-07-24 17:49:35','1','发布成功','rz-service-task','boss后台生成未脱敏协议
加息卷发放功能，后台查询列表 
提现审核优化','172.16.102.12,172.16.101.12'),
('9d5d256209354bddbac6c193a899f38c','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-07-05 17:09:23','1','发布成功','rz-web-redemption','将原推送至Rebuild的mq替换为java的mq地址','172.16.101.5'),
('9e64b187147e46f29e15b8c00d737879','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-07-12 19:33:43','1','发布成功','rz-service-checkbid','','172.16.101.20'),
('9e8276d8e46f4fcd8597b91117a4a920','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-25 15:08:26','1','发布成功','rz-service-borrow','','172.16.101.7'),
('9f286aa882c94940826b4e58e595ce41','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-06-25 21:08:43','1','发布成功','rz-service-bidweb','','172.16.101.19'),
('9f482de9a717404e81a8f7f7fc28cbeb','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-06-28 19:19:55','1','发布成功','rz-service-account','','172.16.102.6'),
('9f6d8d9e52c240f4b83d0d55c91b6428','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-18 18:27:36','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('9fa5fb46782248a5bbbb7c00d5661631','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-08-16 00:16:48','1','发布成功','rz-service-checkbid','','172.16.101.20'),
('a06be1e52a4b45f5a257e502c5a50e87','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-07-26 19:51:03','1','发布成功','rz-service-account','','172.16.101.6'),
('a08885bea3f84f82b6b6f6f85f3815f2','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-callback','b47613d484c94327a6f4991654f52032','release','all','2018-08-09 15:19:40','1','发布成功','rz-web-callback','受托支付关闭影响业务的解决方式','172.16.103.4,172.16.102.4'),
('a098732455f6467c9d36357c8a88a8b8','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-28 18:20:36','1','发布成功','rz-service-borrow','债转协议
借款协议部分信息内容脱敏
提前还款协议','172.16.103.7,172.16.104.7'),
('a09e1b2d260a4a83b48bcd03753f8a2e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-07-12 21:36:33','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('a0b67f70c5b145d2ae06c31a9010ff87','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-04-03 17:52:05','1','发布成功','rz-service-content','主站首页banner图连接地址修改','172.16.101.9'),
('a23e4396ab32405da72b6d45e383840d','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-07-03 15:31:25','1','发布成功','rz-service-task','2.0协议合规内容调整: 协议修改和经常居住地/注册地脱敏需','172.16.102.12,172.16.101.12'),
('a244f382e44f43329d09191c08b93bef','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-taskcompa','9d0759ff802c4331916fc124c08e7c1b','release','all','2018-09-11 17:33:06','1','发布成功','rz-service-taskcompare','restart','172.16.101.18'),
('a28447cc1d064dd09575baed43ce1dc0','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-18 16:16:28','1','发布成功','rz-service-borrow','展期过滤黑名单用户','172.16.102.7,172.16.101.7'),
('a2fd987241d84223b2500acf03b49341','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-04-26 11:35:00','1','发布成功','rz-web-app','配合IOS审核
APP迭代需求','172.16.104.1,172.16.106.1,172.16.105.1,172.16.103.1'),
('a309cd9f44e2459ca188f04fc312e01a','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-07-24 17:55:24','1','发布成功','rz-web-boss','加息卷发放功能，后台查询列表
boss后台生成未脱敏协议','172.16.101.3'),
('a3890ff65fb7447c9ace88b9548db605','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-06-05 19:50:15','1','发布成功','rz-service-customer','','172.16.103.8,172.16.104.8'),
('a3ac0a1cb81249748417da9c6e7c5149','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-14 21:25:21','1','发布成功','rz-service-task','','172.16.102.12,172.16.103.12'),
('a3f4cdac6e7d43cc9963b2c760fc54a5','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-05-29 16:24:26','1','发布成功','rz-service-task','优化bi当日数据统计数据校验','172.16.102.12,172.16.101.12'),
('a445451a69804990b42941cdac0f9a22','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-07-22 02:53:38','1','发布成功','rz-web-pc','','172.16.102.2'),
('a484dadf003c452faee6ae5adc4af48f','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-06-27 08:28:27','1','发布成功','rz-web-boss','','172.16.101.3'),
('a4c546b8e3db4b979a71c228a071fad5','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-02 18:05:39','1','发布成功','rz-service-task','','172.16.104.12'),
('a4e3707c1d084d01ab457deff7c27227','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-06-26 23:39:14','1','发布成功','rz-service-content','','172.16.101.9'),
('a4e42762546e43ca9ddc7e329dbab15c','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redemptio','7b92ba85373f4315a7b9020c7c0227d5','release','all','2018-08-09 18:43:32','1','发布成功','rz-service-redemption','','172.16.102.19'),
('a57d43dbe1254080aa1b7a038d59c45c','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-04-03 18:01:12','1','发布成功','rz-service-account','周末提现到账优化','172.16.103.6,172.16.104.6'),
('a5ad1a654bd14eeca71d6c46500b36a0','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-26 11:31:37','1','发布成功','rz-service-borrow','配合IOS审核
APP迭代需求','172.16.102.7,172.16.101.7'),
('a5d64f25607a44d59978da9c778f58c7','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-27 19:19:33','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('a5fbb5b12f2040fdafd3c6c8d3b0f877','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-06-27 04:02:26','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('a63872ca1dab42a9afb06456bb598844','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-06-27 09:30:47','1','发布成功','rz-web-boss','bug','172.16.101.3'),
('a6a5120f6f3448b29bca71c43651cbaf','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-05-08 18:28:01','1','发布成功','rz-service-rplan','日志记录处理时间，便于定位问题','172.16.104.14,172.16.103.14'),
('a6c5bdabeba74afc9f31637d3f9d146d','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-08-14 22:01:29','1','发布成功','rz-web-pc','','172.16.101.2'),
('a78b22e49e154e2b91ba8e13429da506','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-08-16 00:20:03','1','发布成功','rz-web-redemption','','172.16.101.5'),
('a78c7c28b0dc4d8b95c7a8d6cc7dd316','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redemptio','7b92ba85373f4315a7b9020c7c0227d5','release','all','2018-07-05 17:08:58','1','发布成功','rz-service-redemption','将原推送至Rebuild的mq替换为java的mq地址','172.16.102.19'),
('a86bd77ed5fb4be8ae7be50ee7804228','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-04-09 14:29:40','1','发布成功','rz-service-taskoffline','信息披露--平台数据','172.16.101.23'),
('a92d9404b7844b4f9c87a5c136131779','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-04-03 22:59:43','1','发布成功','rz-web-pc','','172.16.102.2,172.16.101.2'),
('a9539e14a4dc425d878f82cedba3ceb7','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-07-10 17:28:31','1','发布成功','rz-service-content','协议分表','172.16.102.9'),
('a964fc5dd6f94d27a79908e1da244438','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-14 18:14:18','1','发布成功','rz-service-borrow','投资失败bug修复','172.16.103.7,172.16.104.7'),
('a9df1ad938c84f50add976b8ac4cff40','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-28 10:41:57','1','发布成功','rz-service-borrow','回款日历优化','172.16.102.7,172.16.101.7'),
('aa13b1eaf0a14b4284a3bf1b49903eee','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-04-12 18:20:32','1','发布成功','rz-service-taskoffline','金智塔
登录 按月披露
按日披露','172.16.101.23'),
('aa26a4a2e66642fab04e9cef00e6f297','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-31 19:48:32','1','发布成功','rz-web-boss','','172.16.101.3'),
('aa2ef1a5194149339fe20d89fedaa6ef','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-27 09:54:09','1','发布成功','rz-service-borrow','Android标的详情进度精度问题bug','172.16.103.7,172.16.104.7'),
('aa3e079c72494f85918344a8492d2913','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-09-01 02:04:38','1','发布成功','rz-web-boss','','172.16.101.3'),
('aa6782886f0042db8a4a8b575b2f163c','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-05-15 19:02:45','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('aa8ef926f30e45bdbf1991df7edcfdd6','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-05 19:35:02','1','发布成功','rz-service-borrow','','172.16.101.7'),
('ab5d75278e8e4fa38cf7a34c8cef4055','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-10 17:30:11','1','发布成功','rz-service-borrow','R计划技术优化
	债转定向开启需求','172.16.103.7,172.16.104.7'),
('abc6bc8d956547cc9b6f503b9a141e70','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-07-05 19:26:58','1','发布成功','rz-web-pc','邀请好友增加历史排行榜','172.16.101.2'),
('ac6767390e3142e09743b55f3ca8b577','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-03 11:30:14','1','发布成功','rz-web-boss','jar包误删，导致解析excel异常','172.16.101.3'),
('accce48ae7f44e089e343803be8f5303','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-taskcompa','9d0759ff802c4331916fc124c08e7c1b','release','all','2018-09-11 17:33:52','1','发布成功','rz-service-taskcompare','restart','172.16.102.18'),
('ad08addd0bba470a9d3450afd167330d','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-05-31 19:43:23','1','发布成功','rz-service-content','	系统短信按照短信内容做不同渠道发送','172.16.101.9'),
('ae0673f1c2c441b0abb8315b16a8dee8','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-04-12 20:30:40','1','发布成功','rz-service-rplan','','172.16.104.14,172.16.103.14'),
('af64c6947e7a406e8d5da2291978f804','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-03 18:51:06','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('af7cd6b793564903b205a131d0196b2a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-18 15:54:24','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('b00e51ceb96a4aa19cd4c99a82cae734','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-04-09 19:41:18','1','发布成功','rz-service-rplan','','172.16.102.14,172.16.101.14'),
('b02d2b301f424823a38fc949f86c647b','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-06-27 09:02:30','1','发布成功','rz-web-boss','bug','172.16.101.3'),
('b040418cfc1148cba4941ca11e827c07','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-26 18:14:46','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.103.7,172.16.104.7'),
('b0fa59669eb5411daf2b41cf8a1e6c4e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-09-07 05:33:35','1','发布成功','rz-web-app','','172.16.102.1,172.16.101.1'),
('b139bb47151a444fb337925c44978a5f','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-08 19:22:10','1','发布成功','rz-service-redpacket','','172.16.102.10'),
('b149f4c8a69b4050b323b8e8181b925e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-08-14 21:27:29','1','发布成功','rz-service-third','','172.16.101.11'),
('b1756720ec9c448684743bd647cf768a','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-provide','acf68ee3993641d5b029a205ba7da108','release','all','2018-07-12 17:38:54','1','发布成功','rz-web-provide','与第三方数据对接，优化时间格式，','172.16.101.21'),
('b1cd40fb9e974b3fb60f4e54c7177cc0','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-09-14 16:54:51','1','发布成功','rz-service-account','MQ技术改造','172.16.102.6'),
('b1f1d051c91f4632869157c249c5b4d4','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-09-14 17:58:42','1','发布成功','rz-service-account','自动提现优化','172.16.101.6'),
('b2420186d4804145b7e652f07df77996','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-09-07 05:26:12','1','发布成功','rz-service-customer','','172.16.103.8,172.16.102.8,172.16.104.8'),
('b24d63fafed2447ea4557e5c1e8d8b33','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-03-20 17:00:35','1','发布成功','rz-service-borrow','迭代优化',''),
('b2f9282576df4f7db6b3c514f3b02c24','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-04 22:34:08','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('b32fa0d1bac34d1389577e5b448f422e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-06-28 18:47:46','1','发布成功','rz-service-content','','172.16.101.9'),
('b3555eca19de4dd4a224d45136d0226d','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-04-12 20:41:18','1','发布成功','rz-web-pc','','172.16.102.2'),
('b39a29b3e4144cb2947c573aa61186f2','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-07-19 20:52:39','1','发布成功','rz-web-boss','','172.16.101.3'),
('b441a7074e814c7b81abc7da7b48e0a1','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-08-21 16:44:07','1','发布成功','rz-service-checkbid','对标系统180817优化','172.16.101.20'),
('b4a8f5180fb2486e89c4d067ef972327','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-31 19:45:35','1','发布成功','rz-service-borrow','','172.16.101.7'),
('b4c9f43980f04639a212bf643884f3d3','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-03 15:27:09','1','发布成功','rz-service-borrow','2.0协议合规内容调整: 协议修改和经常居住地/注册地脱敏需','172.16.103.7,172.16.104.7'),
('b5afef8db9b149f0b771dd41737e8f92','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-06-25 15:40:23','1','发布成功','rz-service-checkbid','','172.16.101.20'),
('b6d919c53ae4469b8f4b7629454a2315','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-06-26 23:13:50','1','发布成功','rz-service-account','','172.16.101.6'),
('b735dbdc5ba34440bba22d0cd3931082','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redemptio','7b92ba85373f4315a7b9020c7c0227d5','release','all','2018-09-11 21:06:52','1','发布成功','rz-service-redemption','boss后台：黑名单配置界面','172.16.102.19'),
('b7d7d311f3944479a3b4fe270275e78d','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-ups','3f2f7c6b5eb24ccea5d1047e2a959a96','release','all','2018-07-10 20:39:47','1','发布成功','rz-web-ups','','172.16.101.22'),
('b9425d91efd44b53be297adc7ca5e113','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-07-26 16:12:41','1','发布成功','rz-web-app','协议：图片改为pdf','172.16.102.1,172.16.101.1,172.16.103.1'),
('b9e69cef3a25438e8b87ca02eb4fd989','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-ups','3f2f7c6b5eb24ccea5d1047e2a959a96','release','all','2018-06-19 23:17:46','1','发布成功','rz-web-ups','','172.16.101.22'),
('b9f3a9b709d949d4b4ef4586d918dc09','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-05-31 19:11:47','1','发布成功','rz-service-third','','172.16.101.11'),
('bb270f27e6724000861ff3177acf8d2e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-07-19 20:51:25','1','发布成功','rz-web-app','','172.16.104.1,172.16.106.1,172.16.105.1'),
('bbc88b3134844537b23baba37e80372c','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-05-31 19:47:42','1','发布成功','rz-service-borrow','系统短信按照短信内容做不同渠道发送','172.16.103.7,172.16.104.7'),
('bbe4a5811bea4b088d307394d26d8acc','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-09-01 02:03:35','1','发布成功','rz-web-app','','172.16.104.1,172.16.106.1,172.16.105.1,172.16.103.1'),
('bc8b61940b594c53a5836e86334e4332','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-27 04:09:17','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('bcff8512582c4ca082aefa0223bee0f2','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-06-27 03:13:32','1','发布成功','rz-service-task','','172.16.104.12,172.16.103.12'),
('be1dff138585470da70d8bbfa6fe4dcd','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-09-04 18:28:40','1','发布成功','rz-service-task','技术优化，去掉数据库监控配置','172.16.102.12,172.16.101.12'),
('be1ff584fb3a42cbb1083330631d1b7e','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-provide','acf68ee3993641d5b029a205ba7da108','release','all','2018-07-12 15:16:31','1','发布成功','rz-web-provide','网贷之家，网贷天眼提前还款接口','172.16.101.21'),
('be487c4aa73f41d9b0887d88786cd89b','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-accountlo','4d0674633fc8424bb44075597166157c','release','all','2018-04-18 00:10:36','1','发布成功','rz-service-accountlog','','172.16.101.16'),
('bf78a4b5cd36472fb489762525ef1027','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-05-03 21:41:50','1','发布成功','rz-service-rplan','','172.16.104.14,172.16.103.14'),
('bf86f333e5ec4cd1a4f2225fe5cb1f60','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-28 14:40:42','1','发布成功','rz-web-boss','boss后台增加手工废标','172.16.101.3'),
('bf999571fb6b4821833e3d5d8daf7499','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-05-24 18:31:20','1','发布成功','rz-service-content','','172.16.102.9'),
('c00750f94aad45b48fd00c7341eadc40','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-07-24 17:52:05','1','发布成功','rz-service-task','boss后台生成未脱敏协议
加息卷发放功能，后台查询列表 
提现审核优化','172.16.104.12,172.16.103.12'),
('c012c65771fe4ac18247f327f915d12f','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-consumer','c0097a800e784e42bb7cc7b94cd69113','release','all','2018-07-10 17:33:18','1','发布成功','rz-service-consumer','R计划技术优化','172.16.101.13,172.16.102.13'),
('c05ff017daba40a49df059e5a745b3a0','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-06-28 18:55:06','1','发布成功','rz-service-customer','','172.16.101.8,172.16.102.8'),
('c1077a82e833409abe3266a4d353f5ad','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-04-12 20:45:13','1','发布成功','rz-web-app','','172.16.104.1,172.16.106.1,172.16.105.1'),
('c12c7da2faad48bfb25ac3b8ed4fb518','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-provide','acf68ee3993641d5b029a205ba7da108','release','all','2018-03-29 21:11:31','1','发布成功','rz-web-provide','','172.16.101.21'),
('c1552fa7bf21404f9b6cc825e1ffae18','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-18 00:12:32','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('c180142e464d400ba4d035a44971b2cb','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-07 17:58:08','1','发布成功','rz-service-borrow','springboot技术改造','172.16.102.7,172.16.101.7'),
('c191672ee1f0441bac234367f18c3abb','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-05-17 18:24:05','1','发布成功','rz-service-customer','官网信息披露的自然人借款人信息（身份证号码和手机号）需要进行脱敏处理','172.16.101.8,172.16.102.8'),
('c4064f09d7bd45e9b39aa926f58c09e2','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-04-28 18:18:21','1','发布成功','rz-service-content','债转协议
借款协议部分信息内容脱敏
提前还款协议','172.16.101.9'),
('c46ebdc3d13b422bbeeb2c1f42341eb9','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-07-12 21:37:21','1','发布成功','rz-service-task','','172.16.104.12,172.16.103.12'),
('c48169a0ceed450d844703d8b90bb46d','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-22 02:44:50','1','发布成功','rz-service-borrow','','172.16.101.7'),
('c48bdd17e3234895b6247938743ff7f8','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-04 19:46:45','1','发布成功','rz-service-borrow','展期优化','172.16.102.7,172.16.101.7'),
('c5de02232d0a4439b43528edb13a8c71','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-07-31 18:17:26','1','发布成功','rz-service-checkbid','兑标协议配合第三方签章优化','172.16.101.20'),
('c6f9ccfc755a41e0bc9eefe7e86a389b','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-06-28 18:56:52','1','发布成功','rz-service-checkbid','','172.16.101.20'),
('c7179dac6bc84f9f9a0e0d27865d40b6','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-provide','acf68ee3993641d5b029a205ba7da108','release','all','2018-06-26 23:57:30','1','发布成功','rz-web-provide','','172.16.101.21'),
('c738993fabd44cb1a91a57ae12e03532','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-05-03 21:53:38','1','发布成功','rz-service-taskoffline','','172.16.101.23'),
('c87ab398cb4748ac9f610b69e4e387b8','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-05-08 18:33:10','1','发布成功','rz-service-redpacket','邀请好友后台现金查询','172.16.101.10'),
('c8a89e1fc45b460986f2b51672e0b0eb','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-04 22:35:12','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('c9154d158afc4953b17d76372bf433cc','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-08-09 18:10:48','1','发布成功','rz-service-customer','','172.16.101.8'),
('ca3be28ae2ce4c18a9867ddeb0e2f756','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-08-09 19:26:36','1','发布成功','rz-service-third','boss后台短信管理','172.16.103.11,172.16.102.11'),
('ca42f0b144c64422a54e3252abfcaa13','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-07-12 21:33:07','1','发布成功','rz-service-customer','','172.16.101.8,172.16.102.8'),
('ca4b6687a6d345339daaff83d91835ff','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-09-11 14:28:29','1','发布成功','rz-web-boss','boss后台自动提现','172.16.101.3'),
('cabc38ad18b74090aa4fa5912aa5aa50','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-08-22 10:43:43','1','发布成功','rz-service-account','昨天发错老包','172.16.101.6'),
('cb48929c64c14cb4a9ee7e529d4ccc99','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-ups','3f2f7c6b5eb24ccea5d1047e2a959a96','release','all','2018-06-19 23:12:21','1','发布成功','rz-web-ups','','172.16.101.22'),
('cb7f9e0b9e704f89be9b94136a62399f','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-07-22 02:52:10','1','发布成功','rz-web-pc','','172.16.101.2'),
('cbfde695d7ba41269fdf00e497906784','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-05-17 18:22:22','1','发布成功','rz-service-account','部分老数据，账户信息完善','172.16.102.6'),
('cc2f1a1b7f8f4e2687a195473532f1b4','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-07-03 21:26:38','1','发布成功','rz-service-task','','172.16.104.12,172.16.103.12'),
('cc318526480d46178a74928bbd334308','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-05-08 14:32:11','1','发布成功','rz-service-taskoffline','','172.16.101.23'),
('cca7e4dc7d534f818f2bf07af4110f41','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redemptio','7b92ba85373f4315a7b9020c7c0227d5','release','all','2018-08-09 15:16:42','1','发布成功','rz-service-redemption','受托支付关闭影响业务的解决方式','172.16.102.19'),
('cd166333b10d47d586039c8cab43d244','','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-bi','9d0f99c5f18e4496a80322f8320aa393','release','all','2018-03-19 15:33:58','1','发布成功','rz-web-bi','',''),
('cd88a4c77b544da091b97ca666c7db91','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-04-19 16:21:16','1','发布成功','rz-service-rplan','口袋记账第三方对接','172.16.104.14,172.16.103.14'),
('cd8a9bf7eb044b45ae0a4bffc5e5a075','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-04-12 20:29:44','1','发布成功','rz-service-rplan','','172.16.102.14,172.16.101.14'),
('cd9cbef0be794eb299d352c791311d2e','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-04 14:47:44','1','发布成功','rz-service-redpacket','短信模板问题修复','172.16.101.10,172.16.102.10'),
('ce5e3b1d58c54c7e883c41b0c509b3ef','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-04-03 22:49:56','1','发布成功','rz-service-customer','','172.16.101.8,172.16.102.8'),
('ce6756114d294b588bb092bbd50c60fd','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-29 19:02:39','1','发布成功','rz-web-boss','','172.16.101.3'),
('ce74893892934191acbb6f19f578fc0b','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-07-17 16:25:32','1','发布成功','rz-web-redemption','','172.16.101.5'),
('cf17b16db7ef4f61a249a144b8d41322','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-09-04 19:48:38','1','发布成功','rz-web-app','平台数据优化','172.16.102.1,172.16.101.1,172.16.103.1'),
('cf424e8423be40068316b344b3845087','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-provide','acf68ee3993641d5b029a205ba7da108','release','all','2018-04-12 18:22:06','1','发布成功','rz-web-provide','金智塔
登录 按月披露
按日披露','172.16.101.21'),
('d049f48568c646a3993f59d2f12dfd73','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-06-26 23:56:37','1','发布成功','rz-web-boss','','172.16.101.3'),
('d04e8fcbbcd7469887e432a9cb72b268','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-09-07 05:42:11','1','发布成功','rz-web-boss','','172.16.101.3'),
('d081e324f6d3470ba8a7c788cb472444','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-09-07 05:21:03','1','发布成功','rz-service-content','','172.16.102.9'),
('d0919ffaa316415facf53fbf9285efcc','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-06-27 06:13:24','1','发布成功','rz-web-boss','','172.16.101.3'),
('d0ad63e8fd354788adfe61ffc19b8d26','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redemptio','7b92ba85373f4315a7b9020c7c0227d5','release','all','2018-09-14 16:58:41','1','发布成功','rz-service-redemption','MQ技术改造','172.16.101.19'),
('d0d67a4230754213bcbda75b4dc6c5e5','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-04 19:47:30','1','发布成功','rz-service-borrow','展期优化','172.16.103.7,172.16.104.7'),
('d0d883bcd1be4e65bd970e669b8404a2','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-04-12 20:34:34','1','发布成功','rz-service-content','','172.16.101.9'),
('d1861defa92742ac97ad2d943e04327c','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-24 20:20:08','1','发布成功','rz-web-boss','展期配置','172.16.101.3'),
('d1928360f6c5434dafbc5af26c9669c3','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-26 18:27:24','1','发布成功','rz-service-borrow','回款日历优化','172.16.102.7,172.16.101.7'),
('d1a3aebd1ba846e6a55fe6361a019489','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-09 19:40:08','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('d1aa8cce9ebe496284aaf4c4bf4c2df6','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-25 18:22:12','1','发布成功','rz-service-borrow','','172.16.102.7'),
('d2b8435cbe4b48599639f886c7070273','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-30 10:06:39','1','发布成功','rz-web-boss','boss后台提前还款优化','172.16.101.3'),
('d2bf4ba13d6248509814c0ebba7bb1d7','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-04-18 16:09:47','1','发布成功','rz-web-boss','','172.16.101.3'),
('d360d9bff9694a549f002156af54d550','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-ups','3f2f7c6b5eb24ccea5d1047e2a959a96','release','all','2018-06-19 23:13:42','1','发布成功','rz-web-ups','','172.16.101.22'),
('d3afaf4f35c04ba3a957cb47df12dcbd','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-consumer','c0097a800e784e42bb7cc7b94cd69113','release','all','2018-07-10 17:34:30','1','发布成功','rz-service-consumer','R计划技术优化','172.16.104.13,172.16.103.13'),
('d522c6544ecc407e8ca27af3647213a4','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-05-31 18:42:51','1','发布成功','rz-service-task','','172.16.104.12,172.16.103.12'),
('d6a94cd247c74cafa227ece9f8c191a0','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-05-08 18:35:11','1','发布成功','rz-service-redpacket','邀请好友后台现金查询','172.16.102.10'),
('d711b746c0e24d77a11348cf5d1c1a32','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-09-13 18:17:58','1','发布成功','rz-web-boss','','172.16.101.3'),
('d76ec7ba9ea041db80c770bbefb81828','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-08 19:26:34','1','发布成功','rz-service-task','','172.16.104.12,172.16.103.12'),
('d7ca25529cb845f4bd52fffb4993784c','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-19 21:22:20','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('d7f58a7fb9db4f4aaf2b812be751cff4','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-callback','b47613d484c94327a6f4991654f52032','release','all','2018-06-26 23:55:23','1','发布成功','rz-web-callback','','172.16.103.4,172.16.102.4'),
('d8723a3fad1948979e0a37a62da941db','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-05-03 21:38:38','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('d88b32f527f7436882a13150cc56912b','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-06-26 23:44:45','1','发布成功','rz-service-third','','172.16.101.11'),
('d8bfb9511cdf4c339be0c06b1fa5c98d','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-06-28 19:21:51','1','发布成功','rz-web-pc','','172.16.102.2,172.16.101.2'),
('d8ef71dcc38242edba82ecc5f2a11194','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-04 23:13:39','1','发布成功','rz-service-task','','172.16.102.12,172.16.101.12'),
('da7533139a1646a18de6e7d6506e1a07','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-accountlo','4d0674633fc8424bb44075597166157c','release','all','2018-08-21 20:32:09','1','发布成功','rz-service-accountlog','springboot 改造','172.16.101.16'),
('da81e4079d254769a84b1baae36c810a','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-05-17 18:21:11','1','发布成功','rz-service-account','部分老数据，账户信息完善','172.16.101.6'),
('db1c9fe607b74a0f88e9aba38e98f778','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-06-05 19:49:33','1','发布成功','rz-service-customer','','172.16.101.8,172.16.102.8'),
('db2e03b9daa94d4abe9bcb90bd7243cc','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-10 17:29:39','1','发布成功','rz-service-borrow','债转定向开启需求
R计划技术优化','172.16.102.7,172.16.101.7'),
('db4f70abade842378c7e5df91ea403ce','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-03 15:25:25','1','发布成功','rz-service-borrow','2.0协议合规内容调整: 协议修改和经常居住地/注册地脱敏需','172.16.102.7,172.16.101.7'),
('db8f18445b6343029693a528d4c829ac','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-09-07 05:38:16','1','发布成功','rz-web-pc','','172.16.101.2'),
('dbc7ac646e814ad08b36f7a2a1faf874','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-19 20:13:02','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('dc1027c5cd9b403a9a89558496009cb2','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-04 22:50:44','1','发布成功','rz-service-redpacket','','172.16.101.10,172.16.102.10'),
('dc6b79bdc7454b9eaa726b2d32036c77','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-04-03 23:08:05','1','发布成功','rz-service-rplan','','172.16.104.14,172.16.103.14'),
('dc965d87252e4b7a9d3a1d7d02b67d1a','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redemptio','7b92ba85373f4315a7b9020c7c0227d5','release','all','2018-09-04 18:33:15','1','发布成功','rz-service-redemption','springboot技术改造','172.16.102.19'),
('dcbfe25d1daf4add82ae35a5372a170b','','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-03-16 13:52:35','1','发布成功','rz-web-boss','20180316',''),
('dcfa21c9105a47609faf28516cc9d0e4','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-18 15:53:44','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('dd0d9ea38131446bbf6679c5a278d896','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-16 00:21:25','1','发布成功','rz-web-boss','','172.16.101.3'),
('de1696e43e204641aaa71a19852bad67','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-04-19 16:16:55','1','发布成功','rz-service-third','口袋记账第三方对接','172.16.103.11,172.16.102.11'),
('de4bf6a9af414add8d072416080453fe','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-09 19:27:49','1','发布成功','rz-web-boss','boss后台短信管理','172.16.101.3'),
('de8e5fb13aa842f88af652b4efe57829','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-03 18:12:20','1','发布成功','rz-service-task','周末提现在工作日审批后能够有限到账','172.16.104.12,172.16.103.12'),
('deb88053b17c4950bb4c377eeef47772','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-05-10 18:14:33','1','发布成功','rz-service-third','承接债权银行超时处理','172.16.103.11,172.16.102.11'),
('dec2dd7fbc8d41d3bb4dd752cebe4b82','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-08-09 19:23:53','1','发布成功','rz-service-task','bi手机版H5页面数据sql优化','172.16.104.12,172.16.103.12'),
('df17b4b458a14631a3bf21bc3e84c209','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-08-09 18:12:33','1','发布成功','rz-service-customer','','172.16.103.8,172.16.102.8,172.16.104.8'),
('dfb67fea3bbd455f8ae8e07e03438c67','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-provide','acf68ee3993641d5b029a205ba7da108','release','all','2018-04-18 00:24:53','1','发布成功','rz-web-provide','','172.16.101.21'),
('dfcda2a3228c4d079cffc278cb86aecf','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-09-13 18:16:18','1','发布成功','rz-service-customer','','172.16.103.8,172.16.102.8,172.16.104.8'),
('dfd91e49edce4344b615d22c6e171b40','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-05-29 20:05:29','1','发布成功','rz-service-rplan','标的进度优化','172.16.104.14,172.16.103.14'),
('e0a73acd9efa4e8ebbb1253739fdf1f1','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-taskcompa','9d0759ff802c4331916fc124c08e7c1b','release','all','2018-08-23 17:40:37','1','发布成功','rz-service-taskcompare','springboot 改造','172.16.102.18'),
('e0d3966ae3964ea8a8996fe4abed8292','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-26 16:10:16','1','发布成功','rz-service-borrow','协议：图片改为pdf','172.16.103.7,172.16.104.7'),
('e176b086316c48f19c6171c543fcaf33','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-04-03 22:54:48','1','发布成功','rz-service-redpacket','','172.16.104.10,172.16.103.10'),
('e193830df39e411e98f0157c03b3b6bc','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-04-18 15:56:19','1','发布成功','rz-service-customer','','172.16.103.8,172.16.104.8'),
('e27926285e994fa8a084d3fe0ef167cb','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-07-05 19:23:26','1','发布成功','rz-web-app','邀请好友增加历史排行榜','172.16.102.1,172.16.101.1,172.16.103.1'),
('e2c6b5847f24414eaefb3a1561564d2a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-consumer','c0097a800e784e42bb7cc7b94cd69113','sp','all','2018-09-14 18:39:42','1','发布成功','rz-service-consumer','','172.16.104.13'),
('e316bca3522b4296bf7b5b3707337502','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-08-02 17:59:00','1','发布成功','rz-service-account','','172.16.102.6'),
('e33a576b0dc046e3a7f990b72e33371f','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-28 22:16:44','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('e33f6b245a24461ab7b46ba104900929','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-03-21 22:38:55','1','发布成功','rz-service-third','',''),
('e3bc6483c9b84275bce5cc2cd3635783','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-09-18 17:27:51','1','发布成功','rz-web-redemption','线下还款mq补发','172.16.101.5'),
('e4bb3288f09947749c9479e17515fe3e','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-05-08 18:35:11','1','发布成功','rz-service-redpacket','邀请好友后台现金查询','172.16.102.10'),
('e53e8e694ddd4dcab554ed8097d92b72','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-04-17 18:36:22','1','发布成功','rz-service-taskoffline','金智塔
优化','172.16.101.23'),
('e591daacab274b7ea2f961e19c764d27','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-08-25 15:07:17','1','发布成功','rz-service-content','','172.16.102.9'),
('e5aaf1808aa548bb9771319dd5a84de9','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-08-25 21:17:44','1','发布成功','rz-service-content','','172.16.102.9'),
('e671f70ca49c4f969c243f04ebe79aa4','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-bi','9d0f99c5f18e4496a80322f8320aa393','release','all','2018-06-26 23:56:06','1','发布成功','rz-web-bi','','172.16.101.22'),
('e68016a0d7fd4742a7f0ee1666403446','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-31 19:47:15','1','发布成功','rz-service-borrow','','172.16.104.7'),
('e87ad633d9994a6884930605e5cbbbba','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-05-22 19:35:08','1','发布成功','rz-service-redpacket','','172.16.102.10'),
('e8cbfaf98b734b8885bd84c5ce44b087','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-04-12 20:37:33','1','发布成功','rz-service-account','','172.16.102.6'),
('e8da049504bc4bbba5ee2ca99ce0327a','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-consumer','c0097a800e784e42bb7cc7b94cd69113','release','all','2018-09-07 17:56:54','1','发布成功','rz-service-consumer','springboot技术改造','172.16.104.13,172.16.103.13'),
('e936bf66204e43e3a266234abe479119','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-25 15:18:06','1','发布成功','rz-web-boss','','172.16.101.3'),
('e98cc52052744e7d875f0bdcb3238a7e','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-26 17:42:34','1','发布成功','rz-service-borrow','展期规则配置优化','172.16.103.7,172.16.104.7'),
('ea1cc6782ae74ce4965c3640162c12a9','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-06-26 23:45:22','1','发布成功','rz-service-third','','172.16.103.11,172.16.102.11'),
('ea7b9caa7d144e07b5e9b41c90dcd710','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-08-03 11:34:17','1','发布成功','rz-web-boss','jar包误删，导致解析excel异常','172.16.101.3'),
('eaa19bedf73345c19519d0cb53415ce6','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-06-27 18:50:02','1','发布成功','rz-web-app','','172.16.101.1'),
('ead19fe0067c4a109a0482e4a76a719a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-03 18:50:14','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('ec32ede492374644a925fba000a6e4ad','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-12 14:15:54','1','发布成功','rz-service-borrow','投标异常回滚','172.16.102.7,172.16.101.7'),
('ec529b65b08641379c649a08a9f1b0b7','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-consumer','c0097a800e784e42bb7cc7b94cd69113','release','all','2018-06-26 23:37:18','1','发布成功','rz-service-consumer','','172.16.101.13'),
('ec91d75193734bda96949312731690e5','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-05-03 17:42:29','1','发布成功','rz-web-app','修改IOS审核首页隐藏因素iPhonex不支持的问题','172.16.102.1,172.16.101.1'),
('ecd4f56fdeda454c9910191d4c7562a6','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-06-25 21:09:53','1','发布成功','rz-service-bidweb','','172.16.101.19'),
('ecf64a009177426a80edae9906c148dc','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-09-11 21:12:07','1','发布成功','rz-web-boss','boss后台：黑名单配置界面','172.16.101.3'),
('ed3889d37724499fa64814e5719ab623','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-07-03 15:32:21','1','发布成功','rz-service-task','2.0协议合规内容调整: 协议修改和经常居住地/注册地脱敏需','172.16.104.12,172.16.103.12'),
('ed62e3270bf443d69ea191da85355d9d','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-04-05 02:12:43','1','发布成功','rz-service-customer','','172.16.101.8,172.16.102.8'),
('ed6e4265e79a4c07989bd5002b2790a9','','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-bi','9d0f99c5f18e4496a80322f8320aa393','release','all','2018-03-13 18:36:06','1','发布成功','rz-web-bi','',''),
('edbf8fc170b64fc28f7d597cc06e18da','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-accountlo','4d0674633fc8424bb44075597166157c','release','all','2018-08-23 17:32:34','1','发布成功','rz-service-accountlog','springboot 改造','172.16.102.16'),
('ee12603bebe9442c9dc65ece4b577aa8','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-redemption','a240928ca7d9484e969f39228a4678bc','release','all','2018-08-24 20:04:11','1','发布成功','rz-web-redemption','日志级别修改','172.16.101.5'),
('ee3f9075e8944c6bae3533ceafd2788f','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-08-10 17:38:48','1','发布成功','rz-service-taskoffline','','172.16.101.23'),
('ef1965f4461a4514a641afcfadad4ee7','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-04-12 20:39:57','1','发布成功','rz-web-pc','','172.16.101.2'),
('efcdc4521b144b83a373eaa08ed571d7','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-08-30 16:06:14','1','发布成功','rz-web-pc','springboot技术改造','172.16.101.2'),
('efd83bddabd34a458dd58b1ed73674b1','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-16 20:55:58','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('efe4393e20bf46a89fb97601b5a4a646','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-03-22 03:25:48','1','发布成功','rz-web-app','获取渠道来源',''),
('effe90f78f18496ba438c56c700f4e65','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-06-25 15:44:35','1','发布成功','rz-service-checkbid','','172.16.101.20'),
('f0718285edc8462e83388a27054cef03','','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-03-15 17:57:20','1','发布成功','rz-service-task','03
04',''),
('f0989a4a72754c39bb6e499e29c460d4','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-07-10 20:43:50','1','发布成功','rz-web-app','','172.16.104.1,172.16.106.1,172.16.105.1'),
('f16be4d6b75c4985b6dd63f8e56ae18e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-19 21:31:17','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('f1bf1951d69440568785644686074db0','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-05-15 19:03:46','1','发布成功','rz-service-task','','172.16.104.12,172.16.103.12'),
('f22e13c6866d439bb4e1b68b3987b741','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-08-14 22:19:32','1','发布成功','rz-service-account','','172.16.101.6'),
('f312eff2477b419d9ad631553d624806','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-third','3df7fcdeadf14376b26436b955242ee3','release','all','2018-07-31 22:47:16','1','发布成功','rz-service-third','','172.16.101.11'),
('f398b323e30a4ef7ba3f7325c1369f67','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-08-31 19:52:35','1','发布成功','rz-service-account','','172.16.102.6'),
('f3abecb06fc74a1fbf31d2958b00c824','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-04-17 18:41:29','1','发布成功','rz-service-account','充值处于创建状态会显示"取消提现"','172.16.101.6'),
('f3c59404aba549b0981819e402ad7c67','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-consumer','c0097a800e784e42bb7cc7b94cd69113','sp','all','2018-09-14 18:39:28','1','发布成功','rz-service-consumer','','172.16.103.13'),
('f422fa784d134649b4d27a26491f69e2','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-04-04 23:14:35','1','发布成功','rz-service-task','','172.16.104.12,172.16.103.12'),
('f4f0cd9d1d8b4a4499f0769b1f979543','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-08-25 15:09:09','1','发布成功','rz-service-borrow','','172.16.102.7'),
('f50729656a8b4d349874375bcb8cd557','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-16 22:15:15','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('f5171b9c402b4200b2cc21fca990a511','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-08-31 19:56:34','1','发布成功','rz-web-app','','172.16.106.1,172.16.105.1'),
('f56e8c35470c4956902d168508fa6bd4','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-03-22 15:23:02','1','发布成功','rz-service-borrow','回款日历查询优化',''),
('f5b17a4f80e046c6ae244417f96de8a4','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-24 17:53:07','1','发布成功','rz-service-borrow','r计划查询标的详情查询优化','172.16.102.7,172.16.101.7'),
('f689805c587d4fe686a60dda477e20bd','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-06-28 18:53:54','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('f79089d9615448979125a5e62a86fe49','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-08-30 16:33:35','1','发布成功','rz-web-pc','springboot技术改造','172.16.102.2'),
('f821ca5611284f27bda9b74910d1efda','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-07-05 19:21:52','1','发布成功','rz-web-boss','boss后台图片上传容量限制
BOSS后台，客服系统中，单标以及R计划待收统计列表中，增加对应加息券收益','172.16.101.3'),
('f838f030c5d146619e211b813dcd3a67','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-taskcompa','9d0759ff802c4331916fc124c08e7c1b','release','all','2018-09-11 16:05:50','1','发布成功','rz-service-taskcompare','去掉监控配置','172.16.102.18'),
('f9321d5acef34fa4b18c099bb314de5f','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-rplan','6fcc6017391c4e209410e7b76072b5ab','release','all','2018-05-24 18:51:16','1','发布成功','rz-service-rplan','','172.16.102.14,172.16.101.14'),
('f943fa36cbba4df39b3f7d45d9283718','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-04-18 00:13:16','1','发布成功','rz-service-borrow','','172.16.103.7,172.16.104.7'),
('f95b46ad230f49e1b8a982236665bdc8','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-pc','da73040acef5431d932598f826833eac','release','all','2018-07-19 20:47:45','1','发布成功','rz-web-pc','','172.16.101.2'),
('fa3db9f68d78413e8a3bc8a9afb1c65d','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-08-22 10:45:57','1','发布成功','rz-service-account','昨天发错老包','172.16.102.6'),
('fafe169b26954d059a43ed9c342dbe69','hejianxiong','04000bdf-6adb-3336-9bfa-dd0f36ec7377','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-04-04 14:45:45','1','发布成功','rz-web-app','注册发短信接口404错误需要上线app,以及短信模板问题修复','172.16.104.1,172.16.103.1'),
('fb342d3347f74e68a36c3ced5de98f35','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-06-26 23:21:10','1','发布成功','rz-service-account','','172.16.102.6'),
('fb3dbd9b35614c35bd914f717bba3993','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-boss','51d4fc95a73c413e9b975dd4fec41c5a','release','all','2018-04-05 04:28:33','1','发布成功','rz-web-boss','','172.16.101.3'),
('fc22d4c8a8db48f0913943169f5f3fb7','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-task','a57aa7dd95f24bada3a057b17953b46a','release','all','2018-06-27 04:02:47','1','发布成功','rz-service-task','','172.16.104.12,172.16.103.12'),
('fd05224be46241f9b6f6fa4da3f7180a','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-checkbid','db08ce48dcfa4288be0c1add8e539fa6','release','all','2018-07-03 19:45:18','1','发布成功','rz-service-checkbid','','172.16.101.20'),
('fda8a3988c224907a07291e5225b1891','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-bi','9d0f99c5f18e4496a80322f8320aa393','release','all','2018-07-19 19:52:30','1','发布成功','rz-web-bi','','172.16.101.22'),
('fdea04496f494685b800b5a3c76fba57','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-content','28bc8a3a614545c1b606d8d770bf31d6','release','all','2018-07-03 19:30:29','1','发布成功','rz-service-content','','172.16.102.9'),
('fe090c5107514fc086c6db45a2b84fa2','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-bidweb','a5e6b79d00ed480fa0b0180e8cfeaf7d','release','all','2018-08-08 20:41:46','1','发布成功','rz-service-bidweb','','172.16.101.24'),
('fe151a6b03e34483856611cef153b135','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-07-19 20:43:26','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.101.7'),
('fe62fa7d93ba4fbfa043675e6a906ea4','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-borrow','60117ba135b74bd198521710be351373','release','all','2018-09-05 19:35:54','1','发布成功','rz-service-borrow','','172.16.102.7,172.16.103.7,172.16.104.7'),
('fe85a9ba264d44ddad5ae7adbffd17be','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-account','a98972442c444d0f87f0fc28c70fa270','release','all','2018-08-14 22:28:02','1','发布成功','rz-service-account','','172.16.102.6'),
('fee56867fb2b4eeeb172b77c8d8a5fd2','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-web-app','880d60d415574de59c66e092040ceb45','release','all','2018-03-22 05:36:58','1','发布成功','rz-web-app','',''),
('ff21a197ad994a75bc730da4e00f1b1e','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-customer','ac7b15eb162c4490b1f4f5bc4d2403c5','release','all','2018-04-03 22:50:45','1','发布成功','rz-service-customer','','172.16.103.8,172.16.104.8'),
('ffb4b33ace1a44ff9f9790eff1a99a11','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz23-service-taskoff','865d759655304107a0eb9067e6217b9d','release','all','2018-04-18 15:51:16','1','发布成功','rz-service-taskoffline','','172.16.101.23'),
('ffd3ffff3ef34bef9d11110f6c18c790','admin','3eceb1e9-df90-38ed-9960-03183bc85cce','rz-service-redpacket','501c6a4698f84b948eb642e87b581016','release','all','2018-07-12 21:34:51','1','发布成功','rz-service-redpacket','','172.16.101.10');
DROP TABLE IF EXISTS  `auth_group_permissions`;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_0e939a4f` (`group_id`),
  KEY `auth_group_permissions_8373b171` (`permission_id`),
  CONSTRAINT `auth_group__permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permission_group_id_689710a9a73b7457_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `assets_project`;
CREATE TABLE `assets_project` (
  `uuid` char(32) NOT NULL,
  `service_name` varchar(60) DEFAULT NULL,
  `aliases_name` varchar(60) DEFAULT NULL,
  `description` longtext,
  `project_doc` longtext,
  `project_user_group` longtext,
  `sort` int(11) DEFAULT NULL,
  `line_id` char(32) DEFAULT NULL,
  `project_contact_id` int(11) NOT NULL,
  `project_contact_backup_id` int(11) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `assets_project_line_id_3271c84b6deb8f1f_fk_assets_line_uuid` (`line_id`),
  KEY `assets_project_087d62fc` (`project_contact_id`),
  KEY `assets_project_227d338f` (`project_contact_backup_id`),
  CONSTRAINT `asset_project_contact_id_55a9a08f4b924c8c_fk_users_customuser_id` FOREIGN KEY (`project_contact_id`) REFERENCES `users_customuser` (`id`),
  CONSTRAINT `assets_project_line_id_3271c84b6deb8f1f_fk_assets_line_uuid` FOREIGN KEY (`line_id`) REFERENCES `assets_line` (`uuid`),
  CONSTRAINT `d46f719c8dcde971d1e0990f038ba85a` FOREIGN KEY (`project_contact_backup_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `assets_project`(`uuid`,`service_name`,`aliases_name`,`description`,`project_doc`,`project_user_group`,`sort`,`line_id`,`project_contact_id`,`project_contact_backup_id`) values
('28bc8a3a614545c1b606d8d770bf31d6','rz-service-content','rz-service-content','rz-service-content',null,'','9','512a9e416957498a934c8821ea895cc1','1','1'),
('3df7fcdeadf14376b26436b955242ee3','rz-service-third','rz-service-third','rz-service-third',null,'','11','512a9e416957498a934c8821ea895cc1','1','1'),
('3f2f7c6b5eb24ccea5d1047e2a959a96','rz-web-ups','rz-web-ups','rz-web-ups',null,'[]','0','512a9e416957498a934c8821ea895cc1','18','18'),
('4d0674633fc8424bb44075597166157c','rz-service-accountlog','rz-service-accountlog','rz-service-accountlog',null,'','15','512a9e416957498a934c8821ea895cc1','18','18'),
('501c6a4698f84b948eb642e87b581016','rz-service-redpacket','rz-service-redpacket','rz-service-redpacket',null,'','10','512a9e416957498a934c8821ea895cc1','1','1'),
('51d4fc95a73c413e9b975dd4fec41c5a','rz-web-boss','rz-web-boss','rz-web-boss',null,'','2','512a9e416957498a934c8821ea895cc1','1','1'),
('60117ba135b74bd198521710be351373','rz-service-borrow','rz-service-borrow','rz-service-borrow',null,'','6','512a9e416957498a934c8821ea895cc1','17','17'),
('6fcc6017391c4e209410e7b76072b5ab','rz-service-rplan','rz-service-rplan','rz-service-rplan',null,'','14','512a9e416957498a934c8821ea895cc1','18','18'),
('71001248baaa49928fe5073d7018a702','salt-master','salt-mater','',null,'','23','512a9e416957498a934c8821ea895cc1','17','1'),
('7b92ba85373f4315a7b9020c7c0227d5','rz-service-redemption','rz-service-redemption','rz-service-redemption',null,'','19','512a9e416957498a934c8821ea895cc1','18','18'),
('865d759655304107a0eb9067e6217b9d','rz23-service-taskoffline','rz23-service-taskoffline','rz23-service-taskoffline',null,'','23','512a9e416957498a934c8821ea895cc1','18','18'),
('880d60d415574de59c66e092040ceb45','rz-web-app','rz-web-app','rz-web-app',null,'','0','512a9e416957498a934c8821ea895cc1','1','1'),
('9d0759ff802c4331916fc124c08e7c1b','rz-service-taskcompare','rz-service-taskcompare','rz-service-taskcompare',null,'','18','512a9e416957498a934c8821ea895cc1','18','18'),
('9d0f99c5f18e4496a80322f8320aa393','rz-web-bi','rz-web-bi','rz-web-bi',null,'','22','512a9e416957498a934c8821ea895cc1','18','18'),
('a240928ca7d9484e969f39228a4678bc','rz-web-redemption','rz-web-redemption','rz-web-redemption',null,'','5','512a9e416957498a934c8821ea895cc1','1','1'),
('a57aa7dd95f24bada3a057b17953b46a','rz-service-task','rz-service-task','rz-service-task',null,'','12','512a9e416957498a934c8821ea895cc1','1','1'),
('a5e6b79d00ed480fa0b0180e8cfeaf7d','rz-service-bidweb','rz-service-bidweb','rz-service-bidweb',null,'[]','2','512a9e416957498a934c8821ea895cc1','1','1'),
('a98972442c444d0f87f0fc28c70fa270','rz-service-account','rz-service-account','rz-service-account',null,'','6','512a9e416957498a934c8821ea895cc1','1','1'),
('ac7b15eb162c4490b1f4f5bc4d2403c5','rz-service-customer','rz-service-customer','rz-service-customer',null,'','8','512a9e416957498a934c8821ea895cc1','1','1'),
('acf68ee3993641d5b029a205ba7da108','rz-web-provide','rz-web-provide','rz-web-provide',null,'','21','512a9e416957498a934c8821ea895cc1','18','18'),
('b47613d484c94327a6f4991654f52032','rz-web-callback','rz-web-callback','rz-web-callback',null,'','3','512a9e416957498a934c8821ea895cc1','1','1'),
('c0097a800e784e42bb7cc7b94cd69113','rz-service-consumer','rz-service-consumer','rz-service-consumer',null,'','13','512a9e416957498a934c8821ea895cc1','18','18'),
('da73040acef5431d932598f826833eac','rz-web-pc','rz-web-pc','rz-web-pc',null,'','1','512a9e416957498a934c8821ea895cc1','1','1'),
('db08ce48dcfa4288be0c1add8e539fa6','rz-service-checkbid','rz-service-checkbid','rz-service-checkbid',null,'[]','1','512a9e416957498a934c8821ea895cc1','1','1');
DROP TABLE IF EXISTS  `assets_conftemplate`;
CREATE TABLE `assets_conftemplate` (
  `uuid` char(32) NOT NULL,
  `name` varchar(30) NOT NULL,
  `init_file` longtext NOT NULL,
  `template_file` longtext NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `assets_host`;
CREATE TABLE `assets_host` (
  `uuid` char(32) NOT NULL,
  `node_name` varchar(100) DEFAULT NULL,
  `eth1` char(15) DEFAULT NULL,
  `eth2` char(15) DEFAULT NULL,
  `mac` varchar(20) DEFAULT NULL,
  `internal_ip` char(15) DEFAULT NULL,
  `brand` varchar(64) DEFAULT NULL,
  `cpu` varchar(64) DEFAULT NULL,
  `hard_disk` varchar(128) DEFAULT NULL,
  `memory` varchar(128) DEFAULT NULL,
  `system` varchar(32) DEFAULT NULL,
  `system_cpuarch` varchar(32) DEFAULT NULL,
  `system_version` varchar(8) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `guarantee_date` date DEFAULT NULL,
  `cabinet` varchar(32) DEFAULT NULL,
  `server_cabinet_id` int(11) DEFAULT NULL,
  `number` varchar(32) DEFAULT NULL,
  `editor` longtext,
  `status` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `Services_Code` varchar(16) DEFAULT NULL,
  `env` varchar(32) DEFAULT NULL,
  `room_number` varchar(32) DEFAULT NULL,
  `server_sn` varchar(32) DEFAULT NULL,
  `switch_port` varchar(12) DEFAULT NULL,
  `idle` tinyint(1) NOT NULL,
  `idc_id` char(32) DEFAULT NULL,
  `vm_id` char(32) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  KEY `assets_host_0869e37a` (`idc_id`),
  KEY `assets_host_0e0cecb8` (`vm_id`),
  CONSTRAINT `assets_host_idc_id_fc02f1e2acbbcc_fk_assets_idc_uuid` FOREIGN KEY (`idc_id`) REFERENCES `assets_idc` (`uuid`),
  CONSTRAINT `assets_host_vm_id_75080968af94dfe0_fk_assets_host_uuid` FOREIGN KEY (`vm_id`) REFERENCES `assets_host` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `assets_host`(`uuid`,`node_name`,`eth1`,`eth2`,`mac`,`internal_ip`,`brand`,`cpu`,`hard_disk`,`memory`,`system`,`system_cpuarch`,`system_version`,`create_time`,`guarantee_date`,`cabinet`,`server_cabinet_id`,`number`,`editor`,`status`,`type`,`Services_Code`,`env`,`room_number`,`server_sn`,`switch_port`,`idle`,`idc_id`,`vm_id`) values
('00a453cc901a4852ba4bc3ec3e6f1171','00a453cc901a4852ba4bc3ec3e6f1171','','','00-16-3e-12-80-8c','','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','','','','2018-03-13 10:01:37',null,'','0','','','3','0','','',null,'','','1','fdc800201b6e4c7baca23d3720e0e14d',null),
('0ee19bdefd474ca69f971ba9565ba336','rz22-web-bi-01','172.16.101.22','172.16.101.22','00-16-3f-00-da-84','172.16.101.22','虚拟化','Intel(R) Xeon(R) Platinum 8163 CPU @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 09:47:46',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('1da4d56bff0d49ce9fb61b7161958410','rz07-borrow-02','172.16.102.7','172.16.102.7','00-16-3e-04-01-60','172.16.102.7','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 09:48:51',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('281ee4bdd589466d8ff23f37e74db9d1','rz12-task-04','172.16.104.12','172.16.104.12','00-16-3e-10-17-2b','172.16.104.12','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:28:38',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('2a8b5327d0eb4119b761358429d5221b','2a8b5327d0eb4119b761358429d5221b','','','00-16-3e-0c-42-a3','','虚拟化','Intel(R) Xeon(R) Platinum 8163 CPU @ 2.50GHz','40G','3961','','','','2018-03-13 09:58:32',null,'','0','','','3','0','','',null,'','','1','fdc800201b6e4c7baca23d3720e0e14d',null),
('2fade89f55da4583ab2e8172ab3ffccc','rz13-consumer-01','172.16.101.13','172.16.101.13','00-16-3e-10-21-f9','172.16.101.13','虚拟化','Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz','','3961','CentOS','x86_64',null,'2018-03-13 10:24:20',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('331e180944b54fc2b93ea1a002aff9e3','rz16-account-log-01','172.16.101.16','172.16.101.16','00-16-3e-10-65-ec','172.16.101.16','虚拟化','Intel(R) Xeon(R) Platinum 8163 CPU @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:32:29',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('373310488a2a4db2af33ad7989ea01a6','373310488a2a4db2af33ad7989ea01a6','','','00-16-3e-11-79-c3','','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','','','','2018-03-13 10:37:36',null,'','0','','','3','0','','',null,'','','1','fdc800201b6e4c7baca23d3720e0e14d',null),
('39831ac380474932aeda749be56a8a2d','rz03-web-boss-01','172.16.101.3','172.16.101.3','00-16-3e-04-07-46','172.16.101.3','虚拟化','Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz','40G','3961','CentOS','x86_64',null,'2018-03-12 16:27:08',null,'',null,'','','1','1','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('3b44291e2ef648dabd1454da8c2fc799','rz01-web-app-04','172.16.104.1','172.16.104.1','00-16-3e-0f-bb-71','172.16.104.1','虚拟化','Intel(R) Xeon(R) Platinum 8163 CPU @ 2.50GHz','','3961','CentOS','x86_64',null,'2018-03-12 15:49:29',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('3fc7f5176602460981b7161adcf6e8c8','rz04-web-callback-03','172.16.103.4','172.16.103.4','00-16-3e-10-21-27','172.16.103.4','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','','3961','CentOS','x86_64',null,'2018-04-08 18:04:48',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('40eaa2e55390498482e29613946a4a52','rz02-web-pc-03','172.16.103.2','172.16.103.2','00-16-3e-10-15-1f','172.16.103.2','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','','3961','CentOS','x86_64',null,'2018-03-12 15:59:28',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('434e41ed69b94147a33d3991bed8bded','rz09-content-02','172.16.102.9','172.16.102.9','00-16-3e-0f-fe-ac','172.16.102.9','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-12 18:05:21',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('4a4e9bd4d70a4d56bd1c7cfff07c9acd','4a4e9bd4d70a4d56bd1c7cfff07c9acd','','','00-16-3e-0c-5e-bf','','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','','','','2018-03-13 09:49:29',null,'','0','','','3','0','','',null,'','','1','fdc800201b6e4c7baca23d3720e0e14d',null),
('4b01881128644227ac8b345b8ab0e335','rz02-web-pc-02','172.16.102.2','172.16.102.2','00-16-3e-13-dc-e1','172.16.102.2','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','','3961','CentOS','x86_64',null,'2018-03-12 15:58:50',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('4d49b5d9919e4a92b77c8b49f031a2ae','rz14-rplan-04','172.16.104.14','172.16.104.14','00-16-3e-11-6e-a3','172.16.104.14','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:31:59',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('53c8c24011c6496fae19d451b4d87e0d','rz14-rplan-02','172.16.102.14','172.16.102.14','00-16-3e-0e-aa-28','172.16.102.14','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:31:06',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('573995d50bba43be978599a41861faf7','rz18-taskcompare-02','172.16.102.18','172.16.102.18','00-16-3f-00-85-b1','172.16.102.18','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:35:24',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('5e74a72799ca4c58a5d3a8ec2f19dd81','rz06-account-02','172.16.102.6','172.16.102.6','00-16-3e-0f-15-86','172.16.102.6','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 09:48:19',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('6289d71d26c14641811cf8f868b3fea6','rz18-taskcompare-01','172.16.101.18','172.16.101.18','00-16-3e-0d-fe-a5','172.16.101.18','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:33:12',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('63d3f007774241f9888b4cd931a96991','rz19-redemption-01','172.16.101.19','172.16.101.19','00-16-3f-00-8f-10','172.16.101.19','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:34:27',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('661e8acebc664513a1c190518bf509df','rz04-web-callback-02','172.16.102.4','172.16.102.4','00-16-3e-0f-4b-d0','172.16.102.4','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','','3961','CentOS','x86_64',null,'2018-03-12 16:36:43',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('68720adbd74a42ccbd13813b133f5e87','rz07-borrow-03','172.16.103.7','172.16.103.7','00-16-3e-12-fc-2a','172.16.103.7','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 09:54:24',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('6a2d404a802c4c20bf7ce1733a221096','rz13-consumer-04','172.16.104.13','172.16.104.13','00-16-3e-13-28-cc','172.16.104.13','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:30:16',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('70700e3193eb40d4b04b19d50366c738','rz08-customer-01','172.16.101.8','172.16.101.8','00-16-3e-0f-74-65','172.16.101.8','虚拟化','Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz','','3961','CentOS','x86_64',null,'2018-03-12 18:00:42',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('7f46c2dabac0461d8b3b785ddc548368','rz14-rplan-01','172.16.101.14','172.16.101.14','00-16-3e-10-65-5f','172.16.101.14','虚拟化','Intel(R) Xeon(R) Platinum 8163 CPU @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:30:40',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('80c84e2365f84c3c8acb64d7c7110ee9','rz07-borrow-01','172.16.101.7','172.16.101.7','00-16-3e-0f-f2-4b','172.16.101.7','虚拟化','Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz','40G','3961','CentOS','x86_64',null,'2018-03-12 17:59:51',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('8495bdb243ba4fd7834a541935296a16','rz01-web-app-06','172.16.106.1','172.16.106.1','00-16-3e-10-1d-a7','172.16.106.1','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','','3961','CentOS','x86_64',null,'2018-03-12 15:50:24',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('87bdb70665f44b3ea18414168f646eb0','rz02-web-pc-01','172.16.101.2','172.16.101.2','00-16-3e-04-11-24','172.16.101.2','虚拟化','Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz','','3961','CentOS','x86_64',null,'2018-03-12 15:58:32',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('920d7f5d1c5f45ea8ad60ebdbc95cdb7','rz01-web-app-02','172.16.102.1','172.16.102.1','00-16-3e-04-04-4d','172.16.102.1','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','','3961','CentOS','x86_64',null,'2018-03-12 15:48:26',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('929390a816c64ca3bad9427c6a61bc8a','rz21-web-provide-01','172.16.101.21','172.16.101.21','00-16-3e-12-1e-15','172.16.101.21','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:33:37',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('96716780541c47f9a717f6dfb38dbbb8','96716780541c47f9a717f6dfb38dbbb8','','','00-16-3e-11-7b-e9','','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','','','','2018-03-13 10:37:11',null,'','0','','','3','0','','',null,'','','1','fdc800201b6e4c7baca23d3720e0e14d',null),
('a2ddd6b350134e29b61de1632f99951c','rz08-customer-03','172.16.103.8','172.16.103.8','00-16-3e-0d-12-55','172.16.103.8','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:01:03',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('a90f2ad509bf45038475de14b222254b','rz10-redpacket-01','172.16.101.10','172.16.101.10','00-16-3e-0e-3f-89','172.16.101.10','虚拟化','Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 09:50:29',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('aca69ae4047043648bd7d22ac8768c78','rz11-third-01','172.16.101.11','172.16.101.11','00-16-3e-10-21-0a','172.16.101.11','虚拟化','Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 09:54:58',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('b3d5549560294b55be66e879ce50cc63','rz12-task-02','172.16.102.12','172.16.102.12','00-16-3e-0e-3b-57','172.16.102.12','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','','3961','CentOS','x86_64',null,'2018-03-13 10:24:44',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('c02f6dcc9e9e4266a01786ac4dc8a910','rz24-bidweb-01','172.16.101.24','172.16.101.24','00-16-3e-0c-cd-34','172.16.101.24','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','','3961','CentOS','x86_64',null,'2018-06-26 11:42:53',null,'',null,'','','1','0','','prod','3-2','',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('c212701463a64565b78570d6b8a3f327','rz23-taskoffline-01','172.16.101.23','172.16.101.23','00-16-3e-10-4e-94','172.16.101.23','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-15 18:01:52',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('c880688c3558450ca198bb40bc24a824','rz16-account-log-02','172.16.102.16','172.16.102.16','00-16-3e-04-10-85','172.16.102.16','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:36:05',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('cc65ad7c5c5d4ee28d618a1a48fcf2f7','rz07-borrow-04','172.16.104.7','172.16.104.7','00-16-3e-10-dc-f4','172.16.104.7','虚拟化','Intel(R) Xeon(R) Platinum 8163 CPU @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 09:57:21',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('cd90c144576e4283a42d881c290d958b','rz11-third-03','172.16.103.11','172.16.103.11','00-16-3e-0f-b4-57','172.16.103.11','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:00:40',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('ce29d96613d54a6bb34c779be5eb2320','rz08-customer-02','172.16.102.8','172.16.102.8','00-16-3e-0f-fa-d2','172.16.102.8','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 09:49:57',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('cea2ceeeb9d5411b870117c4493e7bf7','rz05-web-redemption-01','172.16.101.5','172.16.101.5','00-16-3e-10-c4-d1','172.16.101.5','虚拟化','Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz','','3961','CentOS','x86_64',null,'2018-03-12 17:46:01',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('d248814a89cf4cd0bd280c23dcb01b38','rz20-web-benchmarking-01','172.16.101.20','172.16.101.20','00-16-3e-13-84-4d','172.16.101.20','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:34:01',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('d36533c0f7fe4fdfb0bc8cf6d0821219','rz10-redpacket-02','172.16.102.10','172.16.102.10','00-16-3e-10-25-a8','172.16.102.10','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 09:56:55',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('d63d5ce484374594b5c28ffbfd4b1454','rz01-web-app-01','172.16.101.1','172.16.101.1','00-16-3e-04-25-90','172.16.101.1','虚拟化','Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz','','3961','CentOS','x86_64',null,'2018-03-12 15:32:31',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('d85625e41fb84609ab991fecb3731ac9','d85625e41fb84609ab991fecb3731ac9','','','00-16-3e-13-b7-b2','','虚拟化','Intel(R) Xeon(R) Platinum 8163 CPU @ 2.50GHz','40G','3961','','','','2018-03-13 09:53:56',null,'','0','','','3','0','','',null,'','','1','fdc800201b6e4c7baca23d3720e0e14d',null),
('da5c37a7134a46e09ebfdfe08642a238','rz06-account-01','172.16.101.6','172.16.101.6','00-16-3e-0d-fe-4a','172.16.101.6','虚拟化','Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz','40G','3961','CentOS','x86_64',null,'2018-03-12 17:47:46',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('dfad991de88a473eb51c8fbfe5758329','rz12-task-01','172.16.101.12','172.16.101.12','00-16-3e-10-c1-cd','172.16.101.12','虚拟化','Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 09:59:03',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('e17795d5d51a4bc6986f1c4c3803c215','rz13-consumer-02','172.16.102.13','172.16.102.13','00-16-3e-0f-fb-29','172.16.102.13','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:29:25',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('e756c7646fbd4deb8ddf488666f9c56f','rz04-web-callback-01','172.16.101.4','172.16.101.4','00-16-3e-0f-a8-b3','172.16.101.4','虚拟化','Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz','','3961','CentOS','x86_64',null,'2018-03-12 16:35:56',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('e806abad59b344b4850f23512d94d192','rz01-web-app-05','172.16.105.1','172.16.105.1','00-16-3e-13-cb-4b','172.16.105.1','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','','3961','CentOS','x86_64',null,'2018-03-12 15:49:53',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('ebc801311a7448d2b9e5702b50f91915','rz14-rplan-03','172.16.103.14','172.16.103.14','00-16-3e-11-70-28','172.16.103.14','虚拟化','Intel(R) Xeon(R) Platinum 8163 CPU @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:31:29',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('ebd6b633359242b0a5d3ffe81b472294','rz09-content-01','172.16.101.9','172.16.101.9','00-16-3e-0f-c2-b1','172.16.101.9','虚拟化','Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz','40G','3961','CentOS','x86_64',null,'2018-03-12 18:04:53',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('f055b5f0a0e34e5aab4344fc0e25b195','f055b5f0a0e34e5aab4344fc0e25b195','','','00-16-3e-0e-2b-20','','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','','','','2018-03-13 09:58:01',null,'','0','','','3','0','','',null,'','','1','fdc800201b6e4c7baca23d3720e0e14d',null),
('f0970a4c458440b8bf8aa03e6f8962dc','rz11-third-02','172.16.102.11','172.16.102.11','00-16-3e-0f-14-f3','172.16.102.11','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:00:15',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('f11b4a0b622b4f529aa78f87b3278f95','rz01-web-app-03','172.16.103.1','172.16.103.1','00-16-3e-0f-b4-a3','172.16.103.1','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','','3961','CentOS','x86_64',null,'2018-03-12 15:48:46',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('f16f80fb12e24a828da7fdc20bf0baf1','rz12-task-03','172.16.103.12','172.16.103.12','00-16-3e-0e-29-b7','172.16.103.12','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','','3961','CentOS','x86_64',null,'2018-03-13 10:28:16',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('f39ce94c495a4a7081f6a5140b9ba3d2','rz02-web-pc-04','172.16.104.2','172.16.104.2','00-16-3e-10-26-f9','172.16.104.2','虚拟化','Intel(R) Xeon(R) Platinum 8163 CPU @ 2.50GHz','','3961','CentOS','x86_64',null,'2018-03-12 15:59:56',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('f49bfd6d64b84f1388ee55d884bdb835','rz08-customer-04','172.16.104.8','172.16.104.8','00-16-3e-04-12-25','172.16.104.8','虚拟化','Intel(R) Xeon(R) Platinum 8163 CPU @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:11:42',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('f4f7353dc25a4c3c965c2e1b1760ebe6','rz19-redemption-02','172.16.102.19','172.16.102.19','00-16-3f-00-d1-57','172.16.102.19','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:34:56',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('f634fc1f5c93410dbd523b6d70e51618','salt-master','172.16.200.1','172.16.200.1','00-16-3e-13-70-df','172.16.200.1','虚拟化','Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:38:09',null,'',null,'','','0','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null),
('fc85d1b92a20459ca6d282cefafef864','rz13-consumer-03','172.16.103.13','172.16.103.13','00-16-3e-10-13-d4','172.16.103.13','虚拟化','Intel(R) Xeon(R) CPU E5-2682 v4 @ 2.50GHz','40G','3961','CentOS','x86_64',null,'2018-03-13 10:29:50',null,'',null,'','','1','0','','prod',null,'',null,'1','eb9061fdb6c9404f937105c4a34b0781',null);
DROP TABLE IF EXISTS  `django_admin_log`;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_417f1b1c` (`content_type_id`),
  KEY `django_admin_log_e8701ad4` (`user_id`),
  CONSTRAINT `djang_content_type_id_697914295151027a_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_52fdd58701c5f563_fk_users_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `assets_host_service`;
CREATE TABLE `assets_host_service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host_id` char(32) NOT NULL,
  `service_id` char(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `host_id` (`host_id`,`service_id`),
  KEY `assets_host_service_8396f175` (`host_id`),
  KEY `assets_host_service_b0dc1e29` (`service_id`),
  CONSTRAINT `assets_host_s_service_id_1f5ce3d13bb0764b_fk_assets_service_uuid` FOREIGN KEY (`service_id`) REFERENCES `assets_service` (`uuid`),
  CONSTRAINT `assets_host_service_host_id_660cc79feac0eb15_fk_assets_host_uuid` FOREIGN KEY (`host_id`) REFERENCES `assets_host` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `assets_host_business`;
CREATE TABLE `assets_host_business` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host_id` char(32) NOT NULL,
  `project_id` char(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `host_id` (`host_id`,`project_id`),
  KEY `assets_host_business_8396f175` (`host_id`),
  KEY `assets_host_business_b098ad43` (`project_id`),
  CONSTRAINT `assets_host_b_project_id_7e1fdf33706676c3_fk_assets_project_uuid` FOREIGN KEY (`project_id`) REFERENCES `assets_project` (`uuid`),
  CONSTRAINT `assets_host_busines_host_id_185b5e5decf9451d_fk_assets_host_uuid` FOREIGN KEY (`host_id`) REFERENCES `assets_host` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8;

insert into `assets_host_business`(`id`,`host_id`,`project_id`) values
('106','0ee19bdefd474ca69f971ba9565ba336','3f2f7c6b5eb24ccea5d1047e2a959a96'),
('105','0ee19bdefd474ca69f971ba9565ba336','9d0f99c5f18e4496a80322f8320aa393'),
('75','1da4d56bff0d49ce9fb61b7161958410','60117ba135b74bd198521710be351373'),
('85','281ee4bdd589466d8ff23f37e74db9d1','a57aa7dd95f24bada3a057b17953b46a'),
('81','2fade89f55da4583ab2e8172ab3ffccc','c0097a800e784e42bb7cc7b94cd69113'),
('93','331e180944b54fc2b93ea1a002aff9e3','4d0674633fc8424bb44075597166157c'),
('50','39831ac380474932aeda749be56a8a2d','51d4fc95a73c413e9b975dd4fec41c5a'),
('42','3b44291e2ef648dabd1454da8c2fc799','880d60d415574de59c66e092040ceb45'),
('102','3fc7f5176602460981b7161adcf6e8c8','b47613d484c94327a6f4991654f52032'),
('58','434e41ed69b94147a33d3991bed8bded','28bc8a3a614545c1b606d8d770bf31d6'),
('46','4b01881128644227ac8b345b8ab0e335','da73040acef5431d932598f826833eac'),
('83','4d49b5d9919e4a92b77c8b49f031a2ae','6fcc6017391c4e209410e7b76072b5ab'),
('97','53c8c24011c6496fae19d451b4d87e0d','6fcc6017391c4e209410e7b76072b5ab'),
('95','573995d50bba43be978599a41861faf7','9d0759ff802c4331916fc124c08e7c1b'),
('74','5e74a72799ca4c58a5d3a8ec2f19dd81','a98972442c444d0f87f0fc28c70fa270'),
('92','6289d71d26c14641811cf8f868b3fea6','9d0759ff802c4331916fc124c08e7c1b'),
('119','63d3f007774241f9888b4cd931a96991','7b92ba85373f4315a7b9020c7c0227d5'),
('52','661e8acebc664513a1c190518bf509df','b47613d484c94327a6f4991654f52032'),
('68','68720adbd74a42ccbd13813b133f5e87','60117ba135b74bd198521710be351373'),
('84','6a2d404a802c4c20bf7ce1733a221096','c0097a800e784e42bb7cc7b94cd69113'),
('55','70700e3193eb40d4b04b19d50366c738','ac7b15eb162c4490b1f4f5bc4d2403c5'),
('91','7f46c2dabac0461d8b3b785ddc548368','6fcc6017391c4e209410e7b76072b5ab'),
('56','80c84e2365f84c3c8acb64d7c7110ee9','60117ba135b74bd198521710be351373'),
('44','8495bdb243ba4fd7834a541935296a16','880d60d415574de59c66e092040ceb45'),
('45','87bdb70665f44b3ea18414168f646eb0','da73040acef5431d932598f826833eac'),
('40','920d7f5d1c5f45ea8ad60ebdbc95cdb7','880d60d415574de59c66e092040ceb45'),
('79','929390a816c64ca3bad9427c6a61bc8a','acf68ee3993641d5b029a205ba7da108'),
('67','a2ddd6b350134e29b61de1632f99951c','ac7b15eb162c4490b1f4f5bc4d2403c5'),
('63','a90f2ad509bf45038475de14b222254b','501c6a4698f84b948eb642e87b581016'),
('64','aca69ae4047043648bd7d22ac8768c78','3df7fcdeadf14376b26436b955242ee3'),
('99','b3d5549560294b55be66e879ce50cc63','a57aa7dd95f24bada3a057b17953b46a'),
('118','c02f6dcc9e9e4266a01786ac4dc8a910','a5e6b79d00ed480fa0b0180e8cfeaf7d'),
('101','c212701463a64565b78570d6b8a3f327','865d759655304107a0eb9067e6217b9d'),
('96','c880688c3558450ca198bb40bc24a824','4d0674633fc8424bb44075597166157c'),
('59','cc65ad7c5c5d4ee28d618a1a48fcf2f7','60117ba135b74bd198521710be351373'),
('70','cd90c144576e4283a42d881c290d958b','3df7fcdeadf14376b26436b955242ee3'),
('76','ce29d96613d54a6bb34c779be5eb2320','ac7b15eb162c4490b1f4f5bc4d2403c5'),
('53','cea2ceeeb9d5411b870117c4493e7bf7','a240928ca7d9484e969f39228a4678bc'),
('111','d248814a89cf4cd0bd280c23dcb01b38','db08ce48dcfa4288be0c1add8e539fa6'),
('72','d36533c0f7fe4fdfb0bc8cf6d0821219','501c6a4698f84b948eb642e87b581016'),
('39','d63d5ce484374594b5c28ffbfd4b1454','880d60d415574de59c66e092040ceb45'),
('54','da5c37a7134a46e09ebfdfe08642a238','a98972442c444d0f87f0fc28c70fa270'),
('65','dfad991de88a473eb51c8fbfe5758329','a57aa7dd95f24bada3a057b17953b46a'),
('98','e17795d5d51a4bc6986f1c4c3803c215','c0097a800e784e42bb7cc7b94cd69113'),
('51','e756c7646fbd4deb8ddf488666f9c56f','b47613d484c94327a6f4991654f52032'),
('43','e806abad59b344b4850f23512d94d192','880d60d415574de59c66e092040ceb45'),
('100','ebc801311a7448d2b9e5702b50f91915','6fcc6017391c4e209410e7b76072b5ab'),
('57','ebd6b633359242b0a5d3ffe81b472294','28bc8a3a614545c1b606d8d770bf31d6'),
('73','f0970a4c458440b8bf8aa03e6f8962dc','3df7fcdeadf14376b26436b955242ee3'),
('41','f11b4a0b622b4f529aa78f87b3278f95','880d60d415574de59c66e092040ceb45'),
('89','f16f80fb12e24a828da7fdc20bf0baf1','a57aa7dd95f24bada3a057b17953b46a'),
('77','f49bfd6d64b84f1388ee55d884bdb835','ac7b15eb162c4490b1f4f5bc4d2403c5'),
('114','f4f7353dc25a4c3c965c2e1b1760ebe6','7b92ba85373f4315a7b9020c7c0227d5'),
('78','f634fc1f5c93410dbd523b6d70e51618','71001248baaa49928fe5073d7018a702'),
('88','fc85d1b92a20459ca6d282cefafef864','c0097a800e784e42bb7cc7b94cd69113');
DROP TABLE IF EXISTS  `django_migrations`;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `monitor_monitorhttp`;
CREATE TABLE `monitor_monitorhttp` (
  `uuid` char(32) NOT NULL,
  `title` varchar(120) NOT NULL,
  `url` longtext NOT NULL,
  `monitor_type` tinyint(1) NOT NULL,
  `monitor_ip` longtext NOT NULL,
  `mail_status` tinyint(1) NOT NULL,
  `mail` longtext NOT NULL,
  `weixin_status` tinyint(1) NOT NULL,
  `weixin` longtext NOT NULL,
  `payload` longtext,
  `status` tinyint(1) NOT NULL,
  `result_code` tinyint(1) NOT NULL,
  `createtime` datetime NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `assets_projectuser`;
CREATE TABLE `assets_projectuser` (
  `uuid` char(32) NOT NULL,
  `data_created` datetime NOT NULL,
  `env` varchar(100) DEFAULT NULL,
  `project_id` char(32) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  KEY `assets_projec_project_id_298fad6d989e9c44_fk_assets_project_uuid` (`project_id`),
  KEY `assets_projectuser_e8701ad4` (`user_id`),
  CONSTRAINT `assets_projec_project_id_298fad6d989e9c44_fk_assets_project_uuid` FOREIGN KEY (`project_id`) REFERENCES `assets_project` (`uuid`),
  CONSTRAINT `assets_projectus_user_id_53f8464903c02003_fk_users_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `push_system`;
CREATE TABLE `push_system` (
  `uuid` char(32) NOT NULL,
  `project_name` int(11) NOT NULL,
  `push_url` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `users_customuser_user_permissions`;
CREATE TABLE `users_customuser_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customuser_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customuser_id` (`customuser_id`,`permission_id`),
  KEY `users_customuser_user_permissions_721e74b0` (`customuser_id`),
  KEY `users_customuser_user_permissions_8373b171` (`permission_id`),
  CONSTRAINT `users_custo_permission_id_26c8d8c42be54c0a_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `users_custom_customuser_id_cd602244af3539_fk_users_customuser_id` FOREIGN KEY (`customuser_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `monitor_monitorhttplog`;
CREATE TABLE `monitor_monitorhttplog` (
  `uuid` char(32) NOT NULL,
  `monitorId` varchar(120) NOT NULL,
  `monitor_title` varchar(120) NOT NULL,
  `content` longtext,
  `code` int(11) NOT NULL,
  `job_id` varchar(32) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `createtime` datetime NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `users_departmentgroup`;
CREATE TABLE `users_departmentgroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department_groups_name` varchar(64) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `users_customuser`;
CREATE TABLE `users_customuser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `email` varchar(254) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `session_key` varchar(60) DEFAULT NULL,
  `user_key` longtext,
  `menu_status` tinyint(1) NOT NULL,
  `user_active` tinyint(1) NOT NULL,
  `uuid` varchar(64) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `users_customuser_bf691be4` (`department_id`),
  CONSTRAINT `users_department_id_7ef5db15268629e1_fk_users_department_mode_id` FOREIGN KEY (`department_id`) REFERENCES `users_department_mode` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

insert into `users_customuser`(`id`,`password`,`last_login`,`is_superuser`,`email`,`username`,`first_name`,`last_name`,`mobile`,`session_key`,`user_key`,`menu_status`,`user_active`,`uuid`,`is_staff`,`is_active`,`date_joined`,`department_id`) values
('1','pbkdf2_sha256$15000$Jk0LUsb0dmVu$YkZqG97ewQqpWXXgG9QKfkGrt7aoFZRIis8BD4Cfod8=','2018-09-19 17:58:44','1','hejianxiong@51rz.com','admin','admin','admin','','duy972zsulcugycn0kfctqafnsqkk3be',null,'1','0','3eceb1e9-df90-38ed-9960-03183bc85cce','1','1','2018-03-09 14:05:50',null),
('17','pbkdf2_sha256$15000$MktNXGq4wX3c$OAFB30d87eRjhteCKNTrdzBS4BWzg+9pP4gV9EvrWF8=','2018-09-19 16:43:18','1','mrhjxhn@163.com','hejianxiong','hejianxiong','','1598145004','fmskgq1p4rcb9b38tvy5l7fwwjm7qyi4','','1','0','04000bdf-6adb-3336-9bfa-dd0f36ec7377','1','1','2018-03-12 16:48:04','8'),
('18','','2018-03-13 09:36:00','0','yangguangwei@51rz.com','yangguangwei','杨光伟','','15100011452','','','0','0','5342f267-3b87-3ea5-a3e0-0f76d341b41b','1','1','2018-03-13 09:36:00','6'),
('19','','2018-03-13 09:37:54','0','luoziliang@51rz.com','luoziliang','罗梓亮','','18956561414','','','0','0','12fe2c5b-d970-350e-b129-5ff01c3fa0fd','0','0','2018-03-13 09:37:54','7'),
('21','','2018-03-20 15:10:08','0','hjxhainan@126.com','test','test','','1234567894','','sfdaew','0','0','df2bd02a-49ea-3c73-b7b5-ca8c693a0744','1','1','2018-03-20 15:10:08','8');
DROP TABLE IF EXISTS  `cmdb_auth_auth_group`;
CREATE TABLE `cmdb_auth_auth_group` (
  `uuid` char(32) NOT NULL,
  `group_name` varchar(100) NOT NULL,
  `enable` tinyint(1) NOT NULL,
  `explanation` longtext NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `group_name` (`group_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `cmdb_auth_auth_group`(`uuid`,`group_name`,`enable`,`explanation`,`date_time`) values
('846e66dd279647dfb1d1963fc79fb27f','yunwei','1','运维部','2018-03-20 14:02:17');
DROP TABLE IF EXISTS  `gitcode`;
CREATE TABLE `gitcode` (
  `uuid` char(32) NOT NULL,
  `codePath` varchar(64) NOT NULL,
  `codeserver` varchar(64) NOT NULL,
  `codeFqdn` varchar(64) NOT NULL,
  `codename` varchar(64) NOT NULL,
  `environ` varchar(8) NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `django_session`;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_de54fa62` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `django_session`(`session_key`,`session_data`,`expire_date`) values
('03yyevyl309r8c0s9rk6c4vbwna7v44m','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-21 18:38:58'),
('08tji7zz1xe9u75836gn6744vdkwmzhr','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-07-25 03:10:26'),
('0h5kkg6rt3vtqdbgz1xegagdvznjme6o','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-05-08 23:59:29'),
('0j77kqq4418sqyih6pu0pkhrbpqvm5qr','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-03-27 02:27:04'),
('0mit15sie3bqhbiax99sbt8a2lweqjk6','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-09-11 23:54:18'),
('0pm7ukpkyvbjvfd7rjazpyqf8qen6vvd','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-03-22 13:36:59'),
('0rr8syy2eu6l6jn8td8ak60jk5oil4aj','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-09-15 02:39:42'),
('1kkj9anehhasbbgc85j71z0mdw1y50ak','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-08-17 03:25:34'),
('1p6c69h6hgbbreqknrzb4eb0fad5c9la','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-04-28 05:11:04'),
('1pud5785c3xa2tvzk47at1s1zwigke9z','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-04-19 00:09:47'),
('1q1uoxmot5ho0tiw4r4ryjxe1eb3qpud','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-05-11 05:07:14'),
('1rt9wc60a9tkp5p7q3d3huaqm1dtkrr2','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-21 03:25:24'),
('1sqym57exfwyl9qnat2t3om8yq97qu03','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-06-20 18:02:34'),
('1tba4nb195mmxxq8f3ot3qvszbttxwdi','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-04-20 00:24:15'),
('2e541sdvxmn8sl7whd1jjw2l6wt10jn2','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-27 17:59:18'),
('2or4d91mleh126il3hr9j5hf6cqdk1yg','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-06-20 07:17:46'),
('2qoi0qd0i8386w610i5cwy83gaxiookh','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-04-20 04:13:44'),
('3066yrt6pqmi0dpj9pz57y4ggp31fmdh','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-06-19 17:28:00'),
('36jfbz1ftems23bmcn65pd6cg18tpce0','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-04-02 17:39:01'),
('39u8thi5x555tw54np7r852hn0dyab42','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-21 00:54:23'),
('3d7jf52tllwijdksh5ukyh7iz0ztil5o','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-05-11 02:15:51'),
('3np19ruoh4kfgsc68dyfv6p93ineockp','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-04-09 22:29:54'),
('3q2k167ah1iud6cjyroulv9489bofz0w','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:42:44'),
('3qnir866b8mosx05wdtth1wu85o843jx','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-09-06 03:35:54'),
('3xinidexba7f5vp1xa9cssintoeupyx3','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-05-16 03:03:47'),
('46tpkvhogqsqfxbxr2zz73wx2lrzqjsy','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-15 02:17:07'),
('4bur0kf5lq4fl3t6f3t2n5t5snp6sp48','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-07-20 05:59:01'),
('4eclw2hav6e2z4uhzzrp0hlyekmk2zcb','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-05-07 17:39:22'),
('4jk1pwyumg1o8xvtvhc9sdftyp9jqfl3','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-04-09 02:11:52'),
('4pnijhtdeupsi1j2zbggce1e5frogrw5','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-07-27 02:31:53'),
('4qzbconpy8cm05tv07oetrdm0jr5i0y3','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-08-08 02:22:47'),
('4udhkk429bsm3598tfkxtsog8cb7un1t','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-04-02 17:54:55'),
('4z7pw924x5dl9ncd30d0k2zaj5lef2ji','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-07-25 02:00:15'),
('4zmeu66fgz1umxjz5c8mwlkzlyj4cffv','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-05-08 22:32:11'),
('58i6ypmt43yol40jykbd2dntofvnp13y','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 17:22:42'),
('5axjuh37mjx4cqmcn3gt07ax7qv0uhuj','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-09-07 02:31:02'),
('5mykjsn0p7k0v98tt00cy58jzgudi3gi','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-06-15 19:38:28'),
('5s06dvy9aib0cvruous1nxp3x2se9znv','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-14 06:00:46'),
('5ti34nmcaf4qunt5qwkgv8gbbmfq51gz','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-09-05 03:53:38'),
('5uqyyr5qiicwotop3ttmdjbmpt2occt8','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-04-19 00:40:12'),
('5xb9phafwjp4hzugbglb1nuxvnl098f2','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-08-03 03:41:30'),
('63ouv7059usw3wxa5gfcrwsub3wj7oqq','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:35:45'),
('64g9iyr1tekaprtsydn4ipbu0m1at45o','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-13 01:44:04'),
('65x5goiui9cfo6yblwblb43qecua6s3z','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-04-05 12:28:33'),
('66vsgokjzjuczqxtfoowtf3k89ahd2m0','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-09-14 08:38:45'),
('670cjzbpmd2ex9hk1q2zwynxwwuur0gt','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-05-04 17:13:42'),
('69cvt5kdmm7wo4i4e0qsy3kys52s99ce','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-16 05:54:57'),
('6b3v0rwyzmtfqlq9ddpq5vs5rjdug616','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 18:38:06'),
('6bo9yyzlfqkg62z2b6hm2h7mto72fubq','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-08-26 05:17:44'),
('6brf1hputwqqzdasu0d5qwud0djlaksr','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-27 17:59:43'),
('6ckjlgkhrf8k8tlghj7yzbc34djmwzag','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-16 23:45:44'),
('6e02kth8inhyakbf9izyadnzn5xqrbor','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-21 01:00:02'),
('6u5k8mr04iqhz7yph7rkaqzwhkxbacxj','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-06-21 00:46:42'),
('6udqjbk4vsqlb1jt2fbk2pz3g7ji388c','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 17:33:05'),
('6xwxhp6eq5wu0luptbee1k88yes8fwnz','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-14 06:00:37'),
('6z93mtuzmpvr8gw9vkslbze89c62ekj3','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-15 02:30:00'),
('79tye7gzjuqitg5elzt9txv3wgqaf201','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-21 18:38:45'),
('7b1vu3ap2m41c4qy1tt6olhamczpimtz','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-04-04 02:24:31'),
('7km5qlh2b2f078e4rcpboduwux83dbz9','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-04-25 17:20:10'),
('7o6vp3ai8tpc3mz6kzxr3fm6zpio1ljz','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-04-29 03:04:26'),
('7p93sawxrb0ctg827abtrids1lloydex','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-09-01 02:09:56'),
('7uevo4vw3y7zesgriyk9kgn38izpvbel','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-04-10 22:42:04'),
('7wfq1rzw3ak83impje7zep4zqn74r1je','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-04-27 17:02:56'),
('8dyye25cwpi8rwja4i0czqa18u1giuc2','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-05-25 02:52:00'),
('8s17dm7bok5o42hnoi0o1kxapryde2ol','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-05-04 22:13:27'),
('8sqspficloa37cgyxlii9coyl9fio05t','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-05-07 17:51:44'),
('94xcuzzbh0m6s6jfs2zro83jfnni8vzb','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-14 06:00:28'),
('9bvrb6an98ig9bckbdotyrg8mn2zr85z','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-08-10 03:30:35'),
('9pqejm2to4jymhd4z9feb325p5y1fjgv','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-06-21 18:29:54'),
('9sp8lw9nz9ikqbwchudgfsx3jgrv0aqc','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-04-02 18:27:24'),
('9zytb7uy5ji4vsbzeigvdgl67x8ra420','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-21 03:24:51'),
('a23hwzr3xzllv4mfpxft1ghdjv0216qh','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-21 03:25:04'),
('a69dvmn7k8o9n3m59bw1bovo4z2ex5vs','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-04-10 03:45:45'),
('a814dvcwbl2hve5zt0vvagah55wie4or','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-07-13 01:44:44'),
('a98r9x4u8hxmfbrp9561gr8if1lkgmew','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-03-21 02:25:18'),
('aebanv6kpmzw7vuyl6k94jsupaeeiynx','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-09-08 05:04:30'),
('alm2mlqazicrk1c2s9xp2edzsmgrzjwr','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-05-07 23:00:12'),
('ams1f6vhmzvxca7x2xmsjlmc39hn9cjc','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-06-28 18:36:27'),
('anrq1sr55bb7h93yb1rw7xn4y0zvlixs','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-08-21 00:36:00'),
('ave85r2gtzg60wkjqy1zym3qv017bx1c','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-27 17:59:03'),
('awfr94mfi9p0o2i1c6can34tgto0iwgi','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:54:34'),
('axmzd2k59s0c0xfo4lalbkuulocr27hf','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-21 03:25:20'),
('bkcwqgfb70a1f3nesu9idf9qdy0rqubd','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-04-13 04:45:14'),
('bqey5f9onbwvtsbdjc9iyoql46g4z6ko','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-05-04 18:08:47'),
('c742ezkuaprs9l6xsk5r6ypf1k5j96l2','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:44:52'),
('c861zzkdgoflotj4bsuzjx0zez4eiftr','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-15 02:16:49'),
('ccanre91pvbqnu0gm8xpm6wz4qcllnao','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-06-02 08:15:15'),
('chq47yiqzjk8j70f5l5ipzx5os0a8d0o','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-15 02:18:06'),
('ci6o5g6xz18jl59eafoasef14jq8zqpo','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-04-02 18:17:48'),
('d4xaz6mun82wlo0zj0q2b5bqx0nfw9ju','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-09-12 01:33:52'),
('dbm7wqn2dq6hadzkxtdy1ygo5aqo1yvr','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-09-17 22:03:14'),
('dc3i0zshe2vqsa4m5cks23bwkg2ifnm1','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 18:58:08'),
('dd8mkz7h927xwzw2su8pxh950cwcx6ea','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 17:29:34'),
('dgjkccmk09fnhdofllouzqpktxyjppos','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-03-27 01:05:15'),
('dn3gqlejupcy3nb6jdqpmb6n1tpcokq9','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-04-25 02:31:05'),
('dnl3xtbghyfw1o48wi5mi2ow68p00bir','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 20:35:09'),
('dpih8ywx005c7kazzn12u4ze6arzi1r5','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-08-04 02:51:06'),
('dqoiztyjer0tgond7nrz28uh35fvqboc','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-03-31 04:12:16'),
('dqpxdjv4gt1m44fxki90aj36nbg0nne3','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 01:38:16'),
('dra0grmg2iynrg318k2pszop9p46iri8','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-04-23 21:44:19'),
('duy972zsulcugycn0kfctqafnsqkk3be','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-09-20 02:09:01'),
('dxehzhsht6syhhwh7i6eqxmx7f1qe8dz','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-09-01 10:04:38'),
('dxo4jjbxqtxsvneihbhcaxuqnmxutd12','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-09-11 23:26:24'),
('e00kdub2wv20sxrwa2ks2716ekh6nw4h','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-21 01:02:00'),
('e4vekxv5kl99fcolbawt1etu7q4r9gm7','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 17:26:01'),
('e81sw50vbh2qx32wlqqkhtdkikkfk8ll','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-31 03:50:59'),
('ebmhrr1gw4p69d4a8em6o8nnfcnzeu89','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 01:38:16'),
('ecg0wari17c0apb3tebvmv4zkp7bbfyx','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-13 04:11:04'),
('ega0uklvmom6vtraigxwjrufz5zi61b5','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-03-28 01:24:31'),
('ehilimywrspatvnk6n2vgbqxvr03pxsg','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-14 06:01:07'),
('ep983xq8cgjrmu0nq2y2p4zn0hmsytav','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-05-17 00:38:05'),
('es1kvvdsbcj7xeca5mhna7jqbuua2tdr','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-04-19 23:43:48'),
('euuuag78mwtc8bopf8y51t26plxv4312','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-09-11 19:18:20'),
('fgqdnc9h98sfq80pi5expjm6eb7lxdvw','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-06-11 22:03:00'),
('fkg37wf5psgpswt5c8nyewnfag7h7okk','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-13 01:44:46'),
('fmskgq1p4rcb9b38tvy5l7fwwjm7qyi4','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-09-20 00:43:34'),
('fsb4uzo945njaowedlsqvhu1vx3wenr0','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 01:37:13'),
('fveopt53s6p771ubp5p2lmwypzd9mgky','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-13 01:43:46'),
('fzocqel91d026yjy8vb957q780e7qv2s','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-06-29 17:07:19'),
('g0sivbbn49w0h6wb0hlf8mxoc3bu11mw','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-09-12 05:15:56'),
('g1rzebwjoe5yrfe9u91ix5a0iqisofav','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-03 23:24:49'),
('g83suiw2zdqfy1qxc3nj16cf1e40cgyx','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:54:34'),
('gkn66v45tyxhqhcenc3k7t8vr6sc5tuz','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-13 04:11:32'),
('gn3u0rzmeqy3jg49rtefapzorqm5nkbb','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-07-06 03:49:56'),
('gnbdohe400lwpennk9z7wmyser7kthlk','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-04-23 21:44:02'),
('gnta1hqwtq7yytfv7eddwqrqzh98twwx','MGMxMDdjZjNmYWQ1OWViZTZkY2YwNmE2YTU3MmJjNzc4YzE3NzlhMzp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=','2018-09-19 02:29:56'),
('gp02gaq5hwmgs2txhvlidkwdaq4okiog','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-04-19 01:02:16'),
('gsohof42f57evcpytwk3xkisqyd14b7t','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-06-20 22:15:21'),
('gvkav8e2080u24gdfp5xckcgndcdxbfe','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-03-31 00:30:39'),
('h2qltdynhw3f0p56ya8gpbb4kpt4fjgx','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:33:45'),
('hd1zi5a2tusq8ljly5xt6oknaskmqv45','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-21 01:00:38'),
('hfxfp8wgph90i49foorswzbg1818eyon','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-04-26 02:08:12'),
('hjo91gq0fokk4hagoikpuft651p3yo07','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-04-12 02:21:13'),
('hm14ykngl58vek4jhvk2y44tzaz2xbtz','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-06-26 05:40:35'),
('hpmnimslaif5aj823zrk4qy8ulmsvcfu','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-09-12 01:30:08'),
('hqkkxqpfs677a7axoaladxo26nmidi6x','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-09-15 02:00:19'),
('hswf360yetjnk6bjxfn494uaenheb1lz','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-07-04 01:19:21'),
('hx33szhi19iwnalpv2tddno8dzgawxgj','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-05-04 18:29:24'),
('hzssh8rfjuldgauaa6u446jl4p3v0js9','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 17:33:05'),
('i01hvc5gdvm9u6x19tmrgv8b9vm63g9z','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-07-18 00:18:40'),
('i42i4xog742qbtgi5p59qzsx7nv8b322','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-08-28 22:40:42'),
('ifuo4n3zfiud0szdi5cu516vxzrj61h6','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-08-28 18:47:38'),
('ijsfjn4y34hq0qqjyyojly5d655jngh0','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-08-15 06:28:02'),
('iltoq4quwfw6l4lnhv6nzzgzgyqrnhag','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 01:56:33'),
('ir1giad6xjmpkgqnyujbcb7hr4sllf2b','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-03-23 23:13:39'),
('j3ymw9pdzbmhyp3nnn8xod9fdi4x945h','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-04-25 17:39:38'),
('jcz0edomlu9080megmj462hkxa4k059s','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-08-24 01:53:39'),
('je4yl7p1pq9m905zjjsuy8bdhmz39ln1','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 17:25:59'),
('jhchu9h6shkke5rpk80k4gleqou11dg6','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-21 01:00:35'),
('jxplgyt3gz3oxittkqwh81usp5roifxe','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-04-17 06:16:39'),
('kb78w42h4tjo63col1235pzmuw56krvg','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 18:36:06'),
('kdb3o3y1g7z8vk7rli43tnh3mwix07fu','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-06-29 22:00:28'),
('kggkkmn9tnq5rmb23oy9sr1fa3d1iffh','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-08-15 02:20:42'),
('kiwomd9hnikp78zxns0basoecdjq15ub','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-04-17 02:09:21'),
('kljx9z2knvn16zf4q1eoa48ejpdumank','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-08-03 19:53:08'),
('km5pjaq1lpobq2y272adentzmukuupnr','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-04-27 03:57:57'),
('krg0e9glfph4t9t1tg3am1pvs4bjah63','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-07-30 22:00:46'),
('kt8mwcz8o2fmd0b2tt0133aophu0nmbp','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-05-04 01:45:59'),
('kv9qxftchaeyzafgssyybabj2p8kamri','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:35:15'),
('kvr1nq2t9eu9sul8alsrowuyfugi98gd','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-20 22:46:28'),
('kz40nzgjmcpwfmklgx2qt6cwcosekvqg','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:42:44'),
('l46kgl91dyva9mue5e2v3igdmwfyl280','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-07-22 10:53:38'),
('l5iivnoyghy7ondsgczqqx4smm3p2wue','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-08-02 21:58:41'),
('l89mnsggtis91kaa8cffgtzev74y907j','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-07-13 05:37:21'),
('lbdwrhqjbk3i6znbj27c99ycz021dabk','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-03-23 00:10:21'),
('lbe7lqdc19wzk2it8lxi9pbmn9drmb1l','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-08-30 23:27:48'),
('lcd7cfgzojqoyivk730bhvlisk7ugv7n','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-06-27 23:14:17'),
('li97rm2mzya44yrjjw20qizsh1qd3ak5','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-08-30 03:02:39'),
('ln5pkpozr6fpysre2wka00s4lfkik3p3','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-09-11 22:28:29'),
('lp1id13w0rmkfpkyww5fj9nkx04w7cft','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-03-10 02:03:48'),
('lpv07zitsumeurajqozvgp65enum17eb','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-03-15 02:22:19'),
('lytoe7jpsiyxom52xz1j4wlzieac62zc','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-09-13 00:00:44'),
('m5t46btwwfeduxn3f5i2u7d6uzaxrfjs','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 01:37:13'),
('m6orjxph9aiat77ibt1ca3po1jb0yzds','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:36:25'),
('m6zatw1tchas1q2tk1vtkrqvnxm05ofg','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-27 17:59:18'),
('mdoa41enkddnnt0iq5eu172pd365nago','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 17:29:34'),
('mpz6h4gooy47falircj69mygnxzae9wm','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-06-26 19:45:42'),
('mq8hg5u9i0sxbeydwklap79ml4yhlumv','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-05-22 05:44:36'),
('mr91xs2s2bny7o9fns6nnnhm9t2wgwm3','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-05-04 22:09:45'),
('n2zm65r7v0vhuuazc9ezf91ko5mjt265','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-05-04 18:13:01'),
('n49qv5kvih47d2mnn9i58hjbuheezf4u','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-14 06:00:21'),
('n6kmtsh1wm56qkyqat1ly2fl2o6iti7s','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-06-29 06:20:45'),
('ndltgfw8mblizcmtk2iswgr31jlajmtc','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-08-08 04:02:43'),
('ndv1vhv4njs345cyeavqosoko0bfmi1b','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-03-14 02:37:59'),
('nhzycbpnkppd45p247z533v67q1ncp5m','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-08-11 01:40:49'),
('nifeyb0cwaiwhp4955s2tzap2arws7ng','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:47:39'),
('nklfkxiagl747o2bdzgv4zc0z1ijdf6u','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-31 03:57:25'),
('no849fj6pr1lmm1c38sjztiph1yee7h6','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-04-09 03:27:43'),
('nya69i19iq90egfpdzu4qqsx5jgkl0rd','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-07-11 02:00:36'),
('nywt1q2mhcul4evfwo2eynulmjoh7fuw','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-03-16 02:07:50'),
('o681mszqvbxufuor5l8d8m3kfzytat29','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:44:52'),
('o6w4fr6psn0x2jddxljmqahoe2obbgjq','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-05-18 02:30:01'),
('o9852ly1c87iwp7c7e90t6sa0ohjmzhc','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-05-23 03:35:26'),
('od7ioqwlr6acxy09fcvv7sh3l537pdsw','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-05-16 19:29:37'),
('ojlce4j463v28gh9iuadboz2dxy72c7r','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-04-04 22:50:50'),
('oyv77kxpjh5ssyyfdn68n9fe2l8675wi','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-08-24 07:52:40'),
('p0pjdg957v1alke0fyz0l2alq3czlqdc','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-04-02 21:54:19'),
('p56rzkkv5bi55b1sdlhx66nvs1dkjp9f','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-09-05 05:08:12'),
('pajgkzsxs055aq867wha1qgcbv4ynnjg','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 20:35:05'),
('pglwk28apmp271vu2bfz2eyxxo5kjghi','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-21 01:00:21'),
('plzgensgkmwyx34i0mi8iudao2go5fyb','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-31 04:03:07'),
('pqhwrs5ffzspvt32frl7apc940qzppga','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-07-18 00:25:32'),
('pss9g83c14yndzwy2wawbzgjk61tlgut','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-07-09 17:36:40'),
('psz6dozpfoe8oidiri2de9zj6rkt9s10','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-20 23:01:07'),
('ptdx02090f7lao92l3rmoturbpf38rim','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-08-22 18:48:01'),
('px2i0hmc415opx5mg219d2sd9fs2iqeq','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-09-11 22:03:34'),
('py9skjcs2rx3mnha524rduh4z36oshl4','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-04-17 00:33:18'),
('q0tt420klgldr96fxvblfb1hibzg6jox','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-04-04 03:28:58'),
('q9evigmdhq29980zrqmbdmfhfjln11me','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-13 04:11:21'),
('qb0j0o9wfkx3j5ii7nh55nz41vkypjo0','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-06-28 03:23:11'),
('qqm3mxt52p2kf24gsjzpasr658rh96dz','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-09-07 13:42:11'),
('qw36na5yyc0bkttnke69dt5qfg8z8wov','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-07-20 02:35:52'),
('qxanti5lfesjapwz5oi3i5fagsova0d2','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-27 00:42:20'),
('r97jhul6ib328rjb5iylo73mcjvgxvwx','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-09-11 18:56:14'),
('rhef6p9dzmbngt3rc5ukubjmzq3sxs85','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-04-14 02:00:19'),
('rl75w1jbdkhpxytuugwv7wh0jf12u4to','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 01:34:45'),
('rpv1awwg874i625xyrfx29urupg5195q','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-08-01 02:18:28'),
('s1ffrtdy2qhr18plr9xt09qi7z5mwd6f','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-08-22 04:55:44'),
('sg36wmy7a4hjp3l7dyswv305f1bi53zz','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-06-19 19:00:47'),
('sj43rz1c7ixsvlbkkvlezgc9gtge0vbj','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-05-04 18:39:07'),
('st54h4i22egqespjnp09gwh64jr970uq','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-05-30 04:09:48'),
('su2yhglbe3w4x4i7d9nciigflhxxqmtp','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-05-11 05:20:12'),
('swqpd1jhwv40h5axu7lq0mz3s1vwxop6','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-07-11 04:43:51'),
('sxxgixgcwytmdai3u8d0dr22vhc2pnqy','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-13 04:11:12'),
('t03dax3sruoghez8tdcbju3fj3w0v5pk','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-03-28 00:27:20'),
('t0uvscuoaiuihsezpd0b7paewz4ncxcc','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-13 01:44:02'),
('t12dzdeng4144itif8u1u6c7zl7xagum','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-08-03 02:08:32'),
('t6u67t43e49oe3x4vzhlb0va548jccc8','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-31 04:03:31'),
('t8uuc0h0ec4r67zny0hqfudbmy00pg31','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-03-21 04:12:46'),
('tag5w6nzl0utp1snuwh2jryxha9ub7fj','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-05-04 18:33:43'),
('tc3z8fghxidqisujpnvug7lxg21s6dnc','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-09-15 02:33:37'),
('tlrk97v4eqc72erxrgp08yjlz2j8dm49','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-09-15 19:19:54'),
('tmkkdoopiol03kova3yv5sj5qlgostzb','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-05-04 16:53:35'),
('trmtd2tu92yksquo7k2awsz69h2k2hgf','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-03-20 00:09:29'),
('tw5gff581bx0vx3eqlxn0eeice3e6lc5','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-03-27 02:24:30'),
('txxpe3alvfzcun6305iq9s3vyespkwno','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:53:42'),
('tylxlbvemk0chtqft4rkn0l5cfakm08s','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-07-04 05:26:38'),
('u2frzdcwhilxgw6p62ss4qm2zvjz3bma','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-07-27 03:52:23'),
('u2wqgbgwjyasnscas6lbi9elfqqlhlz8','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-08-22 06:31:39'),
('u2zb5257mdw3tq4w4qd2kmgw4y8ilbvy','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-03-21 17:44:54'),
('udslbgmstxllwppflhstnlmyeyvodqpp','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-04-25 02:30:28'),
('ug6aoft98h5o0z21gdbxina4cnk779ib','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-09-19 01:37:24'),
('uim61gfnz821hm2maomr40v8kwh66ec1','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-06-20 19:53:03'),
('ujg3ekgh5tasw0jp15d94wd6u877awx6','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-09-11 18:23:52'),
('ulne9h4kmmdphrounx9nji274af6yk91','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-05-11 23:27:37'),
('uqu7cdv06eysc6plca2sexsah8y14ygg','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:35:45'),
('utdguw10z8pplc51tjsv6vbbhx3sfbkc','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-09-11 18:33:43'),
('uywo09kogmaabeuk737l6wri5fmmuq7o','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-06-06 03:50:16'),
('vaiz8incd02nyxtitwopb5l8zqm4kbes','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-06-01 03:52:46'),
('vv6zkf364e68xn4pivmo6d9cees2f8zp','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-08-09 04:41:46'),
('vvhwtwkv6qcp3beo63j9pzxw4a1jzubu','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:43:36'),
('vxa8xk27turqoy0aj3kfjs6h00xntepg','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-08-27 01:51:10'),
('vyp1a5a1i88qcmxfkh2vfh208s2ky92f','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 17:22:42'),
('w3f8m68cygdu4g7pmx1cgw2lkf2tkejn','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:45:17'),
('w4rx4iynn0ne3aanlnotdwmcl1k5qwn7','OTA3ZjdlMDI0ZTdlYWUyZmRlZmIxY2NiZTMzYWI4N2VjNjU2MjViZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9pZCI6MSwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-08-01 07:11:22'),
('w8q5yn9y6oe3dam0fr1o56jbe7bxawds','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-06-09 00:34:43'),
('wtromeiyg62753z2quv9ou46ditv15le','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-08-10 06:37:06'),
('wuq5tswn86mfq387flqxqq4gylw9ujpp','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-04-11 01:34:51'),
('x6p8ktlcd2slrjlho55v0tjw1ksd3w3g','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-08-25 10:19:23'),
('xc9wolkzu16r876q1jxkmjrrb6bz489d','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-27 00:42:03'),
('xf0qcis0595nosr7dm3g8hd4z7vn9ptf','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-05-04 05:53:38'),
('xgo51urm1vehkze392n9xgyagni811xv','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-06-30 02:04:09'),
('xkarfr9fjoojgu7jf8yh6p3uqkb97fxz','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-13 01:44:11'),
('xycqqp473fy8lcgs3cegc0lrtdxfc92k','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-30 00:21:55'),
('xz1ve50zhyb1xykxajaj2lbj21vam23x','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-08-31 01:53:38'),
('y1ongqbnig5gd343axwa614sbn6zpwbw','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-31 05:19:47'),
('y8habgxqujefbca30uqeasys5fvpfsm0','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-13 04:10:53'),
('y8l1rs6e18hseibvl3v9gs2j053dn0xe','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-05-09 02:42:02'),
('y9rk1iqksugc1zue0ds0tbr8zd1vtb8e','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-06-27 16:30:50'),
('yabukdgju3b6sk0e82l11ygd5u042wih','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-04-25 08:19:44'),
('yfrjwtmon5sdagx9iz1zg6fqukkouv1r','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-08-16 08:21:25'),
('ykgooxhazwypc47z29zbkljzgvf3q85m','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-05-04 21:54:46'),
('yl9ewboiauqkkvp082yxn5qaibkuefpy','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-06-14 17:20:47'),
('yr01ehnrfd42bbbq94ucmta4v0tguaaj','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-08-14 19:53:45'),
('ytdrok4d5sp856yuquvz44vutq53yfbm','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-03-30 05:11:32'),
('yxgnl1rmlepwm3vwjkqdlzn4or81yedc','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-13 04:10:43'),
('yyle9awowpkipmm7wgzuvut271c9lq9u','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-07-16 22:39:59'),
('z2r7ggda39049y2qvfdr9c4z52qcgkfe','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-06-01 03:11:47'),
('z6v1imd2za79lkjd3qwl5oxnvih4tqu9','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-04-18 08:46:25'),
('zcda950f0grlptwztbcw3ctbhul94m8n','ZTk3MmYzNTViZWE4MTYzYmY2ODMwZjJjZjIxODI0Njc1MmI1MjIxODp7ImZ1bl9hdXRoIjp7fSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMCwiX2F1dGhfdXNlcl9oYXNoIjoiOGZiNDFjOGYyNGE0YTcyYjY5NWUxNDFjM2UyMTA4YmY1MDVjNTVkOCIsIl9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2018-03-13 02:12:46'),
('zcqujolk3wnuef41a2t6anrpf7q5o4dm','NzNhZDE5YWFmYjczZGM2OTk5YTAwNmYyYjk5NDMyNjZiMjMyMjdlMDp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwiZWRpdF9wYXNzIjp0cnVlLCJzZXJ2ZXJfYXVkaXQiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9zZXNzaW9uX2V4cGlyeSI6Mjg4MDAsIl9hdXRoX3VzZXJfaGFzaCI6IjA3ZDBiNzc1ZjQyNmYxMTllMjBkZTUwYWJmNGI2NGI5ZGU5Zjk1MzYiLCJfYXV0aF91c2VyX2lkIjoxNywiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==','2018-04-18 02:42:07'),
('zkdpepv1fl8nw697nll7japmwbw3666q','OTY2OWNiODA0OTUxNmEwMjY3YmNkNGJkZTgwZmNkNzIwNzAzMWRlZjp7ImZ1bl9hdXRoIjp7fSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZmI0MWM4ZjI0YTRhNzJiNjk1ZTE0MWMzZTIxMDhiZjUwNWM1NWQ4IiwiX2F1dGhfdXNlcl9pZCI6MSwiX3Nlc3Npb25fZXhwaXJ5IjoyODgwMH0=','2018-04-04 07:19:57'),
('zmtz58vvdx6w8j8cqi6sqs388x1nj61t','OTI4ZmYzM2QwMjllNTljZWJiZjA2OGYxZDMwNDBkMzQ3Yzg3YWFlZTp7Il9zZXNzaW9uX2V4cGlyeSI6Mjg4MDB9','2018-03-15 02:17:54'),
('zogpii4l1xj0v0vzeuf753ep7aq0yz7h','NGVlZWI2ODI5ZDJmZDU2ZjVhNDFjYmYyOGZhOTYxYTk3ZWM1ZTJlOTp7ImZ1bl9hdXRoIjp7ImVkaXRfaG9zdCI6dHJ1ZSwic2FsdF9rZXlzIjp0cnVlLCJhdXRoX2xvZyI6dHJ1ZSwiZGVsZXRlX3VzZXIiOnRydWUsImF1dGhfaGlnaHN0YXRlIjp0cnVlLCJzZXR1cF9zeXN0ZW0iOnRydWUsImRlbF9pZGMiOnRydWUsImF1dGhfcHJvamVjdCI6dHJ1ZSwiZGVsZXRlX2hvc3QiOnRydWUsImVkaXRfcHJvamVjdCI6dHJ1ZSwiYWRkX3Byb2plY3QiOnRydWUsImFkZF9ob3N0Ijp0cnVlLCJ1cGxvYWRfc3lzdGVtIjp0cnVlLCJlZGl0X2lkYyI6dHJ1ZSwicHJvamVjdF9hdXRoIjp0cnVlLCJlZGl0X3VzZXIiOnRydWUsImFkZF91c2VyIjp0cnVlLCJ1cGRhdGVfaG9zdCI6dHJ1ZSwiYmF0X2FkZF9ob3N0Ijp0cnVlLCJzZWxlY3RfaG9zdCI6dHJ1ZSwic2VydmVyX2F1ZGl0Ijp0cnVlLCJlZGl0X3Bhc3MiOnRydWUsImFkZF9kZXBhcnRtZW50Ijp0cnVlLCJzZWxlY3RfaWRjIjp0cnVlLCJhZGRfaWRjIjp0cnVlLCJjbWRiX2xvZyI6dHJ1ZX0sIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDdkMGI3NzVmNDI2ZjExOWUyMGRlNTBhYmY0YjY0YjlkZTlmOTUzNiIsIl9hdXRoX3VzZXJfaWQiOjE3LCJfc2Vzc2lvbl9leHBpcnkiOjI4ODAwfQ==','2018-04-13 02:22:28');
DROP TABLE IF EXISTS  `project_swan_push_user`;
CREATE TABLE `project_swan_push_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_swan_id` char(32) NOT NULL,
  `customuser_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_swan_id` (`project_swan_id`,`customuser_id`),
  KEY `project_swan_push_user_a3e2b54e` (`project_swan_id`),
  KEY `project_swan_push_user_721e74b0` (`customuser_id`),
  CONSTRAINT `project_sw_customuser_id_3822f6570ff53a30_fk_users_customuser_id` FOREIGN KEY (`customuser_id`) REFERENCES `users_customuser` (`id`),
  CONSTRAINT `project_swa_project_swan_id_79291c907c649f9_fk_project_swan_uuid` FOREIGN KEY (`project_swan_id`) REFERENCES `project_swan` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

insert into `project_swan_push_user`(`id`,`project_swan_id`,`customuser_id`) values
('18','00f09e54e29a47dc866f949ba755b660','17'),
('21','05f204d07621404db22e893d5fa29d33','17'),
('20','f81f34d2614541289c778b66df22ed9d','17'),
('19','f832512dade74e029905c18afcae4691','17');
DROP TABLE IF EXISTS  `cmdb_auth_user_auth_cmdb`;
CREATE TABLE `cmdb_auth_user_auth_cmdb` (
  `uuid` char(32) NOT NULL,
  `select_host` tinyint(1) NOT NULL,
  `edit_host` tinyint(1) NOT NULL,
  `update_host` tinyint(1) NOT NULL,
  `add_host` tinyint(1) NOT NULL,
  `bat_add_host` tinyint(1) NOT NULL,
  `delete_host` tinyint(1) NOT NULL,
  `add_line_auth` tinyint(1) NOT NULL,
  `auth_project` tinyint(1) NOT NULL,
  `auth_highstate` tinyint(1) NOT NULL,
  `add_user` tinyint(1) NOT NULL,
  `edit_user` tinyint(1) NOT NULL,
  `edit_pass` tinyint(1) NOT NULL,
  `delete_user` tinyint(1) NOT NULL,
  `add_department` tinyint(1) NOT NULL,
  `select_idc` tinyint(1) NOT NULL,
  `add_idc` tinyint(1) NOT NULL,
  `edit_idc` tinyint(1) NOT NULL,
  `del_idc` tinyint(1) NOT NULL,
  `setup_system` tinyint(1) NOT NULL,
  `upload_system` tinyint(1) NOT NULL,
  `salt_keys` tinyint(1) NOT NULL,
  `project_auth` tinyint(1) NOT NULL,
  `add_project` tinyint(1) NOT NULL,
  `edit_project` tinyint(1) NOT NULL,
  `delete_project` tinyint(1) NOT NULL,
  `auth_log` tinyint(1) NOT NULL,
  `cmdb_log` tinyint(1) NOT NULL,
  `server_audit` tinyint(1) NOT NULL,
  `group_name_id` char(32) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `cmdb_auth_user_auth_cmdb_e074f38c` (`group_name_id`),
  CONSTRAINT `cmdb_group_name_id_40e2c7660ed38540_fk_cmdb_auth_auth_group_uuid` FOREIGN KEY (`group_name_id`) REFERENCES `cmdb_auth_auth_group` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `cmdb_auth_user_auth_cmdb`(`uuid`,`select_host`,`edit_host`,`update_host`,`add_host`,`bat_add_host`,`delete_host`,`add_line_auth`,`auth_project`,`auth_highstate`,`add_user`,`edit_user`,`edit_pass`,`delete_user`,`add_department`,`select_idc`,`add_idc`,`edit_idc`,`del_idc`,`setup_system`,`upload_system`,`salt_keys`,`project_auth`,`add_project`,`edit_project`,`delete_project`,`auth_log`,`cmdb_log`,`server_audit`,`group_name_id`) values
('098820a221b74e4c9656be5a923b56f6','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','846e66dd279647dfb1d1963fc79fb27f');
DROP TABLE IF EXISTS  `users_customuser_groups`;
CREATE TABLE `users_customuser_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customuser_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customuser_id` (`customuser_id`,`group_id`),
  KEY `users_customuser_groups_721e74b0` (`customuser_id`),
  KEY `users_customuser_groups_0e939a4f` (`group_id`),
  CONSTRAINT `users_cust_customuser_id_3ff7151cd75e2907_fk_users_customuser_id` FOREIGN KEY (`customuser_id`) REFERENCES `users_customuser` (`id`),
  CONSTRAINT `users_customuser_grou_group_id_7bd979d963ceefdb_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `users_server_auth`;
CREATE TABLE `users_server_auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_ip` char(15) DEFAULT NULL,
  `user_name` varchar(20) DEFAULT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `auth_weights` tinyint(1) NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `assets_idc`;
CREATE TABLE `assets_idc` (
  `uuid` char(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `bandwidth` varchar(64) DEFAULT NULL,
  `phone` varchar(32) NOT NULL,
  `linkman` varchar(32) DEFAULT NULL,
  `address` varchar(128) DEFAULT NULL,
  `network` longtext,
  `create_time` date NOT NULL,
  `operator` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `comment` longtext,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `assets_idc`(`uuid`,`name`,`bandwidth`,`phone`,`linkman`,`address`,`network`,`create_time`,`operator`,`type`,`comment`) values
('eb9061fdb6c9404f937105c4a34b0781','rzjf-rebuild','rz','15958145004','15958145004','rzjf','172.16.0.16','2018-03-12','0','1','rzjf'),
('fdc800201b6e4c7baca23d3720e0e14d','报废库房','100m','1598145004','15958145004','aliyun','172.16.1.1/24','2018-04-08','0',null,'');
DROP TABLE IF EXISTS  `salt_ui_setuplog`;
CREATE TABLE `salt_ui_setuplog` (
  `uuid` char(32) NOT NULL,
  `content` longtext NOT NULL,
  `status` int(11) NOT NULL,
  `approve_time` datetime DEFAULT NULL,
  `reject_reason` longtext,
  `date_created` datetime NOT NULL,
  `run_time` datetime DEFAULT NULL,
  `approve_user_id` int(11) DEFAULT NULL,
  `business_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `salt_ui_setuplog_549dea8c` (`approve_user_id`),
  KEY `salt_ui_setuplog_2f4e4ac4` (`business_id`),
  KEY `salt_ui_setuplog_e8701ad4` (`user_id`),
  CONSTRAINT `salt_ui__approve_user_id_6c1570f72dd3c666_fk_users_customuser_id` FOREIGN KEY (`approve_user_id`) REFERENCES `users_customuser` (`id`),
  CONSTRAINT `salt_ui_setu_business_id_3f48417490749bc5_fk_assets_project_uuid` FOREIGN KEY (`business_id`) REFERENCES `assets_project` (`uuid`),
  CONSTRAINT `salt_ui_setuplog_user_id_23d803f7d2e28ce0_fk_users_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `assets_zabbixrecord`;
CREATE TABLE `assets_zabbixrecord` (
  `uuid` char(32) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `info` longtext,
  `time` datetime NOT NULL,
  `comment` longtext,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `salt_ui_operationlog`;
CREATE TABLE `salt_ui_operationlog` (
  `uuid` char(32) NOT NULL,
  `content` longtext NOT NULL,
  `mail_list` longtext,
  `mail_title` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL,
  `mail_status` tinyint(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `salt_ui_operationlog_e8701ad4` (`user_id`),
  CONSTRAINT `salt_ui_operatio_user_id_69db0895519a6008_fk_users_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `users_customuser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `swan_apply`;
CREATE TABLE `swan_apply` (
  `uuid` char(32) NOT NULL,
  `applyer` varchar(32) DEFAULT NULL,
  `project_name` varchar(20) DEFAULT NULL,
  `module_name` varchar(200) DEFAULT NULL,
  `module_type` int(10) unsigned DEFAULT NULL,
  `module_tgt` varchar(50) DEFAULT NULL,
  `qa` varchar(20) DEFAULT NULL,
  `op` varchar(20) DEFAULT NULL,
  `comment` longtext,
  `status` int(10) unsigned DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_one` datetime DEFAULT NULL,
  `date_ended` datetime DEFAULT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `assets_hostrecord`;
CREATE TABLE `assets_hostrecord` (
  `uuid` char(32) NOT NULL,
  `user` varchar(30) DEFAULT NULL,
  `time` datetime NOT NULL,
  `content` longtext,
  `comment` longtext,
  `host_id` char(32) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `assets_hostrecord_8396f175` (`host_id`),
  CONSTRAINT `assets_hostrecord_host_id_3b740786ef5f690a_fk_assets_host_uuid` FOREIGN KEY (`host_id`) REFERENCES `assets_host` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `assets_hostrecord`(`uuid`,`user`,`time`,`content`,`comment`,`host_id`) values
('05c2a99171fa4f33be4e9813d7f7dc29','admin','2018-03-13 10:10:05','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-borrow\']',null,'1da4d56bff0d49ce9fb61b7161958410'),
('0778e0db7c3a4f93bddf74c54b662521','admin','2018-03-13 10:07:17','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-redpacket\']',null,'f055b5f0a0e34e5aab4344fc0e25b195'),
('0a95d46bb9d5433cb2b54fc94d7c337d','admin','2018-03-13 11:18:45','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-rplan\']',null,'53c8c24011c6496fae19d451b4d87e0d'),
('108f0d432e964e15bfad54685004ad4e','admin','2018-03-13 10:06:34','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-account\']',null,'4a4e9bd4d70a4d56bd1c7cfff07c9acd'),
('1239c6082acf4cc3b803defd8dd5ea05','admin','2018-03-13 10:58:45','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-rplan\']',null,'4d49b5d9919e4a92b77c8b49f031a2ae'),
('18d757d5860d432bb09511d4ac3df335','admin','2018-03-12 18:06:11','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-content\']',null,'ebd6b633359242b0a5d3ffe81b472294'),
('19f9e05b24e5431d9f4d67ee1fc2f415','admin','2018-03-13 10:06:08','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-borrow\']',null,'68720adbd74a42ccbd13813b133f5e87'),
('1ac9f40f8f7b484582071de30605c81e','admin','2018-03-13 10:10:25','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-customer\']',null,'ce29d96613d54a6bb34c779be5eb2320'),
('1bdda2d9b4204812a0070e317b71a0e4','admin','2018-03-13 10:03:09','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-third\']',null,'00a453cc901a4852ba4bc3ec3e6f1171'),
('1c428587529740018280e12cd1fd3b58','admin','2018-03-12 15:56:24','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-app\', u\'\\u73af\\u5883\\u7531  \\u66f4\\u6539\\u4e3a prod\']',null,'8495bdb243ba4fd7834a541935296a16'),
('210a2bd7fb0a4a6c9b55fca8cf447e6a','admin','2018-03-12 17:47:14','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-redemption\']',null,'cea2ceeeb9d5411b870117c4493e7bf7'),
('29f3fa66d5f04583b8ee23c35f6989dc','admin','2018-03-13 10:58:17','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-accountlog\']',null,'373310488a2a4db2af33ad7989ea01a6'),
('30f0325bfc94472c8f0ff9e5bef7e4ad','admin','2018-03-13 10:03:30','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-redpacket\']',null,'2a8b5327d0eb4119b761358429d5221b'),
('33103123e77c4547a1de738db0f2decf','admin','2018-03-13 10:07:57','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-third\']',null,'f0970a4c458440b8bf8aa03e6f8962dc'),
('3a9805cdf12c4fcd83205b8402ca6ada','admin','2018-03-13 11:19:04','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-consumer\']',null,'e17795d5d51a4bc6986f1c4c3803c215'),
('4062ed904c804ad49c0f54e9d9489fd3','admin','2018-03-13 10:59:01','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-consumer\']',null,'6a2d404a802c4c20bf7ce1733a221096'),
('46fe65d992f540aca8ceb8364167b3ef','admin','2018-06-19 23:09:36','[u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531 rz-web-bi \\u66f4\\u6539\\u4e3a rz-web-ups,rz-web-bi\']',null,'0ee19bdefd474ca69f971ba9565ba336'),
('4760a0bd03d84acda97574cc43f972b8','admin','2018-03-12 16:34:41','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\']',null,'39831ac380474932aeda749be56a8a2d'),
('4a77eb7751424cefa1fb6af428de58c9','hejianxiong','2018-06-26 11:44:58','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u623f\\u95f4\\u53f7\\u7531  \\u66f4\\u6539\\u4e3a 3-2\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-bidweb\']',null,'c02f6dcc9e9e4266a01786ac4dc8a910'),
('4b107ca977cb4527a7be6b0f33055ba3','admin','2018-03-13 10:57:50','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-consumer\']',null,'2fade89f55da4583ab2e8172ab3ffccc'),
('4e6619b49bea45ad875e32673fd716b5','admin','2018-06-25 21:01:11','[u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531 rz-web-benchmarking,rz-service-bidweb,rz-service-checkbid \\u66f4\\u6539\\u4e3a rz-web-benchmarking,rz-service-checkbid\']',null,'d248814a89cf4cd0bd280c23dcb01b38'),
('522f32a919e541f48adecf940117cc67','admin','2018-03-13 11:00:29','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-task\']',null,'f16f80fb12e24a828da7fdc20bf0baf1'),
('524bbfd3b43343eab1b507fc6553a4fa','admin','2018-06-26 11:47:02','[u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531 rz-service-redemption,rz-service-bidweb \\u66f4\\u6539\\u4e3a rz-service-redemption\']',null,'63d3f007774241f9888b4cd931a96991'),
('57a8fb31bbaf4ba681f0b0f5d1627670','admin','2018-03-13 10:02:05','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-borrow\']',null,'cc65ad7c5c5d4ee28d618a1a48fcf2f7'),
('5e4a8ca0e3eb4c4cbfa025de1b3a587f','admin','2018-03-12 15:55:49','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-app\', u\'\\u73af\\u5883\\u7531  \\u66f4\\u6539\\u4e3a prod\']',null,'e806abad59b344b4850f23512d94d192'),
('6450f37cec3945a79fd908b74ffa04bb','admin','2018-03-13 11:11:09','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-rplan\']',null,'7f46c2dabac0461d8b3b785ddc548368'),
('660ae3328bbe43a48fa1fbcb13b05f33','admin','2018-03-13 10:22:27','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u673a\\u623f\\u7531 \\u65e0 \\u66f4\\u6539\\u4e3a rzjf-rebuild\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-customer\']',null,'f49bfd6d64b84f1388ee55d884bdb835'),
('69eaab1410774d95a5b2e16602534356','admin','2018-06-25 21:06:45','[u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531 rz-service-redemption \\u66f4\\u6539\\u4e3a rz-service-redemption,rz-service-bidweb\']',null,'63d3f007774241f9888b4cd931a96991'),
('6f6592fd8abc43d9ac18dbda45ea5d7d','admin','2018-03-13 10:59:19','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-task\']',null,'281ee4bdd589466d8ff23f37e74db9d1'),
('6f711352a6654ffe96a9d66fe5b19ead','admin','2018-03-13 10:05:21','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-bi\']',null,'0ee19bdefd474ca69f971ba9565ba336'),
('71cf32df9f5a41eb93081a4867b4c4c4','admin','2018-03-13 11:00:54','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-redemption\']',null,'f4f7353dc25a4c3c965c2e1b1760ebe6'),
('75a974feed6645dab4ffe3c2ebdb55a3','admin','2018-03-12 16:04:47','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-pc\', u\'\\u73af\\u5883\\u7531  \\u66f4\\u6539\\u4e3a prod\']',null,'f39ce94c495a4a7081f6a5140b9ba3d2'),
('7668746c4c0c4b70baece494bc1c8ab8','admin','2018-03-12 16:34:16','[u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-boss\']',null,'39831ac380474932aeda749be56a8a2d'),
('794cd630623d475a812ef341ebbbed64','admin','2018-03-12 18:06:31','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-content\']',null,'434e41ed69b94147a33d3991bed8bded'),
('7c3bc43816924faf9073ce1b9d9c3621','admin','2018-03-12 16:04:27','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-pc\', u\'\\u73af\\u5883\\u7531  \\u66f4\\u6539\\u4e3a prod\']',null,'40eaa2e55390498482e29613946a4a52'),
('7cad0e39499747db9ebc8fc821e44fb6','admin','2018-03-12 15:51:23','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-app\', u\'\\u73af\\u5883\\u7531  \\u66f4\\u6539\\u4e3a prod\']',null,'920d7f5d1c5f45ea8ad60ebdbc95cdb7'),
('7e6c6c8028f7438ba9aea8b5a7ae7bf0','admin','2018-06-25 21:02:15','[u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531 rz-service-redemption \\u66f4\\u6539\\u4e3a rz-service-redemption,rz-service-bidweb\']',null,'f4f7353dc25a4c3c965c2e1b1760ebe6'),
('7ee5717bed744b5f9a2585737af72643','admin','2018-03-13 11:18:07','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-taskcompare\']',null,'573995d50bba43be978599a41861faf7'),
('87b71c33279b43048ad6020f55a40ffe','admin','2018-03-12 16:37:33','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-callback\']',null,'e756c7646fbd4deb8ddf488666f9c56f'),
('898e3266c3a34e83b63fa49e6d81e389','admin','2018-03-13 11:18:23','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-accountlog\']',null,'c880688c3558450ca198bb40bc24a824'),
('8cab2f3caee34e7a8ba61918c20dd6d3','admin','2018-03-13 11:20:15','[u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531 rz-service-accountlog \\u66f4\\u6539\\u4e3a rz-service-rplan\']',null,'ebc801311a7448d2b9e5702b50f91915'),
('8ecf79c187c94c028fc6722ab33addab','admin','2018-03-13 11:19:38','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-task\']',null,'b3d5549560294b55be66e879ce50cc63'),
('97816f95b8fa4dc4b56ecd8aef601b03','admin','2018-03-13 10:03:53','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-redpacket\']',null,'a90f2ad509bf45038475de14b222254b'),
('9a143c6ebe3a465ca4cccbb6360387fd','admin','2018-03-13 11:12:09','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-accountlog\']',null,'331e180944b54fc2b93ea1a002aff9e3'),
('9c9feadf8e694d7e98aaf56275fae2b4','admin','2018-03-12 18:01:52','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-borrow\']',null,'80c84e2365f84c3c8acb64d7c7110ee9'),
('9d16da648f764fafaf34d826cd964553','admin','2018-03-13 10:05:52','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-customer\']',null,'a2ddd6b350134e29b61de1632f99951c'),
('9ffd90f66c5b40cc81aadaeee51023c6','admin','2018-03-13 11:00:11','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-consumer\']',null,'fc85d1b92a20459ca6d282cefafef864'),
('a01d4b023abe4a4fa8ac9a264cc22bd2','admin','2018-03-12 15:51:52','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-app\', u\'\\u73af\\u5883\\u7531  \\u66f4\\u6539\\u4e3a prod\']',null,'f11b4a0b622b4f529aa78f87b3278f95'),
('a6af04c8cf9f49b49c5afea515e1e321','admin','2018-03-13 10:06:58','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-third\']',null,'cd90c144576e4283a42d881c290d958b'),
('a7855b4e09884c59ba9ad3caea2cc48d','admin','2018-03-12 18:01:29','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-customer\']',null,'70700e3193eb40d4b04b19d50366c738'),
('a87cf3c0382d4055a3515f26feb03108','admin','2018-03-15 18:03:38','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz23-service-taskoffline\']',null,'c212701463a64565b78570d6b8a3f327'),
('ada7c7a55b424589b54a016f8869956e','admin','2018-03-12 15:35:10','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-app\', u\'\\u73af\\u5883\\u7531  \\u66f4\\u6539\\u4e3a prod\']',null,'d63d5ce484374594b5c28ffbfd4b1454'),
('bc8cad0c62694dbaac633820b3136817','admin','2018-03-13 11:12:35','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u673a\\u623f\\u7531 \\u65e0 \\u66f4\\u6539\\u4e3a rzjf-rebuild\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-redemption\']',null,'63d3f007774241f9888b4cd931a96991'),
('bdd8d21844c1427da527a4a08f99c9b7','admin','2018-03-13 11:11:42','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-taskcompare\']',null,'6289d71d26c14641811cf8f868b3fea6'),
('c4a511267393457880820388e9b886cf','admin','2018-03-13 10:51:51','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u673a\\u623f\\u7531 \\u65e0 \\u66f4\\u6539\\u4e3a rzjf-rebuild\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a salt-master\']',null,'f634fc1f5c93410dbd523b6d70e51618'),
('c6b5062ae24047e8b0f4c8bf87e67029','hejianxiong','2018-07-03 15:37:16','[u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531 rz-web-pc \\u66f4\\u6539\\u4e3a \']',null,'40eaa2e55390498482e29613946a4a52'),
('c77331f6aa734fe58d8a0179c2638887','admin','2018-03-13 10:04:33','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-third\']',null,'aca69ae4047043648bd7d22ac8768c78'),
('cde78ea623ae48dda1340db55a51fe58','admin','2018-03-12 16:38:05','[u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-callback\']',null,'661e8acebc664513a1c190518bf509df'),
('d0eafb90421c432aa4892f022d667d63','admin','2018-06-25 14:31:10','[u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531 rz-web-benchmarking \\u66f4\\u6539\\u4e3a rz-web-benchmarking,rz-service-bidweb,rz-service-checkbid\']',null,'d248814a89cf4cd0bd280c23dcb01b38'),
('d8ed74d1d6ac4e129b620cdebf85a258','admin','2018-03-13 10:56:00','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-benchmarking\']',null,'d248814a89cf4cd0bd280c23dcb01b38'),
('dfd5fbc0729941ec8ccd5eeb3f212d8f','admin','2018-03-13 10:59:34','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-accountlog\']',null,'96716780541c47f9a717f6dfb38dbbb8'),
('e223516e28f24e32a3619d0518d55890','admin','2018-03-12 16:37:47','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\']',null,'661e8acebc664513a1c190518bf509df'),
('e33f90f486fc4e8e947d12420b3423d8','admin','2018-03-13 10:09:44','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-account\']',null,'5e74a72799ca4c58a5d3a8ec2f19dd81'),
('e586cdb2948c4cb586b074be243e7462','admin','2018-03-12 16:02:47','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-pc\', u\'\\u73af\\u5883\\u7531  \\u66f4\\u6539\\u4e3a prod\']',null,'87bdb70665f44b3ea18414168f646eb0'),
('ebf008d69e5f472a840de9d0e3bcf63c','hejianxiong','2018-07-03 15:37:33','[u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531 rz-web-pc \\u66f4\\u6539\\u4e3a \']',null,'f39ce94c495a4a7081f6a5140b9ba3d2'),
('eefe33baf52c45ecb2ad1e0665f851c3','admin','2018-03-13 10:02:33','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-account\']',null,'d85625e41fb84609ab991fecb3731ac9'),
('ef7394bb03cb4746bb05f34a2b45b4d4','hejianxiong','2018-04-08 18:06:20','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-callback\']',null,'3fc7f5176602460981b7161adcf6e8c8'),
('f095735aa2864a3f99aedb1c9aa9f933','admin','2018-06-25 21:06:15','[u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531 rz-service-redemption,rz-service-bidweb \\u66f4\\u6539\\u4e3a rz-service-redemption\']',null,'f4f7353dc25a4c3c965c2e1b1760ebe6'),
('f1d4caf8bcce46f7a83af815e29a377b','hejianxiong','2018-06-26 11:45:26','[u\'\\u73af\\u5883\\u7531  \\u66f4\\u6539\\u4e3a prod\']',null,'c02f6dcc9e9e4266a01786ac4dc8a910'),
('f3fd3d3742904f2d9ade019769e807b3','admin','2018-03-12 17:48:59','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-account\']',null,'da5c37a7134a46e09ebfdfe08642a238'),
('f6dfa0fbfd724ec2a1dc9df1f4c0ccfc','admin','2018-03-13 10:59:50','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-accountlog\']',null,'ebc801311a7448d2b9e5702b50f91915'),
('fc970f0f987a459f84e2b9aa979dffbf','admin','2018-03-13 10:07:38','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-redpacket\']',null,'d36533c0f7fe4fdfb0bc8cf6d0821219'),
('fe1e2f606cc84f5d8b0e46d37101195f','admin','2018-03-13 10:04:58','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-service-task\']',null,'dfad991de88a473eb51c8fbfe5758329'),
('ff27f598774b4da19b7c26dd5ad57284','admin','2018-03-13 10:55:43','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-provide\']',null,'929390a816c64ca3bad9427c6a61bc8a'),
('ff72a85afb12451eb8e0a65cd010ab42','admin','2018-03-12 16:03:41','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-pc\', u\'\\u73af\\u5883\\u7531  \\u66f4\\u6539\\u4e3a prod\']',null,'4b01881128644227ac8b345b8ab0e335'),
('ff8cdfc72275465e80028a5286373607','admin','2018-03-12 15:55:22','[u\'\\u72b6\\u6001\\u7531 False \\u66f4\\u6539\\u4e3a True\', u\'\\u6240\\u5c5e\\u4e1a\\u52a1\\u7531  \\u66f4\\u6539\\u4e3a rz-web-app\', u\'\\u73af\\u5883\\u7531  \\u66f4\\u6539\\u4e3a prod\']',null,'3b44291e2ef648dabd1454da8c2fc799');
DROP TABLE IF EXISTS  `project_swan`;
CREATE TABLE `project_swan` (
  `uuid` char(32) NOT NULL,
  `swan_name` varchar(100) NOT NULL,
  `code_name` varchar(100) NOT NULL,
  `choose` varchar(10) NOT NULL,
  `check_port_status` tinyint(1) NOT NULL,
  `check_port` varchar(30) DEFAULT NULL,
  `bat_push` int(11) NOT NULL,
  `tgt` longtext,
  `argall_str` varchar(20) DEFAULT NULL,
  `tomcat_init` varchar(128) DEFAULT NULL,
  `cache` longtext,
  `git_code_user` varchar(12) DEFAULT NULL,
  `code_path` varchar(128) DEFAULT NULL,
  `git_user` varchar(12) DEFAULT NULL,
  `git_pass` varchar(64) DEFAULT NULL,
  `shell` varchar(128) DEFAULT NULL,
  `shell_status` tinyint(1) NOT NULL,
  `CheckUrl` varchar(200) DEFAULT NULL,
  `datetime` datetime NOT NULL,
  `git_code_id` char(32) DEFAULT NULL,
  `project_name_id` char(32) DEFAULT NULL,
  `env` longtext,
  `jar_type` longtext,
  `action` longtext,
  PRIMARY KEY (`uuid`),
  KEY `project_swan_5890d2d4` (`git_code_id`),
  KEY `project_swan_6fa54945` (`project_name_id`),
  CONSTRAINT `project__project_name_id_7f50db0e92eba344_fk_assets_project_uuid` FOREIGN KEY (`project_name_id`) REFERENCES `assets_project` (`uuid`),
  CONSTRAINT `project_swan_git_code_id_108333599249714f_fk_gitCode_uuid` FOREIGN KEY (`git_code_id`) REFERENCES `gitcode` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `project_swan`(`uuid`,`swan_name`,`code_name`,`choose`,`check_port_status`,`check_port`,`bat_push`,`tgt`,`argall_str`,`tomcat_init`,`cache`,`git_code_user`,`code_path`,`git_user`,`git_pass`,`shell`,`shell_status`,`CheckUrl`,`datetime`,`git_code_id`,`project_name_id`,`env`,`jar_type`,`action`) values
('00f09e54e29a47dc866f949ba755b660','rz-service-redpacket','rz-service-redpacket','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-15 18:07:18','','501c6a4698f84b948eb642e87b581016','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('05f204d07621404db22e893d5fa29d33','rz-web-redemption','rz-web-redemption','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-16 09:53:39','','a240928ca7d9484e969f39228a4678bc','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('15e2e12d0a2c4e2c9a519e7ed8bd0fdf','rz-service-borrow','rz-service-borrow','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-15 18:07:49','','60117ba135b74bd198521710be351373','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('20a59b4dd0d5413698ba9c64b6455999','rz-web-ups','rz-web-ups','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-06-19 23:11:06','','3f2f7c6b5eb24ccea5d1047e2a959a96','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('251f70b4a2e44dc7bb93b722722ca653','rz-service-customer','rz-service-customer','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-16 09:57:55','','ac7b15eb162c4490b1f4f5bc4d2403c5','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('6a6f0b4db63d456997373e3483f83fbd','rz-web-callback','rz-web-callback','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-16 09:59:26','','b47613d484c94327a6f4991654f52032','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('6dd78f5bb082420888c046fc10b025f3','rz-service-redemption','rz-service-redemption','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-16 09:52:38','','7b92ba85373f4315a7b9020c7c0227d5','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('81960857dc654f7297c049fa6d17ace2','rz-web-provide','rz-web-provide','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-16 09:55:05','','acf68ee3993641d5b029a205ba7da108','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('82c30d1f7cdf41cd8c87a762f8377736','rz-service-task','rz-service-task','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-15 17:51:30','','a57aa7dd95f24bada3a057b17953b46a','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('84fbd6d5afbd43ecbbc528cf0cd75cff','rz-service-bidweb','rz-service-bidweb','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-06-25 14:42:55','','a5e6b79d00ed480fa0b0180e8cfeaf7d','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('8f3780e03ac54e3c99e85437e65e63d1','rz-web-app','rz-web-app','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-12 14:21:34','','880d60d415574de59c66e092040ceb45','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('983bdcb9123a46b1b8e9aa4885b11cdf','rz-service-third','rz-service-third','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-15 18:04:53','','3df7fcdeadf14376b26436b955242ee3','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('988ddc4c36da4f689b743a3ce04d2a3c','rz-service-account','rz-service-account','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-16 09:57:25','','a98972442c444d0f87f0fc28c70fa270','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('b2b017bbacca4d598394b7cf83d63902','rz-service-taskoffline','rz-service-taskoffline','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-15 18:04:26','','865d759655304107a0eb9067e6217b9d','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('b2f6e08569e5401fbb457a90b733d000','rz-service-content','rz-service-content','4','0',null,'0','master
release
test
springboot',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-12 18:12:11','','28bc8a3a614545c1b606d8d770bf31d6','prod
pre
','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('c08ca0522d0248c5808fb65aa38ee5fd','rz-web-bi','rz-web-bi','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-13 18:35:43','','9d0f99c5f18e4496a80322f8320aa393','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('c8214592eca9448da11c7ee4e8099429','rz-service-accountlog','rz-service-accountlog','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-15 18:05:36','','4d0674633fc8424bb44075597166157c','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('d232f9d47c764cd98cef5fac4be84a21','rz-service-consumer','rz-service-consumer','4','0',null,'0','release
sp',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-16 09:58:32','','c0097a800e784e42bb7cc7b94cd69113','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('d6c010a6b33f48a89d007cbe960a290f','rz-service-rplan','rz-service-rplan','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-15 18:06:12','','6fcc6017391c4e209410e7b76072b5ab','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('dae23435fb0644b7ac230f64055c3cbe','rz-web-pc','rz-web-pc','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-16 09:54:03','','da73040acef5431d932598f826833eac','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('de1fa48b3d1f4ac98fdf2624c0f0722b','rz-service-checkbid','rz-service-checkbid','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-06-25 14:43:49','','db08ce48dcfa4288be0c1add8e539fa6','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('f81f34d2614541289c778b66df22ed9d','rz-web-boss','rz-web-boss','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-13 10:09:07','','51d4fc95a73c413e9b975dd4fec41c5a','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy'),
('f832512dade74e029905c18afcae4691','rz-service-taskcompare','rz-service-taskcompare','4','0',null,'0','release',null,null,null,null,null,null,null,'salt://java-fabu/shell/node.sh','0','','2018-03-15 18:06:47','','9d0759ff802c4331916fc124c08e7c1b','prod
pre','war
jar1
jar2','status
start
stop
reload
restart
lrollback
wrollback
deploy');
DROP TABLE IF EXISTS  `authsudo`;
CREATE TABLE `authsudo` (
  `uuid` char(32) NOT NULL,
  `groupname` varchar(64) NOT NULL,
  `shell` longtext NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `assets_service`;
CREATE TABLE `assets_service` (
  `uuid` char(32) NOT NULL,
  `name` varchar(30) NOT NULL,
  `port` int(11) DEFAULT NULL,
  `remark` longtext,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `incident`;
CREATE TABLE `incident` (
  `uuid` char(32) NOT NULL,
  `title` varchar(256) NOT NULL,
  `ip` char(15) DEFAULT NULL,
  `url` longtext,
  `projectuser` varchar(32) NOT NULL,
  `closeuser` varchar(32) DEFAULT NULL,
  `source` int(11) NOT NULL,
  `starttime` datetime NOT NULL,
  `scantime` datetime DEFAULT NULL,
  `stoptime` datetime DEFAULT NULL,
  `mailcomment` longtext NOT NULL,
  `status` int(11) NOT NULL,
  `classical` tinyint(1) NOT NULL,
  `grade` int(11) DEFAULT NULL,
  `comment` longtext NOT NULL,
  `project_principal` varchar(32) DEFAULT NULL,
  `incident_user` varchar(32) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `salt_ui_salt_mode_name`;
CREATE TABLE `salt_ui_salt_mode_name` (
  `uuid` char(32) NOT NULL,
  `sls_name` varchar(20) NOT NULL,
  `sls_description` longtext,
  `sls_conf` int(11) DEFAULT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1;

